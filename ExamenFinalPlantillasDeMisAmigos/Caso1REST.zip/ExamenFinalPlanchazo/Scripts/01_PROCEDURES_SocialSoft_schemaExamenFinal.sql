USE schemaExamenFinal;

DELIMITER $$

DROP PROCEDURE IF EXISTS INSERTAR_CANAL$$
CREATE PROCEDURE INSERTAR_CANAL(
    OUT _id INT,
    IN _nombre VARCHAR(100),
    IN _descripcion VARCHAR(255),
    IN _fecha_creacion DATE,
    IN _numero_seguidores INT,
    IN _categoria VARCHAR(80)
)
BEGIN
    INSERT INTO canal(nombre, descripcion, fecha_creacion, numero_seguidores, categoria)
    VALUES(_nombre, _descripcion, _fecha_creacion, _numero_seguidores, _categoria);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_CANAL$$
CREATE PROCEDURE MODIFICAR_CANAL(
    IN _id INT,
    IN _nombre VARCHAR(100),
    IN _descripcion VARCHAR(255),
    IN _fecha_creacion DATE,
    IN _numero_seguidores INT,
    IN _categoria VARCHAR(80)
)
BEGIN
    UPDATE canal
    SET nombre = _nombre,
        descripcion = _descripcion,
        fecha_creacion = _fecha_creacion,
        numero_seguidores = _numero_seguidores,
        categoria = _categoria
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_CANAL$$
CREATE PROCEDURE ELIMINAR_CANAL(IN _id INT)
BEGIN
    DELETE FROM canal WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_CANAL_X_ID$$
CREATE PROCEDURE OBTENER_CANAL_X_ID(IN _id INT)
BEGIN
    SELECT id, nombre, descripcion, fecha_creacion, numero_seguidores, categoria
    FROM canal
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_CANALES$$
CREATE PROCEDURE LISTAR_CANALES()
BEGIN
    SELECT id, nombre, descripcion, fecha_creacion, numero_seguidores, categoria
    FROM canal
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS INSERTAR_USUARIO$$
CREATE PROCEDURE INSERTAR_USUARIO(
    OUT _id INT,
    IN _nombre_completo VARCHAR(120),
    IN _dni VARCHAR(8),
    IN _edad INT,
    IN _ciudad VARCHAR(80),
    IN _fecha_nacimiento DATE,
    IN _telefono VARCHAR(20),
    IN _correo VARCHAR(120),
    IN _profesion VARCHAR(120)
)
BEGIN
    INSERT INTO usuario(nombre_completo, dni, edad, ciudad, fecha_nacimiento, telefono, correo, profesion)
    VALUES(_nombre_completo, _dni, _edad, _ciudad, _fecha_nacimiento, _telefono, _correo, _profesion);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_USUARIO$$
CREATE PROCEDURE MODIFICAR_USUARIO(
    IN _id INT,
    IN _nombre_completo VARCHAR(120),
    IN _dni VARCHAR(8),
    IN _edad INT,
    IN _ciudad VARCHAR(80),
    IN _fecha_nacimiento DATE,
    IN _telefono VARCHAR(20),
    IN _correo VARCHAR(120),
    IN _profesion VARCHAR(120)
)
BEGIN
    UPDATE usuario
    SET nombre_completo = _nombre_completo,
        dni = _dni,
        edad = _edad,
        ciudad = _ciudad,
        fecha_nacimiento = _fecha_nacimiento,
        telefono = _telefono,
        correo = _correo,
        profesion = _profesion
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_USUARIO$$
CREATE PROCEDURE ELIMINAR_USUARIO(IN _id INT)
BEGIN
    DELETE FROM usuario WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_USUARIO_X_ID$$
CREATE PROCEDURE OBTENER_USUARIO_X_ID(IN _id INT)
BEGIN
    SELECT id, nombre_completo, dni, edad, ciudad, fecha_nacimiento, telefono, correo, profesion
    FROM usuario
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_USUARIOS$$
CREATE PROCEDURE LISTAR_USUARIOS()
BEGIN
    SELECT id, nombre_completo, dni, edad, ciudad, fecha_nacimiento, telefono, correo, profesion
    FROM usuario
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS INSERTAR_PLAN_SUSCRIPCION$$
CREATE PROCEDURE INSERTAR_PLAN_SUSCRIPCION(
    OUT _id INT,
    IN _nombre VARCHAR(20),
    IN _costo_mensual DECIMAL(10,2)
)
BEGIN
    INSERT INTO plan_suscripcion(nombre, costo_mensual)
    VALUES(_nombre, _costo_mensual);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_PLAN_SUSCRIPCION$$
CREATE PROCEDURE MODIFICAR_PLAN_SUSCRIPCION(
    IN _id INT,
    IN _nombre VARCHAR(20),
    IN _costo_mensual DECIMAL(10,2)
)
BEGIN
    UPDATE plan_suscripcion
    SET nombre = _nombre,
        costo_mensual = _costo_mensual
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_PLAN_SUSCRIPCION$$
CREATE PROCEDURE ELIMINAR_PLAN_SUSCRIPCION(IN _id INT)
BEGIN
    DELETE FROM plan_suscripcion WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_PLAN_SUSCRIPCION_X_ID$$
CREATE PROCEDURE OBTENER_PLAN_SUSCRIPCION_X_ID(IN _id INT)
BEGIN
    SELECT id, nombre, costo_mensual
    FROM plan_suscripcion
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_PLANES_SUSCRIPCION$$
CREATE PROCEDURE LISTAR_PLANES_SUSCRIPCION()
BEGIN
    SELECT id, nombre, costo_mensual
    FROM plan_suscripcion
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS INSERTAR_RESOLUCION$$
CREATE PROCEDURE INSERTAR_RESOLUCION(
    OUT _id INT,
    IN _nombre VARCHAR(20),
    IN _descripcion VARCHAR(100)
)
BEGIN
    INSERT INTO resolucion(nombre, descripcion)
    VALUES(_nombre, _descripcion);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_RESOLUCION$$
CREATE PROCEDURE MODIFICAR_RESOLUCION(
    IN _id INT,
    IN _nombre VARCHAR(20),
    IN _descripcion VARCHAR(100)
)
BEGIN
    UPDATE resolucion
    SET nombre = _nombre,
        descripcion = _descripcion
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_RESOLUCION$$
CREATE PROCEDURE ELIMINAR_RESOLUCION(IN _id INT)
BEGIN
    DELETE FROM resolucion WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_RESOLUCION_X_ID$$
CREATE PROCEDURE OBTENER_RESOLUCION_X_ID(IN _id INT)
BEGIN
    SELECT id, nombre, descripcion
    FROM resolucion
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_RESOLUCIONES$$
CREATE PROCEDURE LISTAR_RESOLUCIONES()
BEGIN
    SELECT id, nombre, descripcion
    FROM resolucion
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS INSERTAR_PLAN_RESOLUCION$$
CREATE PROCEDURE INSERTAR_PLAN_RESOLUCION(
    OUT _id INT,
    IN _id_plan_suscripcion INT,
    IN _id_resolucion INT
)
BEGIN
    INSERT INTO plan_resolucion(id_plan_suscripcion, id_resolucion)
    VALUES(_id_plan_suscripcion, _id_resolucion);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_PLAN_RESOLUCION$$
CREATE PROCEDURE MODIFICAR_PLAN_RESOLUCION(
    IN _id INT,
    IN _id_plan_suscripcion INT,
    IN _id_resolucion INT
)
BEGIN
    UPDATE plan_resolucion
    SET id_plan_suscripcion = _id_plan_suscripcion,
        id_resolucion = _id_resolucion
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_PLAN_RESOLUCION$$
CREATE PROCEDURE ELIMINAR_PLAN_RESOLUCION(IN _id INT)
BEGIN
    DELETE FROM plan_resolucion WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_PLAN_RESOLUCION_X_ID$$
CREATE PROCEDURE OBTENER_PLAN_RESOLUCION_X_ID(IN _id INT)
BEGIN
    SELECT id, id_plan_suscripcion, id_resolucion
    FROM plan_resolucion
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_PLANES_RESOLUCION$$
CREATE PROCEDURE LISTAR_PLANES_RESOLUCION()
BEGIN
    SELECT id, id_plan_suscripcion, id_resolucion
    FROM plan_resolucion
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS INSERTAR_BENEFICIO$$
CREATE PROCEDURE INSERTAR_BENEFICIO(
    OUT _id INT,
    IN _nombre VARCHAR(100),
    IN _descripcion VARCHAR(255)
)
BEGIN
    INSERT INTO beneficio(nombre, descripcion)
    VALUES(_nombre, _descripcion);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_BENEFICIO$$
CREATE PROCEDURE MODIFICAR_BENEFICIO(
    IN _id INT,
    IN _nombre VARCHAR(100),
    IN _descripcion VARCHAR(255)
)
BEGIN
    UPDATE beneficio
    SET nombre = _nombre,
        descripcion = _descripcion
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_BENEFICIO$$
CREATE PROCEDURE ELIMINAR_BENEFICIO(IN _id INT)
BEGIN
    DELETE FROM beneficio WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_BENEFICIO_X_ID$$
CREATE PROCEDURE OBTENER_BENEFICIO_X_ID(IN _id INT)
BEGIN
    SELECT id, nombre, descripcion
    FROM beneficio
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_BENEFICIOS$$
CREATE PROCEDURE LISTAR_BENEFICIOS()
BEGIN
    SELECT id, nombre, descripcion
    FROM beneficio
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS INSERTAR_PLAN_BENEFICIO$$
CREATE PROCEDURE INSERTAR_PLAN_BENEFICIO(
    OUT _id INT,
    IN _id_plan_suscripcion INT,
    IN _id_beneficio INT
)
BEGIN
    INSERT INTO plan_beneficio(id_plan_suscripcion, id_beneficio)
    VALUES(_id_plan_suscripcion, _id_beneficio);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_PLAN_BENEFICIO$$
CREATE PROCEDURE MODIFICAR_PLAN_BENEFICIO(
    IN _id INT,
    IN _id_plan_suscripcion INT,
    IN _id_beneficio INT
)
BEGIN
    UPDATE plan_beneficio
    SET id_plan_suscripcion = _id_plan_suscripcion,
        id_beneficio = _id_beneficio
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_PLAN_BENEFICIO$$
CREATE PROCEDURE ELIMINAR_PLAN_BENEFICIO(IN _id INT)
BEGIN
    DELETE FROM plan_beneficio WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_PLAN_BENEFICIO_X_ID$$
CREATE PROCEDURE OBTENER_PLAN_BENEFICIO_X_ID(IN _id INT)
BEGIN
    SELECT id, id_plan_suscripcion, id_beneficio
    FROM plan_beneficio
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_PLANES_BENEFICIO$$
CREATE PROCEDURE LISTAR_PLANES_BENEFICIO()
BEGIN
    SELECT id, id_plan_suscripcion, id_beneficio
    FROM plan_beneficio
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS INSERTAR_USUARIO_CANAL_SUSCRIPCION$$
CREATE PROCEDURE INSERTAR_USUARIO_CANAL_SUSCRIPCION(
    OUT _id INT,
    IN _id_usuario INT,
    IN _id_canal INT,
    IN _id_plan_suscripcion INT,
    IN _fecha_registro TIMESTAMP,
    IN _estado VARCHAR(20)
)
BEGIN
    INSERT INTO usuario_canal_suscripcion(id_usuario, id_canal, id_plan_suscripcion, fecha_registro, estado)
    VALUES(_id_usuario, _id_canal, _id_plan_suscripcion, COALESCE(_fecha_registro, CURRENT_TIMESTAMP), _estado);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_USUARIO_CANAL_SUSCRIPCION$$
CREATE PROCEDURE MODIFICAR_USUARIO_CANAL_SUSCRIPCION(
    IN _id INT,
    IN _id_usuario INT,
    IN _id_canal INT,
    IN _id_plan_suscripcion INT,
    IN _fecha_registro TIMESTAMP,
    IN _estado VARCHAR(20)
)
BEGIN
    UPDATE usuario_canal_suscripcion
    SET id_usuario = _id_usuario,
        id_canal = _id_canal,
        id_plan_suscripcion = _id_plan_suscripcion,
        fecha_registro = _fecha_registro,
        estado = _estado
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_USUARIO_CANAL_SUSCRIPCION$$
CREATE PROCEDURE ELIMINAR_USUARIO_CANAL_SUSCRIPCION(IN _id INT)
BEGIN
    UPDATE usuario_canal_suscripcion
    SET estado = 'CANCELADA'
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_USUARIO_CANAL_SUSCRIPCION_X_ID$$
CREATE PROCEDURE OBTENER_USUARIO_CANAL_SUSCRIPCION_X_ID(IN _id INT)
BEGIN
    SELECT id, id_usuario, id_canal, id_plan_suscripcion, fecha_registro, estado
    FROM usuario_canal_suscripcion
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_USUARIO_CANAL_SUSCRIPCIONES$$
CREATE PROCEDURE LISTAR_USUARIO_CANAL_SUSCRIPCIONES()
BEGIN
    SELECT id, id_usuario, id_canal, id_plan_suscripcion, fecha_registro, estado
    FROM usuario_canal_suscripcion
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS INSERTAR_METODO_PAGO$$
CREATE PROCEDURE INSERTAR_METODO_PAGO(
    OUT _id INT,
    IN _nombre VARCHAR(40)
)
BEGIN
    INSERT INTO metodo_pago(nombre)
    VALUES(_nombre);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_METODO_PAGO$$
CREATE PROCEDURE MODIFICAR_METODO_PAGO(
    IN _id INT,
    IN _nombre VARCHAR(40)
)
BEGIN
    UPDATE metodo_pago
    SET nombre = _nombre
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_METODO_PAGO$$
CREATE PROCEDURE ELIMINAR_METODO_PAGO(IN _id INT)
BEGIN
    DELETE FROM metodo_pago WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_METODO_PAGO_X_ID$$
CREATE PROCEDURE OBTENER_METODO_PAGO_X_ID(IN _id INT)
BEGIN
    SELECT id, nombre
    FROM metodo_pago
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_METODOS_PAGO$$
CREATE PROCEDURE LISTAR_METODOS_PAGO()
BEGIN
    SELECT id, nombre
    FROM metodo_pago
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS INSERTAR_PAGO_SUSCRIPCION$$
CREATE PROCEDURE INSERTAR_PAGO_SUSCRIPCION(
    OUT _id INT,
    IN _id_usuario_canal_suscripcion INT,
    IN _id_metodo_pago INT,
    IN _monto DECIMAL(10,2),
    IN _fecha_pago DATE,
    IN _estado VARCHAR(20)
)
BEGIN
    INSERT INTO pago_suscripcion(id_usuario_canal_suscripcion, id_metodo_pago, monto, fecha_pago, estado)
    VALUES(_id_usuario_canal_suscripcion, _id_metodo_pago, _monto, _fecha_pago, _estado);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_PAGO_SUSCRIPCION$$
CREATE PROCEDURE MODIFICAR_PAGO_SUSCRIPCION(
    IN _id INT,
    IN _id_usuario_canal_suscripcion INT,
    IN _id_metodo_pago INT,
    IN _monto DECIMAL(10,2),
    IN _fecha_pago DATE,
    IN _estado VARCHAR(20)
)
BEGIN
    UPDATE pago_suscripcion
    SET id_usuario_canal_suscripcion = _id_usuario_canal_suscripcion,
        id_metodo_pago = _id_metodo_pago,
        monto = _monto,
        fecha_pago = _fecha_pago,
        estado = _estado
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_PAGO_SUSCRIPCION$$
CREATE PROCEDURE ELIMINAR_PAGO_SUSCRIPCION(IN _id INT)
BEGIN
    UPDATE pago_suscripcion
    SET estado = 'ANULADO'
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_PAGO_SUSCRIPCION_X_ID$$
CREATE PROCEDURE OBTENER_PAGO_SUSCRIPCION_X_ID(IN _id INT)
BEGIN
    SELECT id, id_usuario_canal_suscripcion, id_metodo_pago, monto, fecha_pago, estado
    FROM pago_suscripcion
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_PAGOS_SUSCRIPCION$$
CREATE PROCEDURE LISTAR_PAGOS_SUSCRIPCION()
BEGIN
    SELECT id, id_usuario_canal_suscripcion, id_metodo_pago, monto, fecha_pago, estado
    FROM pago_suscripcion
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS INSERTAR_DISPOSITIVO_USUARIO$$
CREATE PROCEDURE INSERTAR_DISPOSITIVO_USUARIO(
    OUT _id INT,
    IN _id_usuario INT,
    IN _nombre VARCHAR(100),
    IN _tipo VARCHAR(50),
    IN _sistema_operativo VARCHAR(50),
    IN _activo TINYINT
)
BEGIN
    INSERT INTO dispositivo_usuario(id_usuario, nombre, tipo, sistema_operativo, activo)
    VALUES(_id_usuario, _nombre, _tipo, _sistema_operativo, _activo);
    SET _id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS MODIFICAR_DISPOSITIVO_USUARIO$$
CREATE PROCEDURE MODIFICAR_DISPOSITIVO_USUARIO(
    IN _id INT,
    IN _id_usuario INT,
    IN _nombre VARCHAR(100),
    IN _tipo VARCHAR(50),
    IN _sistema_operativo VARCHAR(50),
    IN _activo TINYINT
)
BEGIN
    UPDATE dispositivo_usuario
    SET id_usuario = _id_usuario,
        nombre = _nombre,
        tipo = _tipo,
        sistema_operativo = _sistema_operativo,
        activo = _activo
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS ELIMINAR_DISPOSITIVO_USUARIO$$
CREATE PROCEDURE ELIMINAR_DISPOSITIVO_USUARIO(IN _id INT)
BEGIN
    UPDATE dispositivo_usuario
    SET activo = FALSE
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS OBTENER_DISPOSITIVO_USUARIO_X_ID$$
CREATE PROCEDURE OBTENER_DISPOSITIVO_USUARIO_X_ID(IN _id INT)
BEGIN
    SELECT id, id_usuario, nombre, tipo, sistema_operativo, activo
    FROM dispositivo_usuario
    WHERE id = _id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_DISPOSITIVOS_USUARIO$$
CREATE PROCEDURE LISTAR_DISPOSITIVOS_USUARIO()
BEGIN
    SELECT id, id_usuario, nombre, tipo, sistema_operativo, activo
    FROM dispositivo_usuario
    ORDER BY id;
END$$

/* Procedimientos de consulta útiles para el caso */

DROP PROCEDURE IF EXISTS LISTAR_CANALES_X_CATEGORIA$$
CREATE PROCEDURE LISTAR_CANALES_X_CATEGORIA(IN _categoria VARCHAR(80))
BEGIN
    SELECT id, nombre, descripcion, fecha_creacion, numero_seguidores, categoria
    FROM canal
    WHERE categoria = _categoria
    ORDER BY nombre;
END$$

DROP PROCEDURE IF EXISTS LISTAR_SUSCRIPCIONES_X_USUARIO$$
CREATE PROCEDURE LISTAR_SUSCRIPCIONES_X_USUARIO(IN _id_usuario INT)
BEGIN
    SELECT id, id_usuario, id_canal, id_plan_suscripcion, fecha_registro, estado
    FROM usuario_canal_suscripcion
    WHERE id_usuario = _id_usuario
    ORDER BY fecha_registro DESC;
END$$

DROP PROCEDURE IF EXISTS LISTAR_PAGOS_X_SUSCRIPCION$$
CREATE PROCEDURE LISTAR_PAGOS_X_SUSCRIPCION(IN _id_usuario_canal_suscripcion INT)
BEGIN
    SELECT id, id_usuario_canal_suscripcion, id_metodo_pago, monto, fecha_pago, estado
    FROM pago_suscripcion
    WHERE id_usuario_canal_suscripcion = _id_usuario_canal_suscripcion
    ORDER BY fecha_pago DESC;
END$$

DROP PROCEDURE IF EXISTS LISTAR_DISPOSITIVOS_X_USUARIO$$
CREATE PROCEDURE LISTAR_DISPOSITIVOS_X_USUARIO(IN _id_usuario INT)
BEGIN
    SELECT id, id_usuario, nombre, tipo, sistema_operativo, activo
    FROM dispositivo_usuario
    WHERE id_usuario = _id_usuario
    ORDER BY id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_BENEFICIOS_X_PLAN$$
CREATE PROCEDURE LISTAR_BENEFICIOS_X_PLAN(IN _id_plan_suscripcion INT)
BEGIN
    SELECT b.id, b.nombre, b.descripcion
    FROM beneficio b
    INNER JOIN plan_beneficio pb ON pb.id_beneficio = b.id
    WHERE pb.id_plan_suscripcion = _id_plan_suscripcion
    ORDER BY b.id;
END$$

DROP PROCEDURE IF EXISTS LISTAR_RESOLUCIONES_X_PLAN$$
CREATE PROCEDURE LISTAR_RESOLUCIONES_X_PLAN(IN _id_plan_suscripcion INT)
BEGIN
    SELECT r.id, r.nombre, r.descripcion
    FROM resolucion r
    INNER JOIN plan_resolucion pr ON pr.id_resolucion = r.id
    WHERE pr.id_plan_suscripcion = _id_plan_suscripcion
    ORDER BY r.id;
END$$

DELIMITER ;
