using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace CSharpRestClient
{
    public class SocialSoftRSManager
    {
        private readonly string BASE_URL;

        public SocialSoftRSManager(IConfiguration configuration)
        {
            BASE_URL = configuration["SocialSoftApiBaseUrl"]
                       ?? "http://localhost:8080/RestServices-1.0-SNAPSHOT/webservices";

            BASE_URL = BASE_URL.TrimEnd('/');
        }

        public SocialSoftRSManager()
        {
            BASE_URL = "http://localhost:8080/RestServices/webresources";
        }

        public SocialSoftRSManager(string baseUrl)
        {
            BASE_URL = baseUrl.TrimEnd('/');
        }

        private string Url(string endpoint)
        {
            return $"{BASE_URL}/{endpoint.TrimStart('/')}";
        }

        // =========================
        // Usuarios
        // =========================
        public List<UsuarioDTO> ListarUsuarios()
        {
            return new HttpClientUtils<List<UsuarioDTO>>().get(Url("usuarios"));
        }

        public UsuarioDTO BuscarUsuarioPorId(int id)
        {
            return new HttpClientUtils<UsuarioDTO>().get(Url($"usuarios/{id}"));
        }

        public int InsertarUsuario(UsuarioDTO usuario)
        {
            return new HttpClientUtils<int>().post(Url("usuarios"), usuario);
        }

        public int ModificarUsuario(UsuarioDTO usuario)
        {
            return new HttpClientUtils<int>().put(Url($"usuarios/{usuario.Id}"), usuario);
        }

        public int EliminarUsuario(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"usuarios/{id}"));
        }

        // =========================
        // Canales
        // =========================
        public List<CanalDTO> ListarCanales()
        {
            return new HttpClientUtils<List<CanalDTO>>().get(Url("canales"));
        }

        public CanalDTO BuscarCanalPorId(int id)
        {
            return new HttpClientUtils<CanalDTO>().get(Url($"canales/{id}"));
        }

        public int InsertarCanal(CanalDTO canal)
        {
            return new HttpClientUtils<int>().post(Url("canales"), canal);
        }

        public int ModificarCanal(CanalDTO canal)
        {
            return new HttpClientUtils<int>().put(Url($"canales/{canal.Id}"), canal);
        }

        public int EliminarCanal(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"canales/{id}"));
        }

        // =========================
        // Planes de suscripción
        // =========================
        public List<PlanSuscripcionDTO> ListarPlanes()
        {
            return new HttpClientUtils<List<PlanSuscripcionDTO>>().get(Url("planes-suscripcion"));
        }

        public PlanSuscripcionDTO BuscarPlanPorId(int id)
        {
            return new HttpClientUtils<PlanSuscripcionDTO>().get(Url($"planes-suscripcion/{id}"));
        }

        public int InsertarPlan(PlanSuscripcionDTO plan)
        {
            return new HttpClientUtils<int>().post(Url("planes-suscripcion"), plan);
        }

        public int ModificarPlan(PlanSuscripcionDTO plan)
        {
            return new HttpClientUtils<int>().put(Url($"planes-suscripcion/{plan.Id}"), plan);
        }

        public int EliminarPlan(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"planes-suscripcion/{id}"));
        }

        // =========================
        // Resoluciones
        // =========================
        public List<ResolucionDTO> ListarResoluciones()
        {
            return new HttpClientUtils<List<ResolucionDTO>>().get(Url("resoluciones"));
        }

        public ResolucionDTO BuscarResolucionPorId(int id)
        {
            return new HttpClientUtils<ResolucionDTO>().get(Url($"resoluciones/{id}"));
        }

        public int InsertarResolucion(ResolucionDTO resolucion)
        {
            return new HttpClientUtils<int>().post(Url("resoluciones"), resolucion);
        }

        public int ModificarResolucion(ResolucionDTO resolucion)
        {
            return new HttpClientUtils<int>().put(Url($"resoluciones/{resolucion.Id}"), resolucion);
        }

        public int EliminarResolucion(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"resoluciones/{id}"));
        }

        // =========================
        // Beneficios
        // =========================
        public List<BeneficioDTO> ListarBeneficios()
        {
            return new HttpClientUtils<List<BeneficioDTO>>().get(Url("beneficios"));
        }

        public BeneficioDTO BuscarBeneficioPorId(int id)
        {
            return new HttpClientUtils<BeneficioDTO>().get(Url($"beneficios/{id}"));
        }

        public int InsertarBeneficio(BeneficioDTO beneficio)
        {
            return new HttpClientUtils<int>().post(Url("beneficios"), beneficio);
        }

        public int ModificarBeneficio(BeneficioDTO beneficio)
        {
            return new HttpClientUtils<int>().put(Url($"beneficios/{beneficio.Id}"), beneficio);
        }

        public int EliminarBeneficio(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"beneficios/{id}"));
        }

        // =========================
        // Métodos de pago
        // =========================
        public List<MetodoPagoDTO> ListarMetodosPago()
        {
            return new HttpClientUtils<List<MetodoPagoDTO>>().get(Url("metodos-pago"));
        }

        public MetodoPagoDTO BuscarMetodoPagoPorId(int id)
        {
            return new HttpClientUtils<MetodoPagoDTO>().get(Url($"metodos-pago/{id}"));
        }

        public int InsertarMetodoPago(MetodoPagoDTO metodoPago)
        {
            return new HttpClientUtils<int>().post(Url("metodos-pago"), metodoPago);
        }

        public int ModificarMetodoPago(MetodoPagoDTO metodoPago)
        {
            return new HttpClientUtils<int>().put(Url($"metodos-pago/{metodoPago.Id}"), metodoPago);
        }

        public int EliminarMetodoPago(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"metodos-pago/{id}"));
        }

        // =========================
        // Suscripciones usuario-canal
        // =========================
        public List<UsuarioCanalSuscripcionDTO> ListarSuscripciones()
        {
            return new HttpClientUtils<List<UsuarioCanalSuscripcionDTO>>().get(Url("suscripciones"));
        }

        public UsuarioCanalSuscripcionDTO BuscarSuscripcionPorId(int id)
        {
            return new HttpClientUtils<UsuarioCanalSuscripcionDTO>().get(Url($"suscripciones/{id}"));
        }

        public int InsertarSuscripcion(UsuarioCanalSuscripcionDTO suscripcion)
        {
            return new HttpClientUtils<int>().post(Url("suscripciones"), suscripcion);
        }

        public int ModificarSuscripcion(UsuarioCanalSuscripcionDTO suscripcion)
        {
            return new HttpClientUtils<int>().put(Url($"suscripciones/{suscripcion.Id}"), suscripcion);
        }

        public int EliminarSuscripcion(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"suscripciones/{id}"));
        }

        // =========================
        // Pagos
        // =========================
        public List<PagoSuscripcionDTO> ListarPagos()
        {
            return new HttpClientUtils<List<PagoSuscripcionDTO>>().get(Url("pagos-suscripcion"));
        }

        public PagoSuscripcionDTO BuscarPagoPorId(int id)
        {
            return new HttpClientUtils<PagoSuscripcionDTO>().get(Url($"pagos-suscripcion/{id}"));
        }

        public int InsertarPago(PagoSuscripcionDTO pago)
        {
            return new HttpClientUtils<int>().post(Url("pagos-suscripcion"), pago);
        }

        public int ModificarPago(PagoSuscripcionDTO pago)
        {
            return new HttpClientUtils<int>().put(Url($"pagos-suscripcion/{pago.Id}"), pago);
        }

        public int EliminarPago(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"pagos-suscripcion/{id}"));
        }

        // =========================
        // Dispositivos
        // =========================
        public List<DispositivoUsuarioDTO> ListarDispositivos()
        {
            return new HttpClientUtils<List<DispositivoUsuarioDTO>>().get(Url("dispositivos-usuario"));
        }

        public DispositivoUsuarioDTO BuscarDispositivoPorId(int id)
        {
            return new HttpClientUtils<DispositivoUsuarioDTO>().get(Url($"dispositivos-usuario/{id}"));
        }

        public int InsertarDispositivo(DispositivoUsuarioDTO dispositivo)
        {
            return new HttpClientUtils<int>().post(Url("dispositivos-usuario"), dispositivo);
        }

        public int ModificarDispositivo(DispositivoUsuarioDTO dispositivo)
        {
            return new HttpClientUtils<int>().put(Url($"dispositivos-usuario/{dispositivo.Id}"), dispositivo);
        }

        public int EliminarDispositivo(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"dispositivos-usuario/{id}"));
        }

        // =========================
        // Plan - Beneficio
        // =========================
        public List<PlanBeneficioDTO> ListarPlanBeneficios()
        {
            return new HttpClientUtils<List<PlanBeneficioDTO>>().get(Url("plan-beneficios"));
        }

        public PlanBeneficioDTO BuscarPlanBeneficioPorId(int id)
        {
            return new HttpClientUtils<PlanBeneficioDTO>().get(Url($"plan-beneficios/{id}"));
        }

        public int InsertarPlanBeneficio(PlanBeneficioDTO planBeneficio)
        {
            return new HttpClientUtils<int>().post(Url("plan-beneficios"), planBeneficio);
        }

        public int EliminarPlanBeneficio(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"plan-beneficios/{id}"));
        }

        // =========================
        // Plan - Resolución
        // =========================
        public List<PlanResolucionDTO> ListarPlanResoluciones()
        {
            return new HttpClientUtils<List<PlanResolucionDTO>>().get(Url("plan-resoluciones"));
        }

        public PlanResolucionDTO BuscarPlanResolucionPorId(int id)
        {
            return new HttpClientUtils<PlanResolucionDTO>().get(Url($"plan-resoluciones/{id}"));
        }

        public int InsertarPlanResolucion(PlanResolucionDTO planResolucion)
        {
            return new HttpClientUtils<int>().post(Url("plan-resoluciones"), planResolucion);
        }

        public int EliminarPlanResolucion(int id)
        {
            return new HttpClientUtils<int>().delete(Url($"plan-resoluciones/{id}"));
        }
    }
}
