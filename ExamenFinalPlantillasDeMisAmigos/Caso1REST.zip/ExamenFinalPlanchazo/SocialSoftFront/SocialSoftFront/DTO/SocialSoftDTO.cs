using Newtonsoft.Json;
using System;

namespace CSharpRestClient
{
    public class UsuarioDTO
    {
        private int id;
        private string nombreCompleto;
        private string dni;
        private int edad;
        private string ciudad;
        private string fechaNacimiento;
        private string telefono;
        private string correo;
        private string profesion;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("nombreCompleto")]
        public string NombreCompleto { get => nombreCompleto; set => nombreCompleto = value; }

        [JsonProperty("dni")]
        public string Dni { get => dni; set => dni = value; }

        [JsonProperty("edad")]
        public int Edad { get => edad; set => edad = value; }

        [JsonProperty("ciudad")]
        public string Ciudad { get => ciudad; set => ciudad = value; }

        [JsonProperty("fechaNacimiento")]
        public string FechaNacimiento { get => fechaNacimiento; set => fechaNacimiento = value; }

        [JsonProperty("telefono")]
        public string Telefono { get => telefono; set => telefono = value; }

        [JsonProperty("correo")]
        public string Correo { get => correo; set => correo = value; }

        [JsonProperty("profesion")]
        public string Profesion { get => profesion; set => profesion = value; }
    }

    public class CanalDTO
    {
        private int id;
        private string nombre;
        private string descripcion;
        private string fechaCreacion;
        private string categoria;
        private int numeroSeguidores;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("nombre")]
        public string Nombre { get => nombre; set => nombre = value; }

        [JsonProperty("descripcion")]
        public string Descripcion { get => descripcion; set => descripcion = value; }

        [JsonProperty("fechaCreacion")]
        public string FechaCreacion { get => fechaCreacion; set => fechaCreacion = value; }

        [JsonProperty("categoria")]
        public string Categoria { get => categoria; set => categoria = value; }

        [JsonProperty("numeroSeguidores")]
        public int NumeroSeguidores { get => numeroSeguidores; set => numeroSeguidores = value; }
    }

    public class PlanSuscripcionDTO
    {
        private int id;
        private string nombre;
        private double costoMensual;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("nombre")]
        public string Nombre { get => nombre; set => nombre = value; }

        [JsonProperty("costoMensual")]
        public double CostoMensual { get => costoMensual; set => costoMensual = value; }
    }

    public class ResolucionDTO
    {
        private int id;
        private string nombre;
        private string descripcion;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("nombre")]
        public string Nombre { get => nombre; set => nombre = value; }

        [JsonProperty("descripcion")]
        public string Descripcion { get => descripcion; set => descripcion = value; }
    }

    public class BeneficioDTO
    {
        private int id;
        private string nombre;
        private string descripcion;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("nombre")]
        public string Nombre { get => nombre; set => nombre = value; }

        [JsonProperty("descripcion")]
        public string Descripcion { get => descripcion; set => descripcion = value; }
    }

    public class MetodoPagoDTO
    {
        private int id;
        private string nombre;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("nombre")]
        public string Nombre { get => nombre; set => nombre = value; }
    }

    public class UsuarioCanalSuscripcionDTO
    {
        private int id;
        private UsuarioDTO usuario;
        private CanalDTO canal;
        private PlanSuscripcionDTO planSuscripcion;
        private string fechaRegistro;
        private string estado;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("usuario")]
        public UsuarioDTO Usuario { get => usuario; set => usuario = value; }

        [JsonProperty("canal")]
        public CanalDTO Canal { get => canal; set => canal = value; }

        [JsonProperty("planSuscripcion")]
        public PlanSuscripcionDTO PlanSuscripcion { get => planSuscripcion; set => planSuscripcion = value; }

        [JsonProperty("fechaRegistro")]
        public string FechaRegistro { get => fechaRegistro; set => fechaRegistro = value; }

        [JsonProperty("estado")]
        public string Estado { get => estado; set => estado = value; }
    }

    public class PagoSuscripcionDTO
    {
        private int id;
        private UsuarioCanalSuscripcionDTO usuarioCanalSuscripcion;
        private MetodoPagoDTO metodoPago;
        private double monto;
        private string fechaPago;
        private string estado;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("usuarioCanalSuscripcion")]
        public UsuarioCanalSuscripcionDTO UsuarioCanalSuscripcion { get => usuarioCanalSuscripcion; set => usuarioCanalSuscripcion = value; }

        [JsonProperty("metodoPago")]
        public MetodoPagoDTO MetodoPago { get => metodoPago; set => metodoPago = value; }

        [JsonProperty("monto")]
        public double Monto { get => monto; set => monto = value; }

        [JsonProperty("fechaPago")]
        public string FechaPago { get => fechaPago; set => fechaPago = value; }

        [JsonProperty("estado")]
        public string Estado { get => estado; set => estado = value; }
    }

    public class DispositivoUsuarioDTO
    {
        private int id;
        private UsuarioDTO usuario;
        private string nombre;
        private string tipo;
        private string sistemaOperativo;
        private bool activo;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("usuario")]
        public UsuarioDTO Usuario { get => usuario; set => usuario = value; }

        [JsonProperty("nombre")]
        public string Nombre { get => nombre; set => nombre = value; }

        [JsonProperty("tipo")]
        public string Tipo { get => tipo; set => tipo = value; }

        [JsonProperty("sistemaOperativo")]
        public string SistemaOperativo { get => sistemaOperativo; set => sistemaOperativo = value; }

        [JsonProperty("activo")]
        public bool Activo { get => activo; set => activo = value; }
    }

    public class PlanBeneficioDTO
    {
        private int id;
        private PlanSuscripcionDTO planSuscripcion;
        private BeneficioDTO beneficio;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("planSuscripcion")]
        public PlanSuscripcionDTO PlanSuscripcion { get => planSuscripcion; set => planSuscripcion = value; }

        [JsonProperty("beneficio")]
        public BeneficioDTO Beneficio { get => beneficio; set => beneficio = value; }
    }

    public class PlanResolucionDTO
    {
        private int id;
        private PlanSuscripcionDTO planSuscripcion;
        private ResolucionDTO resolucion;

        [JsonProperty("id")]
        public int Id { get => id; set => id = value; }

        [JsonProperty("planSuscripcion")]
        public PlanSuscripcionDTO PlanSuscripcion { get => planSuscripcion; set => planSuscripcion = value; }

        [JsonProperty("resolucion")]
        public ResolucionDTO Resolucion { get => resolucion; set => resolucion = value; }
    }
}
