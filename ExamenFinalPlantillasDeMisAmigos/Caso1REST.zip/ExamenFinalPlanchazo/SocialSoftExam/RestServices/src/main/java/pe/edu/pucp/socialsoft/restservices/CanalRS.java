package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.CanalBO;
import pe.edu.pucp.socialsoft.business.implementsBO.CanalImplementsBO;
import pe.edu.pucp.socialsoft.model.Canal;

import java.util.List;

@Path("canales")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CanalRS {

    private CanalBO canalBO;

    public CanalRS() {
        canalBO = new CanalImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de canales funcionando";
    }

    @GET
    public List<Canal> listarTodos() {
        return canalBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public Canal buscarPorId(@PathParam("id") int id) {
        return canalBO.buscarPorId(id);
    }

    @POST
    public int insertar(Canal elemento) {
        return canalBO.insertar(elemento);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, Canal elemento) {
        elemento.setId(id);
        return canalBO.modificar(elemento);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return canalBO.eliminar(id);
    }
}
