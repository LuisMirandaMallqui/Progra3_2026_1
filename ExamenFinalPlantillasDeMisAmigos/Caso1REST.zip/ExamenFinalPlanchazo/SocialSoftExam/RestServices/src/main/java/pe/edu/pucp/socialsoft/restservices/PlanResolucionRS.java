package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.PlanResolucionBO;
import pe.edu.pucp.socialsoft.business.implementsBO.PlanResolucionImplementsBO;
import pe.edu.pucp.socialsoft.model.PlanResolucion;

import java.util.List;

@Path("plan-resoluciones")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PlanResolucionRS {

    private PlanResolucionBO planResolucionBO;

    public PlanResolucionRS() {
        planResolucionBO = new PlanResolucionImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de plan-resoluciones funcionando";
    }

    @GET
    public List<PlanResolucion> listarTodos() {
        return planResolucionBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public PlanResolucion buscarPorId(@PathParam("id") int id) {
        return planResolucionBO.buscarPorId(id);
    }

    @POST
    public int insertar(PlanResolucion elemento) {
        return planResolucionBO.insertar(elemento);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, PlanResolucion elemento) {
        elemento.setId(id);
        return planResolucionBO.modificar(elemento);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return planResolucionBO.eliminar(id);
    }
}
