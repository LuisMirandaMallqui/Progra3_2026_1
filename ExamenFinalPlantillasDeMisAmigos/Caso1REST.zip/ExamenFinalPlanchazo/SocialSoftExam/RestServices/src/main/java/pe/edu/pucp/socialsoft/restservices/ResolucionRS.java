package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.ResolucionBO;
import pe.edu.pucp.socialsoft.business.implementsBO.ResolucionImplementsBO;
import pe.edu.pucp.socialsoft.model.Resolucion;

import java.util.List;

@Path("resoluciones")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ResolucionRS {

    private ResolucionBO resolucionBO;

    public ResolucionRS() {
        resolucionBO = new ResolucionImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de resoluciones funcionando";
    }

    @GET
    public List<Resolucion> listarTodos() {
        return resolucionBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public Resolucion buscarPorId(@PathParam("id") int id) {
        return resolucionBO.buscarPorId(id);
    }

    @POST
    public int insertar(Resolucion elemento) {
        return resolucionBO.insertar(elemento);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, Resolucion elemento) {
        elemento.setId(id);
        return resolucionBO.modificar(elemento);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return resolucionBO.eliminar(id);
    }
}
