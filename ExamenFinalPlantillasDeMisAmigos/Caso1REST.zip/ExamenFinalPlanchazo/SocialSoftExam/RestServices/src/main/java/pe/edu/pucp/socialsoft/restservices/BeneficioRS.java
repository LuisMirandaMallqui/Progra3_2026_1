package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.BeneficioBO;
import pe.edu.pucp.socialsoft.business.implementsBO.BeneficioImplementsBO;
import pe.edu.pucp.socialsoft.model.Beneficio;

import java.util.List;

@Path("beneficios")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BeneficioRS {

    private BeneficioBO beneficioBO;

    public BeneficioRS() {
        beneficioBO = new BeneficioImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de beneficios funcionando";
    }

    @GET
    public List<Beneficio> listarTodos() {
        return beneficioBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public Beneficio buscarPorId(@PathParam("id") int id) {
        return beneficioBO.buscarPorId(id);
    }

    @POST
    public int insertar(Beneficio elemento) {
        return beneficioBO.insertar(elemento);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, Beneficio elemento) {
        elemento.setId(id);
        return beneficioBO.modificar(elemento);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return beneficioBO.eliminar(id);
    }
}
