package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.UsuarioBO;
import pe.edu.pucp.socialsoft.business.implementsBO.UsuarioImplementsBO;
import pe.edu.pucp.socialsoft.model.Usuario;

import java.util.List;

@Path("usuarios")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UsuarioRS {

    private UsuarioBO usuarioBO;

    public UsuarioRS() {
        usuarioBO = new UsuarioImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de usuarios funcionando";
    }

    @GET
    public List<Usuario> listarTodos() {
        return usuarioBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public Usuario buscarPorId(@PathParam("id") int id) {
        return usuarioBO.buscarPorId(id);
    }

    @POST
    public int insertar(Usuario usuario) {
        return usuarioBO.insertar(usuario);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, Usuario usuario) {
        usuario.setId(id);
        return usuarioBO.modificar(usuario);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return usuarioBO.eliminar(id);
    }
}