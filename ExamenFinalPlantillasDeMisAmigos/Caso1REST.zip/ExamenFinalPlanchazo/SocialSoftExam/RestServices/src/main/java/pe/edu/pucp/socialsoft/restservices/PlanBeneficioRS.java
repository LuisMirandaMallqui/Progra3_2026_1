package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.PlanBeneficioBO;
import pe.edu.pucp.socialsoft.business.implementsBO.PlanBeneficioImplementsBO;
import pe.edu.pucp.socialsoft.model.PlanBeneficio;

import java.util.List;

@Path("plan-beneficios")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PlanBeneficioRS {

    private PlanBeneficioBO planBeneficioBO;

    public PlanBeneficioRS() {
        planBeneficioBO = new PlanBeneficioImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de plan-beneficios funcionando";
    }

    @GET
    public List<PlanBeneficio> listarTodos() {
        return planBeneficioBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public PlanBeneficio buscarPorId(@PathParam("id") int id) {
        return planBeneficioBO.buscarPorId(id);
    }

    @POST
    public int insertar(PlanBeneficio elemento) {
        return planBeneficioBO.insertar(elemento);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, PlanBeneficio elemento) {
        elemento.setId(id);
        return planBeneficioBO.modificar(elemento);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return planBeneficioBO.eliminar(id);
    }
}
