package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.PagoSuscripcionBO;
import pe.edu.pucp.socialsoft.business.implementsBO.PagoSuscripcionImplementsBO;
import pe.edu.pucp.socialsoft.model.PagoSuscripcion;

import java.util.List;

@Path("pagos-suscripcion")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PagoSuscripcionRS {

    private PagoSuscripcionBO pagoSuscripcionBO;

    public PagoSuscripcionRS() {
        pagoSuscripcionBO = new PagoSuscripcionImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de pagos-suscripcion funcionando";
    }

    @GET
    public List<PagoSuscripcion> listarTodos() {
        return pagoSuscripcionBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public PagoSuscripcion buscarPorId(@PathParam("id") int id) {
        return pagoSuscripcionBO.buscarPorId(id);
    }

    @POST
    public int insertar(PagoSuscripcion elemento) {
        return pagoSuscripcionBO.insertar(elemento);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, PagoSuscripcion elemento) {
        elemento.setId(id);
        return pagoSuscripcionBO.modificar(elemento);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return pagoSuscripcionBO.eliminar(id);
    }
}
