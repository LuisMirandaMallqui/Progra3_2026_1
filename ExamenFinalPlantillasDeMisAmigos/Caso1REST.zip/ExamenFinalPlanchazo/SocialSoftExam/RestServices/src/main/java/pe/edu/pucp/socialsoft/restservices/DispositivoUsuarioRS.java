package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.DispositivoUsuarioBO;
import pe.edu.pucp.socialsoft.business.implementsBO.DispositivoUsuarioImplementsBO;
import pe.edu.pucp.socialsoft.model.DispositivoUsuario;

import java.util.List;

@Path("dispositivos-usuario")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class DispositivoUsuarioRS {

    private DispositivoUsuarioBO dispositivoUsuarioBO;

    public DispositivoUsuarioRS() {
        dispositivoUsuarioBO = new DispositivoUsuarioImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de dispositivos-usuario funcionando";
    }

    @GET
    public List<DispositivoUsuario> listarTodos() {
        return dispositivoUsuarioBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public DispositivoUsuario buscarPorId(@PathParam("id") int id) {
        return dispositivoUsuarioBO.buscarPorId(id);
    }

    @POST
    public int insertar(DispositivoUsuario elemento) {
        return dispositivoUsuarioBO.insertar(elemento);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, DispositivoUsuario elemento) {
        elemento.setId(id);
        return dispositivoUsuarioBO.modificar(elemento);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return dispositivoUsuarioBO.eliminar(id);
    }
}
