package pe.edu.pucp.socialsoft.restservices;
import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("webservices")
public class RestApplication extends Application {

}
