package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.UsuarioCanalSuscripcionBO;
import pe.edu.pucp.socialsoft.business.implementsBO.UsuarioCanalSuscripcionImplementsBO;
import pe.edu.pucp.socialsoft.model.UsuarioCanalSuscripcion;

import java.util.List;

@Path("suscripciones")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UsuarioCanalSuscripcionRS {

    private UsuarioCanalSuscripcionBO usuarioCanalSuscripcionBO;

    public UsuarioCanalSuscripcionRS() {
        usuarioCanalSuscripcionBO = new UsuarioCanalSuscripcionImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de suscripciones funcionando";
    }

    @GET
    public List<UsuarioCanalSuscripcion> listarTodos() {
        return usuarioCanalSuscripcionBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public UsuarioCanalSuscripcion buscarPorId(@PathParam("id") int id) {
        return usuarioCanalSuscripcionBO.buscarPorId(id);
    }

    @POST
    public int insertar(UsuarioCanalSuscripcion elemento) {
        return usuarioCanalSuscripcionBO.insertar(elemento);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, UsuarioCanalSuscripcion elemento) {
        elemento.setId(id);
        return usuarioCanalSuscripcionBO.modificar(elemento);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return usuarioCanalSuscripcionBO.eliminar(id);
    }
}
