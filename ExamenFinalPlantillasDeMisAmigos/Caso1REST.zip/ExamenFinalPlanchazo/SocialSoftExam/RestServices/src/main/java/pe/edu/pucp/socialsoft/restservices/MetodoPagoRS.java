package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.MetodoPagoBO;
import pe.edu.pucp.socialsoft.business.implementsBO.MetodoPagoImplementsBO;
import pe.edu.pucp.socialsoft.model.MetodoPago;

import java.util.List;

@Path("metodos-pago")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MetodoPagoRS {

    private MetodoPagoBO metodoPagoBO;

    public MetodoPagoRS() {
        metodoPagoBO = new MetodoPagoImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de metodos-pago funcionando";
    }

    @GET
    public List<MetodoPago> listarTodos() {
        return metodoPagoBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public MetodoPago buscarPorId(@PathParam("id") int id) {
        return metodoPagoBO.buscarPorId(id);
    }

    @POST
    public int insertar(MetodoPago elemento) {
        return metodoPagoBO.insertar(elemento);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, MetodoPago elemento) {
        elemento.setId(id);
        return metodoPagoBO.modificar(elemento);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return metodoPagoBO.eliminar(id);
    }
}
