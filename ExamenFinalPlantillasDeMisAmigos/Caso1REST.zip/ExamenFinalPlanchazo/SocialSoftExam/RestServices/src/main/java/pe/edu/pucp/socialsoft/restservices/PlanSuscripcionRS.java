package pe.edu.pucp.socialsoft.restservices;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import pe.edu.pucp.socialsoft.business.PlanSuscripcionBO;
import pe.edu.pucp.socialsoft.business.implementsBO.PlanSuscripcionImplementsBO;
import pe.edu.pucp.socialsoft.model.PlanSuscripcion;

import java.util.List;

@Path("planes-suscripcion")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PlanSuscripcionRS {

    private PlanSuscripcionBO planSuscripcionBO;

    public PlanSuscripcionRS() {
        planSuscripcionBO = new PlanSuscripcionImplementsBO();
    }

    @GET
    @Path("ping")
    @Produces(MediaType.TEXT_PLAIN)
    public String ping() {
        return "REST de planes-suscripcion funcionando";
    }

    @GET
    public List<PlanSuscripcion> listarTodos() {
        return planSuscripcionBO.listarTodos();
    }

    @GET
    @Path("{id}")
    public PlanSuscripcion buscarPorId(@PathParam("id") int id) {
        return planSuscripcionBO.buscarPorId(id);
    }

    @POST
    public int insertar(PlanSuscripcion elemento) {
        return planSuscripcionBO.insertar(elemento);
    }

    @PUT
    @Path("{id}")
    public int modificar(@PathParam("id") int id, PlanSuscripcion elemento) {
        elemento.setId(id);
        return planSuscripcionBO.modificar(elemento);
    }

    @DELETE
    @Path("{id}")
    public int eliminar(@PathParam("id") int id) {
        return planSuscripcionBO.eliminar(id);
    }
}
