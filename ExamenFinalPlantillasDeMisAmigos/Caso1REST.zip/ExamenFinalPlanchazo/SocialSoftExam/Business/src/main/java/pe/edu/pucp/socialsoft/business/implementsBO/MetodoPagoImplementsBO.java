package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.MetodoPagoBO;
import pe.edu.pucp.socialsoft.model.MetodoPago;
import pe.edu.pucp.socialsoft.dao.MetodoPagoDAO;
import pe.edu.pucp.socialsoft.impl.MetodoPagoDAOImpl;

public class MetodoPagoImplementsBO implements MetodoPagoBO {

    // Creamos referencia al DAO
    private MetodoPagoDAO metodoPagoDAO;

    public MetodoPagoImplementsBO() {
        metodoPagoDAO = new MetodoPagoDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(MetodoPago elemento) {
        try {
            Integer idGenerado = metodoPagoDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(MetodoPago elemento) {
        try {
            return metodoPagoDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return metodoPagoDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public MetodoPago buscarPorId(int idElemento) {
        try {
            return metodoPagoDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<MetodoPago> listarTodos() {
        try {
            return metodoPagoDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
