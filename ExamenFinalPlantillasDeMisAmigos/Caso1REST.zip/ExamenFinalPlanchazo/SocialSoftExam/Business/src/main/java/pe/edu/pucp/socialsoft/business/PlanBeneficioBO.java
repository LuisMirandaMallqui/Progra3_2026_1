package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.PlanBeneficio;

public interface PlanBeneficioBO extends BaseBO<PlanBeneficio> {
}
