package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.Usuario;

public interface UsuarioBO extends BaseBO<Usuario> {
}
