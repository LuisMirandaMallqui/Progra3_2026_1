package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.MetodoPago;

public interface MetodoPagoBO extends BaseBO<MetodoPago> {
}
