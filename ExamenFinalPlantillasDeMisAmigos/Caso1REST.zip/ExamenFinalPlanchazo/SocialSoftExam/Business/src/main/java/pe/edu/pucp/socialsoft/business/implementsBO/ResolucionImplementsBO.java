package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.ResolucionBO;
import pe.edu.pucp.socialsoft.model.Resolucion;
import pe.edu.pucp.socialsoft.dao.ResolucionDAO;
import pe.edu.pucp.socialsoft.impl.ResolucionDAOImpl;

public class ResolucionImplementsBO implements ResolucionBO {

    // Creamos referencia al DAO
    private ResolucionDAO resolucionDAO;

    public ResolucionImplementsBO() {
        resolucionDAO = new ResolucionDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(Resolucion elemento) {
        try {
            Integer idGenerado = resolucionDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(Resolucion elemento) {
        try {
            return resolucionDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return resolucionDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public Resolucion buscarPorId(int idElemento) {
        try {
            return resolucionDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Resolucion> listarTodos() {
        try {
            return resolucionDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
