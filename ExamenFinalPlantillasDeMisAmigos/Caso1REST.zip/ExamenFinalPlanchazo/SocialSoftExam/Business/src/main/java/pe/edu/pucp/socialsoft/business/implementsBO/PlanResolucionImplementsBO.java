package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.PlanResolucionBO;
import pe.edu.pucp.socialsoft.model.PlanResolucion;
import pe.edu.pucp.socialsoft.dao.PlanResolucionDAO;
import pe.edu.pucp.socialsoft.impl.PlanResolucionDAOImpl;

public class PlanResolucionImplementsBO implements PlanResolucionBO {

    // Creamos referencia al DAO
    private PlanResolucionDAO planResolucionDAO;

    public PlanResolucionImplementsBO() {
        planResolucionDAO = new PlanResolucionDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(PlanResolucion elemento) {
        try {
            Integer idGenerado = planResolucionDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(PlanResolucion elemento) {
        try {
            return planResolucionDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return planResolucionDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public PlanResolucion buscarPorId(int idElemento) {
        try {
            return planResolucionDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<PlanResolucion> listarTodos() {
        try {
            return planResolucionDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
