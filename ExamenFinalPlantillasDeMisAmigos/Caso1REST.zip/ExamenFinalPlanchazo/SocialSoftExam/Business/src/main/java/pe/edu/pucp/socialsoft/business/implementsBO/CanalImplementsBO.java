package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.CanalBO;
import pe.edu.pucp.socialsoft.model.Canal;
import pe.edu.pucp.socialsoft.dao.CanalDAO;
import pe.edu.pucp.socialsoft.impl.CanalDAOImpl;

public class CanalImplementsBO implements CanalBO {

    // Creamos referencia al DAO
    private CanalDAO canalDAO;

    public CanalImplementsBO() {
        canalDAO = new CanalDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(Canal elemento) {
        try {
            Integer idGenerado = canalDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(Canal elemento) {
        try {
            return canalDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return canalDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public Canal buscarPorId(int idElemento) {
        try {
            return canalDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Canal> listarTodos() {
        try {
            return canalDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
