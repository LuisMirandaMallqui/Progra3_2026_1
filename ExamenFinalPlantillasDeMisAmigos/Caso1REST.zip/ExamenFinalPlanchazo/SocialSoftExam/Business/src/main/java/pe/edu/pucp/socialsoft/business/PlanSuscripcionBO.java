package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.PlanSuscripcion;

public interface PlanSuscripcionBO extends BaseBO<PlanSuscripcion> {
}
