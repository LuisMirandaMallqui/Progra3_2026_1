package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.UsuarioCanalSuscripcion;

public interface UsuarioCanalSuscripcionBO extends BaseBO<UsuarioCanalSuscripcion> {
}
