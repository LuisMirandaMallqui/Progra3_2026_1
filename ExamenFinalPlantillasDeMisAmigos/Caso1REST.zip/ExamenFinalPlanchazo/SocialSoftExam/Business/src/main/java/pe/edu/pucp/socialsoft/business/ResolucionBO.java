package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.Resolucion;

public interface ResolucionBO extends BaseBO<Resolucion> {
}
