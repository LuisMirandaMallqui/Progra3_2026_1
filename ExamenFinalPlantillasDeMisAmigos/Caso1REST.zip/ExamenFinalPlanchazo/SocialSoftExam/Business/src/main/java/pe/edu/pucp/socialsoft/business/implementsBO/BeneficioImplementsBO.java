package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.BeneficioBO;
import pe.edu.pucp.socialsoft.model.Beneficio;
import pe.edu.pucp.socialsoft.dao.BeneficioDAO;
import pe.edu.pucp.socialsoft.impl.BeneficioDAOImpl;

public class BeneficioImplementsBO implements BeneficioBO {

    // Creamos referencia al DAO
    private BeneficioDAO beneficioDAO;

    public BeneficioImplementsBO() {
        beneficioDAO = new BeneficioDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(Beneficio elemento) {
        try {
            Integer idGenerado = beneficioDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(Beneficio elemento) {
        try {
            return beneficioDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return beneficioDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public Beneficio buscarPorId(int idElemento) {
        try {
            return beneficioDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Beneficio> listarTodos() {
        try {
            return beneficioDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
