package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.Beneficio;

public interface BeneficioBO extends BaseBO<Beneficio> {
}
