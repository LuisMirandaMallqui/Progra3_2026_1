package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.DispositivoUsuario;

public interface DispositivoUsuarioBO extends BaseBO<DispositivoUsuario> {
}
