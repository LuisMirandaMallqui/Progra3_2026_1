package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.Canal;

public interface CanalBO extends BaseBO<Canal> {
}
