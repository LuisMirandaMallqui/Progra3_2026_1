package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.PagoSuscripcionBO;
import pe.edu.pucp.socialsoft.model.PagoSuscripcion;
import pe.edu.pucp.socialsoft.dao.PagoSuscripcionDAO;
import pe.edu.pucp.socialsoft.impl.PagoSuscripcionDAOImpl;

public class PagoSuscripcionImplementsBO implements PagoSuscripcionBO {

    // Creamos referencia al DAO
    private PagoSuscripcionDAO pagoSuscripcionDAO;

    public PagoSuscripcionImplementsBO() {
        pagoSuscripcionDAO = new PagoSuscripcionDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(PagoSuscripcion elemento) {
        try {
            Integer idGenerado = pagoSuscripcionDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(PagoSuscripcion elemento) {
        try {
            return pagoSuscripcionDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return pagoSuscripcionDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public PagoSuscripcion buscarPorId(int idElemento) {
        try {
            return pagoSuscripcionDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<PagoSuscripcion> listarTodos() {
        try {
            return pagoSuscripcionDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
