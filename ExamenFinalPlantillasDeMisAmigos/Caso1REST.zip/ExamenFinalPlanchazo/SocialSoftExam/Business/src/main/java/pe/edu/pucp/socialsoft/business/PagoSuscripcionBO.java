package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.PagoSuscripcion;

public interface PagoSuscripcionBO extends BaseBO<PagoSuscripcion> {
}
