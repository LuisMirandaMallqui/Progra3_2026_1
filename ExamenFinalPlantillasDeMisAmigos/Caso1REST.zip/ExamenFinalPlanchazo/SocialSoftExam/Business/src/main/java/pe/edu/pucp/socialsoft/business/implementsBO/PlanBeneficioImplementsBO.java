package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.PlanBeneficioBO;
import pe.edu.pucp.socialsoft.model.PlanBeneficio;
import pe.edu.pucp.socialsoft.dao.PlanBeneficioDAO;
import pe.edu.pucp.socialsoft.impl.PlanBeneficioDAOImpl;

public class PlanBeneficioImplementsBO implements PlanBeneficioBO {

    // Creamos referencia al DAO
    private PlanBeneficioDAO planBeneficioDAO;

    public PlanBeneficioImplementsBO() {
        planBeneficioDAO = new PlanBeneficioDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(PlanBeneficio elemento) {
        try {
            Integer idGenerado = planBeneficioDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(PlanBeneficio elemento) {
        try {
            return planBeneficioDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return planBeneficioDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public PlanBeneficio buscarPorId(int idElemento) {
        try {
            return planBeneficioDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<PlanBeneficio> listarTodos() {
        try {
            return planBeneficioDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
