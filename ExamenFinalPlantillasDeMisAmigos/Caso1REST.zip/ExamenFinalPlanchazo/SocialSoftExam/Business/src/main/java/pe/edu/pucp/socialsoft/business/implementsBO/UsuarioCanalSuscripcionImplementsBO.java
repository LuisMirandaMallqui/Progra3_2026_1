package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.UsuarioCanalSuscripcionBO;
import pe.edu.pucp.socialsoft.model.UsuarioCanalSuscripcion;
import pe.edu.pucp.socialsoft.dao.UsuarioCanalSuscripcionDAO;
import pe.edu.pucp.socialsoft.impl.UsuarioCanalSuscripcionDAOImpl;

public class UsuarioCanalSuscripcionImplementsBO implements UsuarioCanalSuscripcionBO {

    // Creamos referencia al DAO
    private UsuarioCanalSuscripcionDAO usuarioCanalSuscripcionDAO;

    public UsuarioCanalSuscripcionImplementsBO() {
        usuarioCanalSuscripcionDAO = new UsuarioCanalSuscripcionDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(UsuarioCanalSuscripcion elemento) {
        try {
            Integer idGenerado = usuarioCanalSuscripcionDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(UsuarioCanalSuscripcion elemento) {
        try {
            return usuarioCanalSuscripcionDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return usuarioCanalSuscripcionDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public UsuarioCanalSuscripcion buscarPorId(int idElemento) {
        try {
            return usuarioCanalSuscripcionDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<UsuarioCanalSuscripcion> listarTodos() {
        try {
            return usuarioCanalSuscripcionDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
