package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.PlanSuscripcionBO;
import pe.edu.pucp.socialsoft.model.PlanSuscripcion;
import pe.edu.pucp.socialsoft.dao.PlanSuscripcionDAO;
import pe.edu.pucp.socialsoft.impl.PlanSuscripcionDAOImpl;

public class PlanSuscripcionImplementsBO implements PlanSuscripcionBO {

    // Creamos referencia al DAO
    private PlanSuscripcionDAO planSuscripcionDAO;

    public PlanSuscripcionImplementsBO() {
        planSuscripcionDAO = new PlanSuscripcionDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(PlanSuscripcion elemento) {
        try {
            Integer idGenerado = planSuscripcionDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(PlanSuscripcion elemento) {
        try {
            return planSuscripcionDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return planSuscripcionDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public PlanSuscripcion buscarPorId(int idElemento) {
        try {
            return planSuscripcionDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<PlanSuscripcion> listarTodos() {
        try {
            return planSuscripcionDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
