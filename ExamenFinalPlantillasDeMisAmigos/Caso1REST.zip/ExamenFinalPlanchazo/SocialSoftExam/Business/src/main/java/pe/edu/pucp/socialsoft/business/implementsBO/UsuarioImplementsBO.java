package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.UsuarioBO;
import pe.edu.pucp.socialsoft.model.Usuario;
import pe.edu.pucp.socialsoft.dao.UsuarioDAO;
import pe.edu.pucp.socialsoft.impl.UsuarioDAOImpl;

public class UsuarioImplementsBO implements UsuarioBO {

    // Creamos referencia al DAO
    private UsuarioDAO usuarioDAO;

    public UsuarioImplementsBO() {
        usuarioDAO = new UsuarioDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(Usuario elemento) {
        try {
            Integer idGenerado = usuarioDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(Usuario elemento) {
        try {
            return usuarioDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return usuarioDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public Usuario buscarPorId(int idElemento) {
        try {
            return usuarioDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Usuario> listarTodos() {
        try {
            return usuarioDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
