package pe.edu.pucp.socialsoft.business.implementsBO;

import java.util.ArrayList;
import java.util.List;
import pe.edu.pucp.socialsoft.business.DispositivoUsuarioBO;
import pe.edu.pucp.socialsoft.model.DispositivoUsuario;
import pe.edu.pucp.socialsoft.dao.DispositivoUsuarioDAO;
import pe.edu.pucp.socialsoft.impl.DispositivoUsuarioDAOImpl;

public class DispositivoUsuarioImplementsBO implements DispositivoUsuarioBO {

    // Creamos referencia al DAO
    private DispositivoUsuarioDAO dispositivoUsuarioDAO;

    public DispositivoUsuarioImplementsBO() {
        dispositivoUsuarioDAO = new DispositivoUsuarioDAOImpl();
    }

    // Métodos heredados de la interfaz implementada
    @Override
    public int insertar(DispositivoUsuario elemento) {
        try {
            Integer idGenerado = dispositivoUsuarioDAO.insertar(elemento);
            return idGenerado != null ? idGenerado : 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificar(DispositivoUsuario elemento) {
        try {
            return dispositivoUsuarioDAO.modificar(elemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public int eliminar(int idElemento) {
        try {
            return dispositivoUsuarioDAO.eliminar(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return 0;
        }
    }

    @Override
    public DispositivoUsuario buscarPorId(int idElemento) {
        try {
            return dispositivoUsuarioDAO.obtenerPorId(idElemento);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    @Override
    public List<DispositivoUsuario> listarTodos() {
        try {
            return dispositivoUsuarioDAO.listarTodos();
        } catch (Exception ex) {
            ex.printStackTrace();
            return new ArrayList<>();
        }
    }
}
