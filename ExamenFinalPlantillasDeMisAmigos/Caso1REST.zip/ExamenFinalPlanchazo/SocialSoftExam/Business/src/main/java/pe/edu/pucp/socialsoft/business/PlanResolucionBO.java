package pe.edu.pucp.socialsoft.business;

import pe.edu.pucp.socialsoft.business.base.BaseBO;
import pe.edu.pucp.socialsoft.model.PlanResolucion;

public interface PlanResolucionBO extends BaseBO<PlanResolucion> {
}
