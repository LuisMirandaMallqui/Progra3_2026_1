package pe.edu.pucp.socialsoft.model;

import java.time.LocalDate;

public class Canal {
    private Integer id;
    private String nombre;
    private String descripcion;
    private LocalDate fechaCreacion;
    private int numeroSeguidores;
    private String categoria;

    public Canal() {
    }

    public Canal(Integer id, String nombre, String descripcion, LocalDate fechaCreacion, int numeroSeguidores, String categoria) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fechaCreacion = fechaCreacion;
        this.numeroSeguidores = numeroSeguidores;
        this.categoria = categoria;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public LocalDate getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDate fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public int getNumeroSeguidores() { return numeroSeguidores; }
    public void setNumeroSeguidores(int numeroSeguidores) { this.numeroSeguidores = numeroSeguidores; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
}
