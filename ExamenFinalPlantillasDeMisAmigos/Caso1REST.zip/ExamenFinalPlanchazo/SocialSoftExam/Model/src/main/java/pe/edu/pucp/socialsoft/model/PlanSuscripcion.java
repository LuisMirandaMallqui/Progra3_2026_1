package pe.edu.pucp.socialsoft.model;

import java.math.BigDecimal;

public class PlanSuscripcion {
    private Integer id;
    private String nombre;
    private BigDecimal costoMensual;

    public PlanSuscripcion() {
    }

    public PlanSuscripcion(Integer id, String nombre, BigDecimal costoMensual) {
        this.id = id;
        this.nombre = nombre;
        this.costoMensual = costoMensual;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public BigDecimal getCostoMensual() { return costoMensual; }
    public void setCostoMensual(BigDecimal costoMensual) { this.costoMensual = costoMensual; }
}
