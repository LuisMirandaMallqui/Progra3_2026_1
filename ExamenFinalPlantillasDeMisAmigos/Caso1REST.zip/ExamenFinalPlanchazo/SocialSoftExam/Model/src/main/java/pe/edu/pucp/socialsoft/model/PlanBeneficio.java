package pe.edu.pucp.socialsoft.model;

public class PlanBeneficio {
    private Integer id;
    private PlanSuscripcion planSuscripcion;
    private Beneficio beneficio;

    public PlanBeneficio() {
    }

    public PlanBeneficio(Integer id, PlanSuscripcion planSuscripcion, Beneficio beneficio) {
        this.id = id;
        this.planSuscripcion = planSuscripcion;
        this.beneficio = beneficio;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public PlanSuscripcion getPlanSuscripcion() { return planSuscripcion; }
    public void setPlanSuscripcion(PlanSuscripcion planSuscripcion) { this.planSuscripcion = planSuscripcion; }

    public Beneficio getBeneficio() { return beneficio; }
    public void setBeneficio(Beneficio beneficio) { this.beneficio = beneficio; }
}
