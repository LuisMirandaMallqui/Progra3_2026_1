package pe.edu.pucp.socialsoft.model;

public class PlanResolucion {
    private Integer id;
    private PlanSuscripcion planSuscripcion;
    private Resolucion resolucion;

    public PlanResolucion() {
    }

    public PlanResolucion(Integer id, PlanSuscripcion planSuscripcion, Resolucion resolucion) {
        this.id = id;
        this.planSuscripcion = planSuscripcion;
        this.resolucion = resolucion;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public PlanSuscripcion getPlanSuscripcion() { return planSuscripcion; }
    public void setPlanSuscripcion(PlanSuscripcion planSuscripcion) { this.planSuscripcion = planSuscripcion; }

    public Resolucion getResolucion() { return resolucion; }
    public void setResolucion(Resolucion resolucion) { this.resolucion = resolucion; }
}
