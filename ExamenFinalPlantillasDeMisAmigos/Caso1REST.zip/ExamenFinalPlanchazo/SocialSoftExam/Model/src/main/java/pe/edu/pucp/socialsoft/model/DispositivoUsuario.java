package pe.edu.pucp.socialsoft.model;

public class DispositivoUsuario {
    private Integer id;
    private Usuario usuario;
    private String nombre;
    private String tipo;
    private String sistemaOperativo;
    private boolean activo;

    public DispositivoUsuario() {
    }

    public DispositivoUsuario(Integer id, Usuario usuario, String nombre, String tipo, String sistemaOperativo, boolean activo) {
        this.id = id;
        this.usuario = usuario;
        this.nombre = nombre;
        this.tipo = tipo;
        this.sistemaOperativo = sistemaOperativo;
        this.activo = activo;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getSistemaOperativo() { return sistemaOperativo; }
    public void setSistemaOperativo(String sistemaOperativo) { this.sistemaOperativo = sistemaOperativo; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
}
