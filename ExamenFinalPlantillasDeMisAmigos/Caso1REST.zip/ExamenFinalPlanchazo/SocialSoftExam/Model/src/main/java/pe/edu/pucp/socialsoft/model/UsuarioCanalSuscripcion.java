package pe.edu.pucp.socialsoft.model;

import java.time.LocalDateTime;

public class UsuarioCanalSuscripcion {
    private Integer id;
    private Usuario usuario;
    private Canal canal;
    private PlanSuscripcion planSuscripcion;
    private LocalDateTime fechaRegistro;
    private String estado;

    public UsuarioCanalSuscripcion() {
    }

    public UsuarioCanalSuscripcion(Integer id, Usuario usuario, Canal canal, PlanSuscripcion planSuscripcion,
                                   LocalDateTime fechaRegistro, String estado) {
        this.id = id;
        this.usuario = usuario;
        this.canal = canal;
        this.planSuscripcion = planSuscripcion;
        this.fechaRegistro = fechaRegistro;
        this.estado = estado;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public Canal getCanal() { return canal; }
    public void setCanal(Canal canal) { this.canal = canal; }

    public PlanSuscripcion getPlanSuscripcion() { return planSuscripcion; }
    public void setPlanSuscripcion(PlanSuscripcion planSuscripcion) { this.planSuscripcion = planSuscripcion; }

    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
