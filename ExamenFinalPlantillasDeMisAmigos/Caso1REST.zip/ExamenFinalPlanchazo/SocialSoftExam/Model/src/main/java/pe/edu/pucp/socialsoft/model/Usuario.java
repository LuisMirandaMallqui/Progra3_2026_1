package pe.edu.pucp.socialsoft.model;

import java.time.LocalDate;

public class Usuario {
    private Integer id;
    private String nombreCompleto;
    private String dni;
    private int edad;
    private String ciudad;
    private LocalDate fechaNacimiento;
    private String telefono;
    private String correo;
    private String profesion;

    public Usuario() {
    }

    public Usuario(Integer id, String nombreCompleto, String dni, int edad, String ciudad,
                   LocalDate fechaNacimiento, String telefono, String correo, String profesion) {
        this.id = id;
        this.nombreCompleto = nombreCompleto;
        this.dni = dni;
        this.edad = edad;
        this.ciudad = ciudad;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correo = correo;
        this.profesion = profesion;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }

    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public int getEdad() { return edad; }
    public void setEdad(int edad) { this.edad = edad; }

    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }

    public LocalDate getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(LocalDate fechaNacimiento) { this.fechaNacimiento = fechaNacimiento; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getProfesion() { return profesion; }
    public void setProfesion(String profesion) { this.profesion = profesion; }
}
