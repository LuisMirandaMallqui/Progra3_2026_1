package pe.edu.pucp.socialsoft.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class PagoSuscripcion {
    private Integer id;
    private UsuarioCanalSuscripcion usuarioCanalSuscripcion;
    private MetodoPago metodoPago;
    private BigDecimal monto;
    private LocalDate fechaPago;
    private String estado;

    public PagoSuscripcion() {
    }

    public PagoSuscripcion(Integer id, UsuarioCanalSuscripcion usuarioCanalSuscripcion, MetodoPago metodoPago,
                           BigDecimal monto, LocalDate fechaPago, String estado) {
        this.id = id;
        this.usuarioCanalSuscripcion = usuarioCanalSuscripcion;
        this.metodoPago = metodoPago;
        this.monto = monto;
        this.fechaPago = fechaPago;
        this.estado = estado;
    }

    public UsuarioCanalSuscripcion getUsuarioCanalSuscripcion() { return usuarioCanalSuscripcion; }
    public void setUsuarioCanalSuscripcion(UsuarioCanalSuscripcion usuarioCanalSuscripcion) { this.usuarioCanalSuscripcion = usuarioCanalSuscripcion; }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public MetodoPago getMetodoPago() { return metodoPago; }
    public void setMetodoPago(MetodoPago metodoPago) { this.metodoPago = metodoPago; }

    public BigDecimal getMonto() { return monto; }
    public void setMonto(BigDecimal monto) { this.monto = monto; }

    public LocalDate getFechaPago() { return fechaPago; }
    public void setFechaPago(LocalDate fechaPago) { this.fechaPago = fechaPago; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
