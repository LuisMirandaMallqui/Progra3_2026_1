package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.MetodoPago;
import pe.edu.pucp.socialsoft.model.PagoSuscripcion;
import pe.edu.pucp.socialsoft.model.UsuarioCanalSuscripcion;
import pe.edu.pucp.socialsoft.dao.PagoSuscripcionDAO;

public class PagoSuscripcionDAOImpl implements PagoSuscripcionDAO {
    @Override
    public Integer insertar(PagoSuscripcion pago) throws Exception {
        String sql = "{ call INSERTAR_PAGO_SUSCRIPCION(?, ?, ?, ?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setInt(2, pago.getUsuarioCanalSuscripcion().getId());
            cs.setInt(3, pago.getMetodoPago().getId());
            cs.setBigDecimal(4, pago.getMonto());
            cs.setDate(5, toSqlDate(pago.getFechaPago()));
            cs.setString(6, pago.getEstado());
            cs.executeUpdate();
            pago.setId(cs.getInt(1));
            return pago.getId();
        }
    }

    @Override
    public int modificar(PagoSuscripcion pago) throws Exception {
        String sql = "{ call MODIFICAR_PAGO_SUSCRIPCION(?, ?, ?, ?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, pago.getId());
            cs.setInt(2, pago.getUsuarioCanalSuscripcion().getId());
            cs.setInt(3, pago.getMetodoPago().getId());
            cs.setBigDecimal(4, pago.getMonto());
            cs.setDate(5, toSqlDate(pago.getFechaPago()));
            cs.setString(6, pago.getEstado());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_PAGO_SUSCRIPCION(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public PagoSuscripcion obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_PAGO_SUSCRIPCION_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<PagoSuscripcion> listarTodos() throws Exception {
        ArrayList<PagoSuscripcion> pagos = new ArrayList<>();
        String sql = "{ call LISTAR_PAGOS_SUSCRIPCION() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) pagos.add(mapear(rs));
        }
        return pagos;
    }

    private PagoSuscripcion mapear(ResultSet rs) throws Exception {
        UsuarioCanalSuscripcion suscripcion = new UsuarioCanalSuscripcion();
        suscripcion.setId(rs.getInt("id_usuario_canal_suscripcion"));
        MetodoPago metodoPago = new MetodoPago();
        metodoPago.setId(rs.getInt("id_metodo_pago"));
        PagoSuscripcion pago = new PagoSuscripcion();
        pago.setId(rs.getInt("id"));
        pago.setUsuarioCanalSuscripcion(suscripcion);
        pago.setMetodoPago(metodoPago);
        pago.setMonto(rs.getBigDecimal("monto"));
        pago.setFechaPago(toLocalDate(rs.getDate("fecha_pago")));
        pago.setEstado(rs.getString("estado"));
        return pago;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

    private Date toSqlDate(LocalDate value) {
        return value == null ? null : Date.valueOf(value);
    }

    private LocalDate toLocalDate(Date value) {
        return value == null ? null : value.toLocalDate();
    }

}
