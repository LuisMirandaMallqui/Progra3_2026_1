package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.Resolucion;
import pe.edu.pucp.socialsoft.dao.ResolucionDAO;

public class ResolucionDAOImpl implements ResolucionDAO {
    @Override
    public Integer insertar(Resolucion resolucion) throws Exception {
        String sql = "{ call INSERTAR_RESOLUCION(?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setString(2, resolucion.getNombre());
            cs.setString(3, resolucion.getDescripcion());
            cs.executeUpdate();
            resolucion.setId(cs.getInt(1));
            return resolucion.getId();
        }
    }

    @Override
    public int modificar(Resolucion resolucion) throws Exception {
        String sql = "{ call MODIFICAR_RESOLUCION(?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, resolucion.getId());
            cs.setString(2, resolucion.getNombre());
            cs.setString(3, resolucion.getDescripcion());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_RESOLUCION(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public Resolucion obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_RESOLUCION_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<Resolucion> listarTodos() throws Exception {
        ArrayList<Resolucion> resoluciones = new ArrayList<>();
        String sql = "{ call LISTAR_RESOLUCIONES() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) resoluciones.add(mapear(rs));
        }
        return resoluciones;
    }

    private Resolucion mapear(ResultSet rs) throws Exception {
        Resolucion resolucion = new Resolucion();
        resolucion.setId(rs.getInt("id"));
        resolucion.setNombre(rs.getString("nombre"));
        resolucion.setDescripcion(rs.getString("descripcion"));
        return resolucion;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

}
