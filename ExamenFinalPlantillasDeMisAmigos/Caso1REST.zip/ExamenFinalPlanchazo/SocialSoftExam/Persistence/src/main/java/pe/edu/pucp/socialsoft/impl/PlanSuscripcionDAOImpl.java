package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.PlanSuscripcion;
import pe.edu.pucp.socialsoft.dao.PlanSuscripcionDAO;

public class PlanSuscripcionDAOImpl implements PlanSuscripcionDAO {
    @Override
    public Integer insertar(PlanSuscripcion plan) throws Exception {
        String sql = "{ call INSERTAR_PLAN_SUSCRIPCION(?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setString(2, plan.getNombre());
            cs.setBigDecimal(3, plan.getCostoMensual());
            cs.executeUpdate();
            plan.setId(cs.getInt(1));
            return plan.getId();
        }
    }

    @Override
    public int modificar(PlanSuscripcion plan) throws Exception {
        String sql = "{ call MODIFICAR_PLAN_SUSCRIPCION(?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, plan.getId());
            cs.setString(2, plan.getNombre());
            cs.setBigDecimal(3, plan.getCostoMensual());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_PLAN_SUSCRIPCION(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public PlanSuscripcion obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_PLAN_SUSCRIPCION_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<PlanSuscripcion> listarTodos() throws Exception {
        ArrayList<PlanSuscripcion> planes = new ArrayList<>();
        String sql = "{ call LISTAR_PLANES_SUSCRIPCION() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) planes.add(mapear(rs));
        }
        return planes;
    }

    private PlanSuscripcion mapear(ResultSet rs) throws Exception {
        PlanSuscripcion plan = new PlanSuscripcion();
        plan.setId(rs.getInt("id"));
        plan.setNombre(rs.getString("nombre"));
        plan.setCostoMensual(rs.getBigDecimal("costo_mensual"));
        return plan;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

}
