package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.MetodoPago;

public interface MetodoPagoDAO extends BaseDAO<MetodoPago> {
}
