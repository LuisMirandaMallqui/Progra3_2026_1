package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.Beneficio;
import pe.edu.pucp.socialsoft.dao.BeneficioDAO;

public class BeneficioDAOImpl implements BeneficioDAO {
    @Override
    public Integer insertar(Beneficio beneficio) throws Exception {
        String sql = "{ call INSERTAR_BENEFICIO(?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setString(2, beneficio.getNombre());
            cs.setString(3, beneficio.getDescripcion());
            cs.executeUpdate();
            beneficio.setId(cs.getInt(1));
            return beneficio.getId();
        }
    }

    @Override
    public int modificar(Beneficio beneficio) throws Exception {
        String sql = "{ call MODIFICAR_BENEFICIO(?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, beneficio.getId());
            cs.setString(2, beneficio.getNombre());
            cs.setString(3, beneficio.getDescripcion());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_BENEFICIO(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public Beneficio obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_BENEFICIO_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<Beneficio> listarTodos() throws Exception {
        ArrayList<Beneficio> beneficios = new ArrayList<>();
        String sql = "{ call LISTAR_BENEFICIOS() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) beneficios.add(mapear(rs));
        }
        return beneficios;
    }

    private Beneficio mapear(ResultSet rs) throws Exception {
        Beneficio beneficio = new Beneficio();
        beneficio.setId(rs.getInt("id"));
        beneficio.setNombre(rs.getString("nombre"));
        beneficio.setDescripcion(rs.getString("descripcion"));
        return beneficio;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

}
