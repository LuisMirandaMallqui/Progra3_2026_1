package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.Beneficio;
import pe.edu.pucp.socialsoft.model.PlanBeneficio;
import pe.edu.pucp.socialsoft.model.PlanSuscripcion;
import pe.edu.pucp.socialsoft.dao.PlanBeneficioDAO;

public class PlanBeneficioDAOImpl implements PlanBeneficioDAO {
    @Override
    public Integer insertar(PlanBeneficio planBeneficio) throws Exception {
        String sql = "{ call INSERTAR_PLAN_BENEFICIO(?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setInt(2, planBeneficio.getPlanSuscripcion().getId());
            cs.setInt(3, planBeneficio.getBeneficio().getId());
            cs.executeUpdate();
            planBeneficio.setId(cs.getInt(1));
            return planBeneficio.getId();
        }
    }

    @Override
    public int modificar(PlanBeneficio planBeneficio) throws Exception {
        String sql = "{ call MODIFICAR_PLAN_BENEFICIO(?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, planBeneficio.getId());
            cs.setInt(2, planBeneficio.getPlanSuscripcion().getId());
            cs.setInt(3, planBeneficio.getBeneficio().getId());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_PLAN_BENEFICIO(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public PlanBeneficio obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_PLAN_BENEFICIO_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<PlanBeneficio> listarTodos() throws Exception {
        ArrayList<PlanBeneficio> relaciones = new ArrayList<>();
        String sql = "{ call LISTAR_PLANES_BENEFICIO() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) relaciones.add(mapear(rs));
        }
        return relaciones;
    }

    private PlanBeneficio mapear(ResultSet rs) throws Exception {
        PlanSuscripcion plan = new PlanSuscripcion();
        plan.setId(rs.getInt("id_plan_suscripcion"));
        Beneficio beneficio = new Beneficio();
        beneficio.setId(rs.getInt("id_beneficio"));
        PlanBeneficio planBeneficio = new PlanBeneficio();
        planBeneficio.setId(rs.getInt("id"));
        planBeneficio.setPlanSuscripcion(plan);
        planBeneficio.setBeneficio(beneficio);
        return planBeneficio;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

}
