package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.PlanResolucion;

public interface PlanResolucionDAO extends BaseDAO<PlanResolucion> {
}
