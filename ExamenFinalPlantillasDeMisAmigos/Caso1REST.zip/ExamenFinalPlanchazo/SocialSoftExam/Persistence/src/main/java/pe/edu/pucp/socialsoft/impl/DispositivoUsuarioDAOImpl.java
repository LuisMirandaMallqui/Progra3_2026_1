package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.DispositivoUsuario;
import pe.edu.pucp.socialsoft.model.Usuario;
import pe.edu.pucp.socialsoft.dao.DispositivoUsuarioDAO;

public class DispositivoUsuarioDAOImpl implements DispositivoUsuarioDAO {
    @Override
    public Integer insertar(DispositivoUsuario dispositivo) throws Exception {
        String sql = "{ call INSERTAR_DISPOSITIVO_USUARIO(?, ?, ?, ?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setInt(2, dispositivo.getUsuario().getId());
            cs.setString(3, dispositivo.getNombre());
            cs.setString(4, dispositivo.getTipo());
            cs.setString(5, dispositivo.getSistemaOperativo());
            cs.setBoolean(6, dispositivo.isActivo());
            cs.executeUpdate();
            dispositivo.setId(cs.getInt(1));
            return dispositivo.getId();
        }
    }

    @Override
    public int modificar(DispositivoUsuario dispositivo) throws Exception {
        String sql = "{ call MODIFICAR_DISPOSITIVO_USUARIO(?, ?, ?, ?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, dispositivo.getId());
            cs.setInt(2, dispositivo.getUsuario().getId());
            cs.setString(3, dispositivo.getNombre());
            cs.setString(4, dispositivo.getTipo());
            cs.setString(5, dispositivo.getSistemaOperativo());
            cs.setBoolean(6, dispositivo.isActivo());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_DISPOSITIVO_USUARIO(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public DispositivoUsuario obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_DISPOSITIVO_USUARIO_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<DispositivoUsuario> listarTodos() throws Exception {
        ArrayList<DispositivoUsuario> dispositivos = new ArrayList<>();
        String sql = "{ call LISTAR_DISPOSITIVOS_USUARIO() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) dispositivos.add(mapear(rs));
        }
        return dispositivos;
    }

    private DispositivoUsuario mapear(ResultSet rs) throws Exception {
        Usuario usuario = new Usuario();
        usuario.setId(rs.getInt("id_usuario"));
        DispositivoUsuario dispositivo = new DispositivoUsuario();
        dispositivo.setId(rs.getInt("id"));
        dispositivo.setUsuario(usuario);
        dispositivo.setNombre(rs.getString("nombre"));
        dispositivo.setTipo(rs.getString("tipo"));
        dispositivo.setSistemaOperativo(rs.getString("sistema_operativo"));
        dispositivo.setActivo(rs.getBoolean("activo"));
        return dispositivo;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

}
