package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.MetodoPago;
import pe.edu.pucp.socialsoft.dao.MetodoPagoDAO;

public class MetodoPagoDAOImpl implements MetodoPagoDAO {
    @Override
    public Integer insertar(MetodoPago metodoPago) throws Exception {
        String sql = "{ call INSERTAR_METODO_PAGO(?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setString(2, metodoPago.getNombre());
            cs.executeUpdate();
            metodoPago.setId(cs.getInt(1));
            return metodoPago.getId();
        }
    }

    @Override
    public int modificar(MetodoPago metodoPago) throws Exception {
        String sql = "{ call MODIFICAR_METODO_PAGO(?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, metodoPago.getId());
            cs.setString(2, metodoPago.getNombre());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_METODO_PAGO(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public MetodoPago obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_METODO_PAGO_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<MetodoPago> listarTodos() throws Exception {
        ArrayList<MetodoPago> metodos = new ArrayList<>();
        String sql = "{ call LISTAR_METODOS_PAGO() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) metodos.add(mapear(rs));
        }
        return metodos;
    }

    private MetodoPago mapear(ResultSet rs) throws Exception {
        MetodoPago metodoPago = new MetodoPago();
        metodoPago.setId(rs.getInt("id"));
        metodoPago.setNombre(rs.getString("nombre"));
        return metodoPago;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

}
