package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.Usuario;
import pe.edu.pucp.socialsoft.dao.UsuarioDAO;

public class UsuarioDAOImpl implements UsuarioDAO {
    @Override
    public Integer insertar(Usuario usuario) throws Exception {
        String sql = "{ call INSERTAR_USUARIO(?, ?, ?, ?, ?, ?, ?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setString(2, usuario.getNombreCompleto());
            cs.setString(3, usuario.getDni());
            cs.setInt(4, usuario.getEdad());
            cs.setString(5, usuario.getCiudad());
            cs.setDate(6, toSqlDate(usuario.getFechaNacimiento()));
            cs.setString(7, usuario.getTelefono());
            cs.setString(8, usuario.getCorreo());
            cs.setString(9, usuario.getProfesion());
            cs.executeUpdate();
            usuario.setId(cs.getInt(1));
            return usuario.getId();
        }
    }

    @Override
    public int modificar(Usuario usuario) throws Exception {
        String sql = "{ call MODIFICAR_USUARIO(?, ?, ?, ?, ?, ?, ?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, usuario.getId());
            cs.setString(2, usuario.getNombreCompleto());
            cs.setString(3, usuario.getDni());
            cs.setInt(4, usuario.getEdad());
            cs.setString(5, usuario.getCiudad());
            cs.setDate(6, toSqlDate(usuario.getFechaNacimiento()));
            cs.setString(7, usuario.getTelefono());
            cs.setString(8, usuario.getCorreo());
            cs.setString(9, usuario.getProfesion());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_USUARIO(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public Usuario obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_USUARIO_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<Usuario> listarTodos() throws Exception {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        String sql = "{ call LISTAR_USUARIOS() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) usuarios.add(mapear(rs));
        }
        return usuarios;
    }

    private Usuario mapear(ResultSet rs) throws Exception {
        Usuario usuario = new Usuario();
        usuario.setId(rs.getInt("id"));
        usuario.setNombreCompleto(rs.getString("nombre_completo"));
        usuario.setDni(rs.getString("dni"));
        usuario.setEdad(rs.getInt("edad"));
        usuario.setCiudad(rs.getString("ciudad"));
        usuario.setFechaNacimiento(toLocalDate(rs.getDate("fecha_nacimiento")));
        usuario.setTelefono(rs.getString("telefono"));
        usuario.setCorreo(rs.getString("correo"));
        usuario.setProfesion(rs.getString("profesion"));
        return usuario;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

    private Date toSqlDate(LocalDate value) {
        return value == null ? null : Date.valueOf(value);
    }

    private LocalDate toLocalDate(Date value) {
        return value == null ? null : value.toLocalDate();
    }

}
