package pe.edu.pucp.socialsoft.baseDAO;

import java.util.ArrayList;

public interface BaseDAO<T> {
    Integer insertar(T modelo) throws Exception;
    int modificar(T modelo) throws Exception;
    int eliminar(int id) throws Exception;
    T obtenerPorId(int id) throws Exception;
    ArrayList<T> listarTodos() throws Exception;
}
