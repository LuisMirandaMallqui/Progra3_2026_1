package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.PlanResolucion;
import pe.edu.pucp.socialsoft.model.PlanSuscripcion;
import pe.edu.pucp.socialsoft.model.Resolucion;
import pe.edu.pucp.socialsoft.dao.PlanResolucionDAO;

public class PlanResolucionDAOImpl implements PlanResolucionDAO {
    @Override
    public Integer insertar(PlanResolucion planResolucion) throws Exception {
        String sql = "{ call INSERTAR_PLAN_RESOLUCION(?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setInt(2, planResolucion.getPlanSuscripcion().getId());
            cs.setInt(3, planResolucion.getResolucion().getId());
            cs.executeUpdate();
            planResolucion.setId(cs.getInt(1));
            return planResolucion.getId();
        }
    }

    @Override
    public int modificar(PlanResolucion planResolucion) throws Exception {
        String sql = "{ call MODIFICAR_PLAN_RESOLUCION(?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, planResolucion.getId());
            cs.setInt(2, planResolucion.getPlanSuscripcion().getId());
            cs.setInt(3, planResolucion.getResolucion().getId());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_PLAN_RESOLUCION(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public PlanResolucion obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_PLAN_RESOLUCION_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<PlanResolucion> listarTodos() throws Exception {
        ArrayList<PlanResolucion> relaciones = new ArrayList<>();
        String sql = "{ call LISTAR_PLANES_RESOLUCION() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) relaciones.add(mapear(rs));
        }
        return relaciones;
    }

    private PlanResolucion mapear(ResultSet rs) throws Exception {
        PlanSuscripcion plan = new PlanSuscripcion();
        plan.setId(rs.getInt("id_plan_suscripcion"));
        Resolucion resolucion = new Resolucion();
        resolucion.setId(rs.getInt("id_resolucion"));
        PlanResolucion planResolucion = new PlanResolucion();
        planResolucion.setId(rs.getInt("id"));
        planResolucion.setPlanSuscripcion(plan);
        planResolucion.setResolucion(resolucion);
        return planResolucion;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

}
