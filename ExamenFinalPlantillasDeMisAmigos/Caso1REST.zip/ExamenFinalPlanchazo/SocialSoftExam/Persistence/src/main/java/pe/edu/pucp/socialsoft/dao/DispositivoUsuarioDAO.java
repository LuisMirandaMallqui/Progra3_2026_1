package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.DispositivoUsuario;

public interface DispositivoUsuarioDAO extends BaseDAO<DispositivoUsuario> {
}
