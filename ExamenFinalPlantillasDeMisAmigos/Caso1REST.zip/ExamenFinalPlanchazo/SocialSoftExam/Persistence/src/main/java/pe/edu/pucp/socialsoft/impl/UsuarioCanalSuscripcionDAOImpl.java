package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Timestamp;
import java.sql.ResultSet;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.Canal;
import pe.edu.pucp.socialsoft.model.PlanSuscripcion;
import pe.edu.pucp.socialsoft.model.Usuario;
import pe.edu.pucp.socialsoft.model.UsuarioCanalSuscripcion;
import pe.edu.pucp.socialsoft.dao.UsuarioCanalSuscripcionDAO;

public class UsuarioCanalSuscripcionDAOImpl implements UsuarioCanalSuscripcionDAO {
    @Override
    public Integer insertar(UsuarioCanalSuscripcion suscripcion) throws Exception {
        String sql = "{ call INSERTAR_USUARIO_CANAL_SUSCRIPCION(?, ?, ?, ?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setInt(2, suscripcion.getUsuario().getId());
            cs.setInt(3, suscripcion.getCanal().getId());
            cs.setInt(4, suscripcion.getPlanSuscripcion().getId());
            cs.setTimestamp(5, toSqlTimestamp(suscripcion.getFechaRegistro()));
            cs.setString(6, suscripcion.getEstado());
            cs.executeUpdate();
            suscripcion.setId(cs.getInt(1));
            return suscripcion.getId();
        }
    }

    @Override
    public int modificar(UsuarioCanalSuscripcion suscripcion) throws Exception {
        String sql = "{ call MODIFICAR_USUARIO_CANAL_SUSCRIPCION(?, ?, ?, ?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, suscripcion.getId());
            cs.setInt(2, suscripcion.getUsuario().getId());
            cs.setInt(3, suscripcion.getCanal().getId());
            cs.setInt(4, suscripcion.getPlanSuscripcion().getId());
            cs.setTimestamp(5, toSqlTimestamp(suscripcion.getFechaRegistro()));
            cs.setString(6, suscripcion.getEstado());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_USUARIO_CANAL_SUSCRIPCION(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public UsuarioCanalSuscripcion obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_USUARIO_CANAL_SUSCRIPCION_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<UsuarioCanalSuscripcion> listarTodos() throws Exception {
        ArrayList<UsuarioCanalSuscripcion> suscripciones = new ArrayList<>();
        String sql = "{ call LISTAR_USUARIO_CANAL_SUSCRIPCIONES() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) suscripciones.add(mapear(rs));
        }
        return suscripciones;
    }

    private UsuarioCanalSuscripcion mapear(ResultSet rs) throws Exception {
        Usuario usuario = new Usuario();
        usuario.setId(rs.getInt("id_usuario"));
        Canal canal = new Canal();
        canal.setId(rs.getInt("id_canal"));
        PlanSuscripcion plan = new PlanSuscripcion();
        plan.setId(rs.getInt("id_plan_suscripcion"));
        UsuarioCanalSuscripcion suscripcion = new UsuarioCanalSuscripcion();
        suscripcion.setId(rs.getInt("id"));
        suscripcion.setUsuario(usuario);
        suscripcion.setCanal(canal);
        suscripcion.setPlanSuscripcion(plan);
        suscripcion.setFechaRegistro(toLocalDateTime(rs.getTimestamp("fecha_registro")));
        suscripcion.setEstado(rs.getString("estado"));
        return suscripcion;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

    private Timestamp toSqlTimestamp(LocalDateTime value) {
        return value == null ? null : Timestamp.valueOf(value);
    }

    private LocalDateTime toLocalDateTime(Timestamp value) {
        return value == null ? null : value.toLocalDateTime();
    }

}
