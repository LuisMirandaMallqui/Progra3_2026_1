package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.Usuario;

public interface UsuarioDAO extends BaseDAO<Usuario> {
}
