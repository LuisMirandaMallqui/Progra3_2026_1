package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.UsuarioCanalSuscripcion;

public interface UsuarioCanalSuscripcionDAO extends BaseDAO<UsuarioCanalSuscripcion> {
}
