package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.PagoSuscripcion;

public interface PagoSuscripcionDAO extends BaseDAO<PagoSuscripcion> {
}
