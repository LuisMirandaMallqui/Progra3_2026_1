package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.Resolucion;

public interface ResolucionDAO extends BaseDAO<Resolucion> {
}
