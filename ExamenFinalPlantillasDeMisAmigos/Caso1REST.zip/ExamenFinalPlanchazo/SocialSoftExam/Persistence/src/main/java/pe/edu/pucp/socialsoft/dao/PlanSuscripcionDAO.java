package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.PlanSuscripcion;

public interface PlanSuscripcionDAO extends BaseDAO<PlanSuscripcion> {
}
