package pe.edu.pucp.socialsoft.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import pe.edu.pucp.socialsoft.manager.DBManager;
import pe.edu.pucp.socialsoft.model.Canal;
import pe.edu.pucp.socialsoft.dao.CanalDAO;

public class CanalDAOImpl implements CanalDAO {
    @Override
    public Integer insertar(Canal canal) throws Exception {
        String sql = "{ call INSERTAR_CANAL(?, ?, ?, ?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setString(2, canal.getNombre());
            cs.setString(3, canal.getDescripcion());
            cs.setDate(4, toSqlDate(canal.getFechaCreacion()));
            cs.setInt(5, canal.getNumeroSeguidores());
            cs.setString(6, canal.getCategoria());
            cs.executeUpdate();
            canal.setId(cs.getInt(1));
            return canal.getId();
        }
    }

    @Override
    public int modificar(Canal canal) throws Exception {
        String sql = "{ call MODIFICAR_CANAL(?, ?, ?, ?, ?, ?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, canal.getId());
            cs.setString(2, canal.getNombre());
            cs.setString(3, canal.getDescripcion());
            cs.setDate(4, toSqlDate(canal.getFechaCreacion()));
            cs.setInt(5, canal.getNumeroSeguidores());
            cs.setString(6, canal.getCategoria());
            return cs.executeUpdate();
        }
    }

    @Override
    public int eliminar(int id) throws Exception {
        String sql = "{ call ELIMINAR_CANAL(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            return cs.executeUpdate();
        }
    }

    @Override
    public Canal obtenerPorId(int id) throws Exception {
        String sql = "{ call OBTENER_CANAL_X_ID(?) }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql)) {
            cs.setInt(1, id);
            try (ResultSet rs = cs.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    @Override
    public ArrayList<Canal> listarTodos() throws Exception {
        ArrayList<Canal> canales = new ArrayList<>();
        String sql = "{ call LISTAR_CANALES() }";
        try (Connection con = getConnection(); CallableStatement cs = con.prepareCall(sql);
             ResultSet rs = cs.executeQuery()) {
            while (rs.next()) canales.add(mapear(rs));
        }
        return canales;
    }

    private Canal mapear(ResultSet rs) throws Exception {
        Canal canal = new Canal();
        canal.setId(rs.getInt("id"));
        canal.setNombre(rs.getString("nombre"));
        canal.setDescripcion(rs.getString("descripcion"));
        canal.setFechaCreacion(toLocalDate(rs.getDate("fecha_creacion")));
        canal.setNumeroSeguidores(rs.getInt("numero_seguidores"));
        canal.setCategoria(rs.getString("categoria"));
        return canal;
    }
    private Connection getConnection() throws Exception {
        return DBManager.getInstance().getConnection();
    }

    private Date toSqlDate(LocalDate value) {
        return value == null ? null : Date.valueOf(value);
    }

    private LocalDate toLocalDate(Date value) {
        return value == null ? null : value.toLocalDate();
    }

}
