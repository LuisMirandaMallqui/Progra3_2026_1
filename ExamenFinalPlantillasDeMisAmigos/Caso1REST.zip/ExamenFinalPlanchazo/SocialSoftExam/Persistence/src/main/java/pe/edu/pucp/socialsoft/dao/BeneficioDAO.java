package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.Beneficio;

public interface BeneficioDAO extends BaseDAO<Beneficio> {
}
