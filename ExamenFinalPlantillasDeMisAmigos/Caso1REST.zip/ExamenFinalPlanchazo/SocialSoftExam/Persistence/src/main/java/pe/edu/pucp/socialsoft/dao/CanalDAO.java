package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.Canal;

public interface CanalDAO extends BaseDAO<Canal> {
}
