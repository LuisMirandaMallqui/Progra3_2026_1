package pe.edu.pucp.socialsoft.dao;

import pe.edu.pucp.socialsoft.baseDAO.BaseDAO;
import pe.edu.pucp.socialsoft.model.PlanBeneficio;

public interface PlanBeneficioDAO extends BaseDAO<PlanBeneficio> {
}
