using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharpRestClient
{
    public class SocialSoftSOAPManager
    {
        // =========================
        // USUARIOS
        // =========================
        public List<UsuarioDTO> ListarUsuarios()
        {
            UsuarioWSReference.UsuarioWSClient ws = new UsuarioWSReference.UsuarioWSClient();
            var listaSoap = ws.listarUsuarios();

            return (listaSoap ?? Array.Empty<UsuarioWSReference.UsuarioDTO>())
                .Select(ToFront)
                .ToList();
        }

        public UsuarioDTO BuscarUsuarioPorId(int id)
        {
            UsuarioWSReference.UsuarioWSClient ws = new UsuarioWSReference.UsuarioWSClient();
            var usuarioSoap = ws.buscarUsuarioPorId(id);

            return usuarioSoap == null ? new UsuarioDTO() : ToFront(usuarioSoap);
        }

        public int InsertarUsuario(UsuarioDTO usuario)
        {
            UsuarioWSReference.UsuarioWSClient ws = new UsuarioWSReference.UsuarioWSClient();
            return ws.insertarUsuario(ToSoapUsuario(usuario));
        }

        public int ModificarUsuario(UsuarioDTO usuario)
        {
            UsuarioWSReference.UsuarioWSClient ws = new UsuarioWSReference.UsuarioWSClient();
            return ws.modificarUsuario(usuario.Id, ToSoapUsuario(usuario));
        }

        public int EliminarUsuario(int id)
        {
            UsuarioWSReference.UsuarioWSClient ws = new UsuarioWSReference.UsuarioWSClient();
            return ws.eliminarUsuario(id);
        }

        // =========================
        // CANALES
        // =========================
        public List<CanalDTO> ListarCanales()
        {
            CanalWSReference.CanalWSClient ws = new CanalWSReference.CanalWSClient();
            var listaSoap = ws.listarCanales();

            return (listaSoap ?? Array.Empty<CanalWSReference.CanalDTO>())
                .Select(ToFront)
                .ToList();
        }

        public CanalDTO BuscarCanalPorId(int id)
        {
            CanalWSReference.CanalWSClient ws = new CanalWSReference.CanalWSClient();
            var canalSoap = ws.buscarCanalPorId(id);

            return canalSoap == null ? new CanalDTO() : ToFront(canalSoap);
        }

        public int InsertarCanal(CanalDTO canal)
        {
            CanalWSReference.CanalWSClient ws = new CanalWSReference.CanalWSClient();
            return ws.insertarCanal(ToSoapCanal(canal));
        }

        public int ModificarCanal(CanalDTO canal)
        {
            CanalWSReference.CanalWSClient ws = new CanalWSReference.CanalWSClient();
            return ws.modificarCanal(canal.Id, ToSoapCanal(canal));
        }

        public int EliminarCanal(int id)
        {
            CanalWSReference.CanalWSClient ws = new CanalWSReference.CanalWSClient();
            return ws.eliminarCanal(id);
        }

        // =========================
        // PLANES DE SUSCRIPCIÓN
        // =========================
        public List<PlanSuscripcionDTO> ListarPlanes()
        {
            PlanSuscripcionWSReference.PlanSuscripcionWSClient ws =
                new PlanSuscripcionWSReference.PlanSuscripcionWSClient();

            var listaSoap = ws.listarPlanesSuscripcion();

            return (listaSoap ?? Array.Empty<PlanSuscripcionWSReference.PlanSuscripcionDTO>())
                .Select(ToFront)
                .ToList();
        }

        public PlanSuscripcionDTO BuscarPlanPorId(int id)
        {
            PlanSuscripcionWSReference.PlanSuscripcionWSClient ws =
                new PlanSuscripcionWSReference.PlanSuscripcionWSClient();

            var planSoap = ws.buscarPlanSuscripcionPorId(id);

            return planSoap == null ? new PlanSuscripcionDTO() : ToFront(planSoap);
        }

        public int InsertarPlan(PlanSuscripcionDTO plan)
        {
            PlanSuscripcionWSReference.PlanSuscripcionWSClient ws =
                new PlanSuscripcionWSReference.PlanSuscripcionWSClient();

            return ws.insertarPlanSuscripcion(ToSoapPlan(plan));
        }

        public int ModificarPlan(PlanSuscripcionDTO plan)
        {
            PlanSuscripcionWSReference.PlanSuscripcionWSClient ws =
                new PlanSuscripcionWSReference.PlanSuscripcionWSClient();

            return ws.modificarPlanSuscripcion(plan.Id, ToSoapPlan(plan));
        }

        public int EliminarPlan(int id)
        {
            PlanSuscripcionWSReference.PlanSuscripcionWSClient ws =
                new PlanSuscripcionWSReference.PlanSuscripcionWSClient();

            return ws.eliminarPlanSuscripcion(id);
        }

        // =========================
        // RESOLUCIONES
        // =========================
        public List<ResolucionDTO> ListarResoluciones()
        {
            ResolucionWSReference.ResolucionWSClient ws =
                new ResolucionWSReference.ResolucionWSClient();

            var listaSoap = ws.listarResoluciones();

            return (listaSoap ?? Array.Empty<ResolucionWSReference.ResolucionDTO>())
                .Select(ToFront)
                .ToList();
        }

        public ResolucionDTO BuscarResolucionPorId(int id)
        {
            ResolucionWSReference.ResolucionWSClient ws =
                new ResolucionWSReference.ResolucionWSClient();

            var resolucionSoap = ws.buscarResolucionPorId(id);

            return resolucionSoap == null ? new ResolucionDTO() : ToFront(resolucionSoap);
        }

        public int InsertarResolucion(ResolucionDTO resolucion)
        {
            ResolucionWSReference.ResolucionWSClient ws =
                new ResolucionWSReference.ResolucionWSClient();

            return ws.insertarResolucion(ToSoapResolucion(resolucion));
        }

        public int ModificarResolucion(ResolucionDTO resolucion)
        {
            ResolucionWSReference.ResolucionWSClient ws =
                new ResolucionWSReference.ResolucionWSClient();

            return ws.modificarResolucion(resolucion.Id, ToSoapResolucion(resolucion));
        }

        public int EliminarResolucion(int id)
        {
            ResolucionWSReference.ResolucionWSClient ws =
                new ResolucionWSReference.ResolucionWSClient();

            return ws.eliminarResolucion(id);
        }

        // =========================
        // BENEFICIOS
        // =========================
        public List<BeneficioDTO> ListarBeneficios()
        {
            BeneficioWSReference.BeneficioWSClient ws =
                new BeneficioWSReference.BeneficioWSClient();

            var listaSoap = ws.listarBeneficios();

            return (listaSoap ?? Array.Empty<BeneficioWSReference.BeneficioDTO>())
                .Select(ToFront)
                .ToList();
        }

        public BeneficioDTO BuscarBeneficioPorId(int id)
        {
            BeneficioWSReference.BeneficioWSClient ws =
                new BeneficioWSReference.BeneficioWSClient();

            var beneficioSoap = ws.buscarBeneficioPorId(id);

            return beneficioSoap == null ? new BeneficioDTO() : ToFront(beneficioSoap);
        }

        public int InsertarBeneficio(BeneficioDTO beneficio)
        {
            BeneficioWSReference.BeneficioWSClient ws =
                new BeneficioWSReference.BeneficioWSClient();

            return ws.insertarBeneficio(ToSoapBeneficio(beneficio));
        }

        public int ModificarBeneficio(BeneficioDTO beneficio)
        {
            BeneficioWSReference.BeneficioWSClient ws =
                new BeneficioWSReference.BeneficioWSClient();

            return ws.modificarBeneficio(beneficio.Id, ToSoapBeneficio(beneficio));
        }

        public int EliminarBeneficio(int id)
        {
            BeneficioWSReference.BeneficioWSClient ws =
                new BeneficioWSReference.BeneficioWSClient();

            return ws.eliminarBeneficio(id);
        }

        // =========================
        // MÉTODOS DE PAGO
        // =========================
        public List<MetodoPagoDTO> ListarMetodosPago()
        {
            MetodoPagoWSReference.MetodoPagoWSClient ws =
                new MetodoPagoWSReference.MetodoPagoWSClient();

            var listaSoap = ws.listarMetodosPago();

            return (listaSoap ?? Array.Empty<MetodoPagoWSReference.MetodoPagoDTO>())
                .Select(ToFront)
                .ToList();
        }

        public MetodoPagoDTO BuscarMetodoPagoPorId(int id)
        {
            MetodoPagoWSReference.MetodoPagoWSClient ws =
                new MetodoPagoWSReference.MetodoPagoWSClient();

            var metodoSoap = ws.buscarMetodoPagoPorId(id);

            return metodoSoap == null ? new MetodoPagoDTO() : ToFront(metodoSoap);
        }

        public int InsertarMetodoPago(MetodoPagoDTO metodoPago)
        {
            MetodoPagoWSReference.MetodoPagoWSClient ws =
                new MetodoPagoWSReference.MetodoPagoWSClient();

            return ws.insertarMetodoPago(ToSoapMetodoPago(metodoPago));
        }

        public int ModificarMetodoPago(MetodoPagoDTO metodoPago)
        {
            MetodoPagoWSReference.MetodoPagoWSClient ws =
                new MetodoPagoWSReference.MetodoPagoWSClient();

            return ws.modificarMetodoPago(metodoPago.Id, ToSoapMetodoPago(metodoPago));
        }

        public int EliminarMetodoPago(int id)
        {
            MetodoPagoWSReference.MetodoPagoWSClient ws =
                new MetodoPagoWSReference.MetodoPagoWSClient();

            return ws.eliminarMetodoPago(id);
        }

        // =========================
        // SUSCRIPCIONES
        // =========================
        public List<UsuarioCanalSuscripcionDTO> ListarSuscripciones()
        {
            UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionWSClient ws =
                new UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionWSClient();

            var listaSoap = ws.listarUsuarioCanalSuscripciones();

            return (listaSoap ?? Array.Empty<UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionDTO>())
                .Select(ToFront)
                .ToList();
        }

        public UsuarioCanalSuscripcionDTO BuscarSuscripcionPorId(int id)
        {
            UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionWSClient ws =
                new UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionWSClient();

            var suscripcionSoap = ws.buscarUsuarioCanalSuscripcionPorId(id);

            return suscripcionSoap == null ? new UsuarioCanalSuscripcionDTO() : ToFront(suscripcionSoap);
        }

        public int InsertarSuscripcion(UsuarioCanalSuscripcionDTO suscripcion)
        {
            UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionWSClient ws =
                new UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionWSClient();

            return ws.insertarUsuarioCanalSuscripcion(ToSoapSuscripcion(suscripcion));
        }

        public int ModificarSuscripcion(UsuarioCanalSuscripcionDTO suscripcion)
        {
            UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionWSClient ws =
                new UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionWSClient();

            return ws.modificarUsuarioCanalSuscripcion(suscripcion.Id, ToSoapSuscripcion(suscripcion));
        }

        public int EliminarSuscripcion(int id)
        {
            UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionWSClient ws =
                new UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionWSClient();

            return ws.eliminarUsuarioCanalSuscripcion(id);
        }

        // =========================
        // PAGOS
        // =========================
        public List<PagoSuscripcionDTO> ListarPagos()
        {
            PagoSuscripcionWSReference.PagoSuscripcionWSClient ws =
                new PagoSuscripcionWSReference.PagoSuscripcionWSClient();

            var listaSoap = ws.listarPagosSuscripcion();

            return (listaSoap ?? Array.Empty<PagoSuscripcionWSReference.PagoSuscripcionDTO>())
                .Select(ToFront)
                .ToList();
        }

        public PagoSuscripcionDTO BuscarPagoPorId(int id)
        {
            PagoSuscripcionWSReference.PagoSuscripcionWSClient ws =
                new PagoSuscripcionWSReference.PagoSuscripcionWSClient();

            var pagoSoap = ws.buscarPagoSuscripcionPorId(id);

            return pagoSoap == null ? new PagoSuscripcionDTO() : ToFront(pagoSoap);
        }

        public int InsertarPago(PagoSuscripcionDTO pago)
        {
            PagoSuscripcionWSReference.PagoSuscripcionWSClient ws =
                new PagoSuscripcionWSReference.PagoSuscripcionWSClient();

            return ws.insertarPagoSuscripcion(ToSoapPago(pago));
        }

        public int ModificarPago(PagoSuscripcionDTO pago)
        {
            PagoSuscripcionWSReference.PagoSuscripcionWSClient ws =
                new PagoSuscripcionWSReference.PagoSuscripcionWSClient();

            return ws.modificarPagoSuscripcion(pago.Id, ToSoapPago(pago));
        }

        public int EliminarPago(int id)
        {
            PagoSuscripcionWSReference.PagoSuscripcionWSClient ws =
                new PagoSuscripcionWSReference.PagoSuscripcionWSClient();

            return ws.eliminarPagoSuscripcion(id);
        }

        // =========================
        // DISPOSITIVOS
        // =========================
        public List<DispositivoUsuarioDTO> ListarDispositivos()
        {
            DispositivoUsuarioWSReference.DispositivoUsuarioWSClient ws =
                new DispositivoUsuarioWSReference.DispositivoUsuarioWSClient();

            var listaSoap = ws.listarDispositivosUsuario();

            return (listaSoap ?? Array.Empty<DispositivoUsuarioWSReference.DispositivoUsuarioDTO>())
                .Select(ToFront)
                .ToList();
        }

        public DispositivoUsuarioDTO BuscarDispositivoPorId(int id)
        {
            DispositivoUsuarioWSReference.DispositivoUsuarioWSClient ws =
                new DispositivoUsuarioWSReference.DispositivoUsuarioWSClient();

            var dispositivoSoap = ws.buscarDispositivoUsuarioPorId(id);

            return dispositivoSoap == null ? new DispositivoUsuarioDTO() : ToFront(dispositivoSoap);
        }

        public int InsertarDispositivo(DispositivoUsuarioDTO dispositivo)
        {
            DispositivoUsuarioWSReference.DispositivoUsuarioWSClient ws =
                new DispositivoUsuarioWSReference.DispositivoUsuarioWSClient();

            return ws.insertarDispositivoUsuario(ToSoapDispositivo(dispositivo));
        }

        public int ModificarDispositivo(DispositivoUsuarioDTO dispositivo)
        {
            DispositivoUsuarioWSReference.DispositivoUsuarioWSClient ws =
                new DispositivoUsuarioWSReference.DispositivoUsuarioWSClient();

            return ws.modificarDispositivoUsuario(dispositivo.Id, ToSoapDispositivo(dispositivo));
        }

        public int EliminarDispositivo(int id)
        {
            DispositivoUsuarioWSReference.DispositivoUsuarioWSClient ws =
                new DispositivoUsuarioWSReference.DispositivoUsuarioWSClient();

            return ws.eliminarDispositivoUsuario(id);
        }

        // =========================
        // PLAN - BENEFICIO
        // =========================
        public List<PlanBeneficioDTO> ListarPlanBeneficios()
        {
            PlanBeneficioWSReference.PlanBeneficioWSClient ws =
                new PlanBeneficioWSReference.PlanBeneficioWSClient();

            var listaSoap = ws.listarPlanBeneficios();

            return (listaSoap ?? Array.Empty<PlanBeneficioWSReference.PlanBeneficioDTO>())
                .Select(ToFront)
                .ToList();
        }

        public PlanBeneficioDTO BuscarPlanBeneficioPorId(int id)
        {
            PlanBeneficioWSReference.PlanBeneficioWSClient ws =
                new PlanBeneficioWSReference.PlanBeneficioWSClient();

            var planBeneficioSoap = ws.buscarPlanBeneficioPorId(id);

            return planBeneficioSoap == null ? new PlanBeneficioDTO() : ToFront(planBeneficioSoap);
        }

        public int InsertarPlanBeneficio(PlanBeneficioDTO planBeneficio)
        {
            PlanBeneficioWSReference.PlanBeneficioWSClient ws =
                new PlanBeneficioWSReference.PlanBeneficioWSClient();

            return ws.insertarPlanBeneficio(ToSoapPlanBeneficio(planBeneficio));
        }

        public int EliminarPlanBeneficio(int id)
        {
            PlanBeneficioWSReference.PlanBeneficioWSClient ws =
                new PlanBeneficioWSReference.PlanBeneficioWSClient();

            return ws.eliminarPlanBeneficio(id);
        }

        // =========================
        // PLAN - RESOLUCIÓN
        // =========================
        public List<PlanResolucionDTO> ListarPlanResoluciones()
        {
            PlanResolucionWSReference.PlanResolucionWSClient ws =
                new PlanResolucionWSReference.PlanResolucionWSClient();

            var listaSoap = ws.listarPlanResoluciones();

            return (listaSoap ?? Array.Empty<PlanResolucionWSReference.PlanResolucionDTO>())
                .Select(ToFront)
                .ToList();
        }

        public PlanResolucionDTO BuscarPlanResolucionPorId(int id)
        {
            PlanResolucionWSReference.PlanResolucionWSClient ws =
                new PlanResolucionWSReference.PlanResolucionWSClient();

            var planResolucionSoap = ws.buscarPlanResolucionPorId(id);

            return planResolucionSoap == null ? new PlanResolucionDTO() : ToFront(planResolucionSoap);
        }

        public int InsertarPlanResolucion(PlanResolucionDTO planResolucion)
        {
            PlanResolucionWSReference.PlanResolucionWSClient ws =
                new PlanResolucionWSReference.PlanResolucionWSClient();

            return ws.insertarPlanResolucion(ToSoapPlanResolucion(planResolucion));
        }

        public int EliminarPlanResolucion(int id)
        {
            PlanResolucionWSReference.PlanResolucionWSClient ws =
                new PlanResolucionWSReference.PlanResolucionWSClient();

            return ws.eliminarPlanResolucion(id);
        }

        // ===============================================================
        // SOAP -> FRONT
        // ===============================================================

        private UsuarioDTO ToFront(UsuarioWSReference.UsuarioDTO u)
        {
            return new UsuarioDTO
            {
                Id = u.id,
                NombreCompleto = u.nombreCompleto,
                Dni = u.dni,
                Edad = u.edad,
                Correo = u.correo,
                Telefono = u.telefono,
                Ciudad = u.ciudad,
                FechaNacimiento = u.fechaNacimiento,
                Profesion = u.profesion
            };
        }

        private CanalDTO ToFront(CanalWSReference.CanalDTO c)
        {
            return new CanalDTO
            {
                Id = c.id,
                Nombre = c.nombre,
                Descripcion = c.descripcion,
                FechaCreacion = c.fechaCreacion,
                Categoria = c.categoria,
                NumeroSeguidores = c.numeroSeguidores
            };
        }

        private PlanSuscripcionDTO ToFront(PlanSuscripcionWSReference.PlanSuscripcionDTO p)
        {
            return new PlanSuscripcionDTO
            {
                Id = p.id,
                Nombre = p.nombre,
                CostoMensual = Convert.ToDouble(p.costoMensual)
            };
        }

        private ResolucionDTO ToFront(ResolucionWSReference.ResolucionDTO r)
        {
            return new ResolucionDTO
            {
                Id = r.id,
                Nombre = r.nombre
            };
        }

        private BeneficioDTO ToFront(BeneficioWSReference.BeneficioDTO b)
        {
            return new BeneficioDTO
            {
                Id = b.id,
                Nombre = b.nombre,
                Descripcion = b.descripcion
            };
        }

        private MetodoPagoDTO ToFront(MetodoPagoWSReference.MetodoPagoDTO m)
        {
            return new MetodoPagoDTO
            {
                Id = m.id,
                Nombre = m.nombre
            };
        }

        private UsuarioCanalSuscripcionDTO ToFront(
            UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionDTO s)
        {
            return new UsuarioCanalSuscripcionDTO
            {
                Id = s.id,
                FechaRegistro = s.fechaRegistro,
                Estado = s.estado,
                Usuario = new UsuarioDTO
                {
                    Id = s.usuario?.id ?? 0
                },
                Canal = new CanalDTO
                {
                    Id = s.canal?.id ?? 0
                },
                PlanSuscripcion = new PlanSuscripcionDTO
                {
                    Id = s.planSuscripcion?.id ?? 0
                }
            };
        }

        private PagoSuscripcionDTO ToFront(PagoSuscripcionWSReference.PagoSuscripcionDTO p)
        {
            return new PagoSuscripcionDTO
            {
                Id = p.id,
                Monto = Convert.ToDouble(p.monto),
                FechaPago = p.fechaPago,
                Estado = p.estado,
                UsuarioCanalSuscripcion = new UsuarioCanalSuscripcionDTO
                {
                    Id = p.usuarioCanalSuscripcion?.id ?? 0
                },
                MetodoPago = new MetodoPagoDTO
                {
                    Id = p.metodoPago?.id ?? 0
                }
            };
        }

        private DispositivoUsuarioDTO ToFront(DispositivoUsuarioWSReference.DispositivoUsuarioDTO d)
        {
            return new DispositivoUsuarioDTO
            {
                Id = d.id,
                Nombre = d.nombre,
                Tipo = d.tipo,
                SistemaOperativo = d.sistemaOperativo,
                Activo = d.activo,
                Usuario = new UsuarioDTO
                {
                    Id = d.usuario?.id ?? 0
                }
            };
        }

        private PlanBeneficioDTO ToFront(PlanBeneficioWSReference.PlanBeneficioDTO pb)
        {
            return new PlanBeneficioDTO
            {
                Id = pb.id,
                PlanSuscripcion = new PlanSuscripcionDTO
                {
                    Id = pb.planSuscripcion?.id ?? 0
                },
                Beneficio = new BeneficioDTO
                {
                    Id = pb.beneficio?.id ?? 0
                }
            };
        }

        private PlanResolucionDTO ToFront(PlanResolucionWSReference.PlanResolucionDTO pr)
        {
            return new PlanResolucionDTO
            {
                Id = pr.id,
                PlanSuscripcion = new PlanSuscripcionDTO
                {
                    Id = pr.planSuscripcion?.id ?? 0
                },
                Resolucion = new ResolucionDTO
                {
                    Id = pr.resolucion?.id ?? 0
                }
            };
        }

        // ===============================================================
        // FRONT -> SOAP
        // ===============================================================

        private UsuarioWSReference.UsuarioDTO ToSoapUsuario(UsuarioDTO u)
        {
            var soap = new UsuarioWSReference.UsuarioDTO
            {
                id = u.Id,
                nombreCompleto = u.NombreCompleto,
                dni = u.Dni,
                edad = u.Edad,
                correo = u.Correo,
                telefono = u.Telefono,
                ciudad = u.Ciudad,
                fechaNacimiento = u.FechaNacimiento,
                profesion = u.Profesion
            };

            MarcarSpecified(soap, "id", "edad");
            return soap;
        }

        private CanalWSReference.CanalDTO ToSoapCanal(CanalDTO c)
        {
            var soap = new CanalWSReference.CanalDTO
            {
                id = c.Id,
                nombre = c.Nombre,
                descripcion = c.Descripcion,
                fechaCreacion = c.FechaCreacion,
                categoria = c.Categoria,
                numeroSeguidores = c.NumeroSeguidores
            };

            MarcarSpecified(soap, "id", "numeroSeguidores");
            return soap;
        }

        private PlanSuscripcionWSReference.PlanSuscripcionDTO ToSoapPlan(PlanSuscripcionDTO p)
        {
            var soap = new PlanSuscripcionWSReference.PlanSuscripcionDTO
            {
                id = p.Id,
                nombre = p.Nombre,
                costoMensual = Convert.ToDecimal(p.CostoMensual)
            };

            MarcarSpecified(soap, "id", "costoMensual");
            return soap;
        }

        private ResolucionWSReference.ResolucionDTO ToSoapResolucion(ResolucionDTO r)
        {
            var soap = new ResolucionWSReference.ResolucionDTO
            {
                id = r.Id,
                nombre = r.Nombre
            };

            MarcarSpecified(soap, "id");
            return soap;
        }

        private BeneficioWSReference.BeneficioDTO ToSoapBeneficio(BeneficioDTO b)
        {
            var soap = new BeneficioWSReference.BeneficioDTO
            {
                id = b.Id,
                nombre = b.Nombre,
                descripcion = b.Descripcion
            };

            MarcarSpecified(soap, "id");
            return soap;
        }

        private MetodoPagoWSReference.MetodoPagoDTO ToSoapMetodoPago(MetodoPagoDTO m)
        {
            var soap = new MetodoPagoWSReference.MetodoPagoDTO
            {
                id = m.Id,
                nombre = m.Nombre
            };

            MarcarSpecified(soap, "id");
            return soap;
        }

        private UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionDTO ToSoapSuscripcion(
            UsuarioCanalSuscripcionDTO s)
        {
            var usuario = new UsuarioCanalSuscripcionWSReference.UsuarioDTO
            {
                id = s.Usuario?.Id ?? 0
            };
            MarcarSpecified(usuario, "id");

            var canal = new UsuarioCanalSuscripcionWSReference.CanalDTO
            {
                id = s.Canal?.Id ?? 0
            };
            MarcarSpecified(canal, "id");

            var plan = new UsuarioCanalSuscripcionWSReference.PlanSuscripcionDTO
            {
                id = s.PlanSuscripcion?.Id ?? 0
            };
            MarcarSpecified(plan, "id");

            var soap = new UsuarioCanalSuscripcionWSReference.UsuarioCanalSuscripcionDTO
            {
                id = s.Id,
                usuario = usuario,
                canal = canal,
                planSuscripcion = plan,
                fechaRegistro = s.FechaRegistro,
                estado = s.Estado
            };

            MarcarSpecified(soap, "id");
            return soap;
        }

        private PagoSuscripcionWSReference.PagoSuscripcionDTO ToSoapPago(PagoSuscripcionDTO p)
        {
            var suscripcion = new PagoSuscripcionWSReference.UsuarioCanalSuscripcionDTO
            {
                id = p.UsuarioCanalSuscripcion?.Id ?? 0
            };
            MarcarSpecified(suscripcion, "id");

            var metodo = new PagoSuscripcionWSReference.MetodoPagoDTO
            {
                id = p.MetodoPago?.Id ?? 0
            };
            MarcarSpecified(metodo, "id");

            var soap = new PagoSuscripcionWSReference.PagoSuscripcionDTO
            {
                id = p.Id,
                usuarioCanalSuscripcion = suscripcion,
                metodoPago = metodo,
                monto = Convert.ToDecimal(p.Monto),
                fechaPago = p.FechaPago,
                estado = p.Estado
            };

            MarcarSpecified(soap, "id", "monto");
            return soap;
        }

        private DispositivoUsuarioWSReference.DispositivoUsuarioDTO ToSoapDispositivo(
            DispositivoUsuarioDTO d)
        {
            var usuario = new DispositivoUsuarioWSReference.UsuarioDTO
            {
                id = d.Usuario?.Id ?? 0
            };
            MarcarSpecified(usuario, "id");

            var soap = new DispositivoUsuarioWSReference.DispositivoUsuarioDTO
            {
                id = d.Id,
                usuario = usuario,
                nombre = d.Nombre,
                tipo = d.Tipo,
                sistemaOperativo = d.SistemaOperativo,
                activo = d.Activo
            };

            MarcarSpecified(soap, "id", "activo");
            return soap;
        }

        private PlanBeneficioWSReference.PlanBeneficioDTO ToSoapPlanBeneficio(PlanBeneficioDTO pb)
        {
            var plan = new PlanBeneficioWSReference.PlanSuscripcionDTO
            {
                id = pb.PlanSuscripcion?.Id ?? 0
            };
            MarcarSpecified(plan, "id");

            var beneficio = new PlanBeneficioWSReference.BeneficioDTO
            {
                id = pb.Beneficio?.Id ?? 0
            };
            MarcarSpecified(beneficio, "id");

            var soap = new PlanBeneficioWSReference.PlanBeneficioDTO
            {
                id = pb.Id,
                planSuscripcion = plan,
                beneficio = beneficio
            };

            MarcarSpecified(soap, "id");
            return soap;
        }

        private PlanResolucionWSReference.PlanResolucionDTO ToSoapPlanResolucion(PlanResolucionDTO pr)
        {
            var plan = new PlanResolucionWSReference.PlanSuscripcionDTO
            {
                id = pr.PlanSuscripcion?.Id ?? 0
            };
            MarcarSpecified(plan, "id");

            var resolucion = new PlanResolucionWSReference.ResolucionDTO
            {
                id = pr.Resolucion?.Id ?? 0
            };
            MarcarSpecified(resolucion, "id");

            var soap = new PlanResolucionWSReference.PlanResolucionDTO
            {
                id = pr.Id,
                planSuscripcion = plan,
                resolucion = resolucion
            };

            MarcarSpecified(soap, "id");
            return soap;
        }

        // ===============================================================
        // Helper para campos idSpecified, montoSpecified, etc.
        // ===============================================================
        private void MarcarSpecified(object? objeto, params string[] propiedades)
        {
            if (objeto == null)
                return;

            Type tipo = objeto.GetType();

            foreach (string propiedad in propiedades)
            {
                var propSpecified = tipo.GetProperty(propiedad + "Specified");

                if (propSpecified != null &&
                    propSpecified.CanWrite &&
                    propSpecified.PropertyType == typeof(bool))
                {
                    propSpecified.SetValue(objeto, true);
                }
            }
        }
    }
}