package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.UsuarioCanalSuscripcionBO;
import pe.edu.pucp.socialsoft.business.implementsBO.UsuarioCanalSuscripcionImplementsBO;
import pe.edu.pucp.socialsoft.model.UsuarioCanalSuscripcion;
import pe.edu.pucp.socialsoft.soapservices.dto.UsuarioCanalSuscripcionDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "UsuarioCanalSuscripcionWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/usuarioCanalSuscripcion"
)
@XmlSeeAlso({
        UsuarioCanalSuscripcionDTO.class
})
public class UsuarioCanalSuscripcionWS {

    private UsuarioCanalSuscripcionBO usuarioCanalSuscripcionBO;

    public UsuarioCanalSuscripcionWS() {
        usuarioCanalSuscripcionBO = new UsuarioCanalSuscripcionImplementsBO();
    }

    @WebMethod(operationName = "pingUsuarioCanalSuscripcion")
    public String pingUsuarioCanalSuscripcion() {
        return "SOAP de suscripciones funcionando";
    }

    @WebMethod(operationName = "listarUsuarioCanalSuscripciones")
    public UsuarioCanalSuscripcionDTO[] listarUsuarioCanalSuscripciones() {
        List<UsuarioCanalSuscripcion> lista = usuarioCanalSuscripcionBO.listarTodos();
        List<UsuarioCanalSuscripcionDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (UsuarioCanalSuscripcion item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new UsuarioCanalSuscripcionDTO[0]);
    }

    @WebMethod(operationName = "buscarUsuarioCanalSuscripcionPorId")
    public UsuarioCanalSuscripcionDTO buscarUsuarioCanalSuscripcionPorId(@WebParam(name = "id") int id) {
        UsuarioCanalSuscripcion model = usuarioCanalSuscripcionBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarUsuarioCanalSuscripcion")
    public int insertarUsuarioCanalSuscripcion(@WebParam(name = "usuarioCanalSuscripcion") UsuarioCanalSuscripcionDTO usuarioCanalSuscripcion) {
        UsuarioCanalSuscripcion model = SocialSoftSoapMapper.toModel(usuarioCanalSuscripcion);
        return usuarioCanalSuscripcionBO.insertar(model);
    }

    @WebMethod(operationName = "modificarUsuarioCanalSuscripcion")
    public int modificarUsuarioCanalSuscripcion(
            @WebParam(name = "id") int id,
            @WebParam(name = "usuarioCanalSuscripcion") UsuarioCanalSuscripcionDTO usuarioCanalSuscripcion
    ) {
        UsuarioCanalSuscripcion model = SocialSoftSoapMapper.toModel(usuarioCanalSuscripcion);
        model.setId(id);
        return usuarioCanalSuscripcionBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarUsuarioCanalSuscripcion")
    public int eliminarUsuarioCanalSuscripcion(@WebParam(name = "id") int id) {
        return usuarioCanalSuscripcionBO.eliminar(id);
    }
}
