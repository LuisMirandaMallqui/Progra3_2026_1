package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.PlanResolucionBO;
import pe.edu.pucp.socialsoft.business.implementsBO.PlanResolucionImplementsBO;
import pe.edu.pucp.socialsoft.model.PlanResolucion;
import pe.edu.pucp.socialsoft.soapservices.dto.PlanResolucionDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "PlanResolucionWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/planResolucion"
)
@XmlSeeAlso({
        PlanResolucionDTO.class
})
public class PlanResolucionWS {

    private PlanResolucionBO planResolucionBO;

    public PlanResolucionWS() {
        planResolucionBO = new PlanResolucionImplementsBO();
    }

    @WebMethod(operationName = "pingPlanResolucion")
    public String pingPlanResolucion() {
        return "SOAP de planes-resoluciones funcionando";
    }

    @WebMethod(operationName = "listarPlanResoluciones")
    public PlanResolucionDTO[] listarPlanResoluciones() {
        List<PlanResolucion> lista = planResolucionBO.listarTodos();
        List<PlanResolucionDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (PlanResolucion item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new PlanResolucionDTO[0]);
    }

    @WebMethod(operationName = "buscarPlanResolucionPorId")
    public PlanResolucionDTO buscarPlanResolucionPorId(@WebParam(name = "id") int id) {
        PlanResolucion model = planResolucionBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarPlanResolucion")
    public int insertarPlanResolucion(@WebParam(name = "planResolucion") PlanResolucionDTO planResolucion) {
        PlanResolucion model = SocialSoftSoapMapper.toModel(planResolucion);
        return planResolucionBO.insertar(model);
    }

    @WebMethod(operationName = "modificarPlanResolucion")
    public int modificarPlanResolucion(
            @WebParam(name = "id") int id,
            @WebParam(name = "planResolucion") PlanResolucionDTO planResolucion
    ) {
        PlanResolucion model = SocialSoftSoapMapper.toModel(planResolucion);
        model.setId(id);
        return planResolucionBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarPlanResolucion")
    public int eliminarPlanResolucion(@WebParam(name = "id") int id) {
        return planResolucionBO.eliminar(id);
    }
}
