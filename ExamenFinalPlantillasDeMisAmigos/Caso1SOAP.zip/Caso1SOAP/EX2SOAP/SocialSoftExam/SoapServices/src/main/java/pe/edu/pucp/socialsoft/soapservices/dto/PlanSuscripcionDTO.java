package pe.edu.pucp.socialsoft.soapservices.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;
import java.math.BigDecimal;

@XmlRootElement(name = "planSuscripcion")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PlanSuscripcionDTO", propOrder = {
        "id",
        "nombre",
        "costoMensual"
})
public class PlanSuscripcionDTO {
    private Integer id;
    private String nombre;
    private BigDecimal costoMensual;

    public PlanSuscripcionDTO() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public BigDecimal getCostoMensual() {
        return costoMensual;
    }

    public void setCostoMensual(BigDecimal costoMensual) {
        this.costoMensual = costoMensual;
    }
}
