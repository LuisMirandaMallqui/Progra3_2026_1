package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.CanalBO;
import pe.edu.pucp.socialsoft.business.implementsBO.CanalImplementsBO;
import pe.edu.pucp.socialsoft.model.Canal;
import pe.edu.pucp.socialsoft.soapservices.dto.CanalDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "CanalWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/canal"
)
@XmlSeeAlso({
        CanalDTO.class
})
public class CanalWS {

    private CanalBO canalBO;

    public CanalWS() {
        canalBO = new CanalImplementsBO();
    }

    @WebMethod(operationName = "pingCanal")
    public String pingCanal() {
        return "SOAP de canales funcionando";
    }

    @WebMethod(operationName = "listarCanales")
    public CanalDTO[] listarCanales() {
        List<Canal> lista = canalBO.listarTodos();
        List<CanalDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (Canal item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new CanalDTO[0]);
    }

    @WebMethod(operationName = "buscarCanalPorId")
    public CanalDTO buscarCanalPorId(@WebParam(name = "id") int id) {
        Canal model = canalBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarCanal")
    public int insertarCanal(@WebParam(name = "canal") CanalDTO canal) {
        Canal model = SocialSoftSoapMapper.toModel(canal);
        return canalBO.insertar(model);
    }

    @WebMethod(operationName = "modificarCanal")
    public int modificarCanal(
            @WebParam(name = "id") int id,
            @WebParam(name = "canal") CanalDTO canal
    ) {
        Canal model = SocialSoftSoapMapper.toModel(canal);
        model.setId(id);
        return canalBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarCanal")
    public int eliminarCanal(@WebParam(name = "id") int id) {
        return canalBO.eliminar(id);
    }
}
