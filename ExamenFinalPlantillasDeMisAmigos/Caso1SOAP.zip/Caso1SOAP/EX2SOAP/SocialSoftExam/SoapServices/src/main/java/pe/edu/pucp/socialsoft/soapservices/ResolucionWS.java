package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.ResolucionBO;
import pe.edu.pucp.socialsoft.business.implementsBO.ResolucionImplementsBO;
import pe.edu.pucp.socialsoft.model.Resolucion;
import pe.edu.pucp.socialsoft.soapservices.dto.ResolucionDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "ResolucionWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/resolucion"
)
@XmlSeeAlso({
        ResolucionDTO.class
})
public class ResolucionWS {

    private ResolucionBO resolucionBO;

    public ResolucionWS() {
        resolucionBO = new ResolucionImplementsBO();
    }

    @WebMethod(operationName = "pingResolucion")
    public String pingResolucion() {
        return "SOAP de resoluciones funcionando";
    }

    @WebMethod(operationName = "listarResoluciones")
    public ResolucionDTO[] listarResoluciones() {
        List<Resolucion> lista = resolucionBO.listarTodos();
        List<ResolucionDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (Resolucion item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new ResolucionDTO[0]);
    }

    @WebMethod(operationName = "buscarResolucionPorId")
    public ResolucionDTO buscarResolucionPorId(@WebParam(name = "id") int id) {
        Resolucion model = resolucionBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarResolucion")
    public int insertarResolucion(@WebParam(name = "resolucion") ResolucionDTO resolucion) {
        Resolucion model = SocialSoftSoapMapper.toModel(resolucion);
        return resolucionBO.insertar(model);
    }

    @WebMethod(operationName = "modificarResolucion")
    public int modificarResolucion(
            @WebParam(name = "id") int id,
            @WebParam(name = "resolucion") ResolucionDTO resolucion
    ) {
        Resolucion model = SocialSoftSoapMapper.toModel(resolucion);
        model.setId(id);
        return resolucionBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarResolucion")
    public int eliminarResolucion(@WebParam(name = "id") int id) {
        return resolucionBO.eliminar(id);
    }
}
