package pe.edu.pucp.socialsoft.soapservices.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

@XmlRootElement(name = "usuarioCanalSuscripcion")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UsuarioCanalSuscripcionDTO", propOrder = {
        "id",
        "usuario",
        "canal",
        "planSuscripcion",
        "fechaRegistro",
        "estado"
})
public class UsuarioCanalSuscripcionDTO {
    private Integer id;
    private UsuarioDTO usuario;
    private CanalDTO canal;
    private PlanSuscripcionDTO planSuscripcion;
    private String fechaRegistro;
    private String estado;

    public UsuarioCanalSuscripcionDTO() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public UsuarioDTO getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioDTO usuario) {
        this.usuario = usuario;
    }

    public CanalDTO getCanal() {
        return canal;
    }

    public void setCanal(CanalDTO canal) {
        this.canal = canal;
    }

    public PlanSuscripcionDTO getPlanSuscripcion() {
        return planSuscripcion;
    }

    public void setPlanSuscripcion(PlanSuscripcionDTO planSuscripcion) {
        this.planSuscripcion = planSuscripcion;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
