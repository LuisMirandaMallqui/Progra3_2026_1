package pe.edu.pucp.socialsoft.soapservices.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

@XmlRootElement(name = "planBeneficio")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PlanBeneficioDTO", propOrder = {
        "id",
        "planSuscripcion",
        "beneficio"
})
public class PlanBeneficioDTO {
    private Integer id;
    private PlanSuscripcionDTO planSuscripcion;
    private BeneficioDTO beneficio;

    public PlanBeneficioDTO() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public PlanSuscripcionDTO getPlanSuscripcion() {
        return planSuscripcion;
    }

    public void setPlanSuscripcion(PlanSuscripcionDTO planSuscripcion) {
        this.planSuscripcion = planSuscripcion;
    }

    public BeneficioDTO getBeneficio() {
        return beneficio;
    }

    public void setBeneficio(BeneficioDTO beneficio) {
        this.beneficio = beneficio;
    }
}
