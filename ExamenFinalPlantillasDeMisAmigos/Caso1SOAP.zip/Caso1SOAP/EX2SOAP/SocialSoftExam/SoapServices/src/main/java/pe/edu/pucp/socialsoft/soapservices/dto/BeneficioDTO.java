package pe.edu.pucp.socialsoft.soapservices.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

@XmlRootElement(name = "beneficio")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BeneficioDTO", propOrder = {
        "id",
        "nombre",
        "descripcion"
})
public class BeneficioDTO {
    private Integer id;
    private String nombre;
    private String descripcion;

    public BeneficioDTO() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
