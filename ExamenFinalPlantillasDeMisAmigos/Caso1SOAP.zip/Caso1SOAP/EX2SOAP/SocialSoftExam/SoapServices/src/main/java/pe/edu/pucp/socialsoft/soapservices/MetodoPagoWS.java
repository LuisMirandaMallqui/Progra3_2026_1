package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.MetodoPagoBO;
import pe.edu.pucp.socialsoft.business.implementsBO.MetodoPagoImplementsBO;
import pe.edu.pucp.socialsoft.model.MetodoPago;
import pe.edu.pucp.socialsoft.soapservices.dto.MetodoPagoDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "MetodoPagoWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/metodoPago"
)
@XmlSeeAlso({
        MetodoPagoDTO.class
})
public class MetodoPagoWS {

    private MetodoPagoBO metodoPagoBO;

    public MetodoPagoWS() {
        metodoPagoBO = new MetodoPagoImplementsBO();
    }

    @WebMethod(operationName = "pingMetodoPago")
    public String pingMetodoPago() {
        return "SOAP de métodos de pago funcionando";
    }

    @WebMethod(operationName = "listarMetodosPago")
    public MetodoPagoDTO[] listarMetodosPago() {
        List<MetodoPago> lista = metodoPagoBO.listarTodos();
        List<MetodoPagoDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (MetodoPago item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new MetodoPagoDTO[0]);
    }

    @WebMethod(operationName = "buscarMetodoPagoPorId")
    public MetodoPagoDTO buscarMetodoPagoPorId(@WebParam(name = "id") int id) {
        MetodoPago model = metodoPagoBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarMetodoPago")
    public int insertarMetodoPago(@WebParam(name = "metodoPago") MetodoPagoDTO metodoPago) {
        MetodoPago model = SocialSoftSoapMapper.toModel(metodoPago);
        return metodoPagoBO.insertar(model);
    }

    @WebMethod(operationName = "modificarMetodoPago")
    public int modificarMetodoPago(
            @WebParam(name = "id") int id,
            @WebParam(name = "metodoPago") MetodoPagoDTO metodoPago
    ) {
        MetodoPago model = SocialSoftSoapMapper.toModel(metodoPago);
        model.setId(id);
        return metodoPagoBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarMetodoPago")
    public int eliminarMetodoPago(@WebParam(name = "id") int id) {
        return metodoPagoBO.eliminar(id);
    }
}
