package pe.edu.pucp.socialsoft.soapservices.mapper;

import pe.edu.pucp.socialsoft.model.*;
import pe.edu.pucp.socialsoft.soapservices.dto.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

public final class SocialSoftSoapMapper {

    private SocialSoftSoapMapper() {
    }

    private static String formatLocalDate(LocalDate fecha) {
        return fecha == null ? null : fecha.toString();
    }

    private static String formatLocalDateTime(LocalDateTime fecha) {
        return fecha == null ? null : fecha.toString();
    }

    private static LocalDate parseLocalDate(String fecha) {
        if (fecha == null || fecha.isBlank()) return null;
        if (fecha.contains("T")) return LocalDateTime.parse(fecha).toLocalDate();
        return LocalDate.parse(fecha);
    }

    private static LocalDateTime parseLocalDateTime(String fecha) {
        if (fecha == null || fecha.isBlank()) return null;
        if (fecha.length() == 10) return LocalDate.parse(fecha).atStartOfDay();
        return LocalDateTime.parse(fecha);
    }

    public static BeneficioDTO toDTO(Beneficio model) {
        if (model == null) return null;
        BeneficioDTO dto = new BeneficioDTO();
        dto.setId(model.getId());
        dto.setNombre(model.getNombre());
        dto.setDescripcion(model.getDescripcion());
        return dto;
    }

    public static Beneficio toModel(BeneficioDTO dto) {
        if (dto == null) return null;
        Beneficio model = new Beneficio();
        model.setId(dto.getId());
        model.setNombre(dto.getNombre());
        model.setDescripcion(dto.getDescripcion());
        return model;
    }

    public static CanalDTO toDTO(Canal model) {
        if (model == null) return null;
        CanalDTO dto = new CanalDTO();
        dto.setId(model.getId());
        dto.setNombre(model.getNombre());
        dto.setDescripcion(model.getDescripcion());
        dto.setFechaCreacion(formatLocalDate(model.getFechaCreacion()));
        dto.setNumeroSeguidores(model.getNumeroSeguidores());
        dto.setCategoria(model.getCategoria());
        return dto;
    }

    public static Canal toModel(CanalDTO dto) {
        if (dto == null) return null;
        Canal model = new Canal();
        model.setId(dto.getId());
        model.setNombre(dto.getNombre());
        model.setDescripcion(dto.getDescripcion());
        model.setFechaCreacion(parseLocalDate(dto.getFechaCreacion()));
        model.setNumeroSeguidores(dto.getNumeroSeguidores());
        model.setCategoria(dto.getCategoria());
        return model;
    }

    public static DispositivoUsuarioDTO toDTO(DispositivoUsuario model) {
        if (model == null) return null;
        DispositivoUsuarioDTO dto = new DispositivoUsuarioDTO();
        dto.setId(model.getId());
        dto.setUsuario(toDTO(model.getUsuario()));
        dto.setNombre(model.getNombre());
        dto.setTipo(model.getTipo());
        dto.setSistemaOperativo(model.getSistemaOperativo());
        dto.setActivo(model.isActivo());
        return dto;
    }

    public static DispositivoUsuario toModel(DispositivoUsuarioDTO dto) {
        if (dto == null) return null;
        DispositivoUsuario model = new DispositivoUsuario();
        model.setId(dto.getId());
        model.setUsuario(toModel(dto.getUsuario()));
        model.setNombre(dto.getNombre());
        model.setTipo(dto.getTipo());
        model.setSistemaOperativo(dto.getSistemaOperativo());
        model.setActivo(dto.isActivo());
        return model;
    }

    public static MetodoPagoDTO toDTO(MetodoPago model) {
        if (model == null) return null;
        MetodoPagoDTO dto = new MetodoPagoDTO();
        dto.setId(model.getId());
        dto.setNombre(model.getNombre());
        return dto;
    }

    public static MetodoPago toModel(MetodoPagoDTO dto) {
        if (dto == null) return null;
        MetodoPago model = new MetodoPago();
        model.setId(dto.getId());
        model.setNombre(dto.getNombre());
        return model;
    }

    public static PagoSuscripcionDTO toDTO(PagoSuscripcion model) {
        if (model == null) return null;
        PagoSuscripcionDTO dto = new PagoSuscripcionDTO();
        dto.setId(model.getId());
        dto.setUsuarioCanalSuscripcion(toDTO(model.getUsuarioCanalSuscripcion()));
        dto.setMetodoPago(toDTO(model.getMetodoPago()));
        dto.setMonto(model.getMonto());
        dto.setFechaPago(formatLocalDate(model.getFechaPago()));
        dto.setEstado(model.getEstado());
        return dto;
    }

    public static PagoSuscripcion toModel(PagoSuscripcionDTO dto) {
        if (dto == null) return null;
        PagoSuscripcion model = new PagoSuscripcion();
        model.setId(dto.getId());
        model.setUsuarioCanalSuscripcion(toModel(dto.getUsuarioCanalSuscripcion()));
        model.setMetodoPago(toModel(dto.getMetodoPago()));
        model.setMonto(dto.getMonto());
        model.setFechaPago(parseLocalDate(dto.getFechaPago()));
        model.setEstado(dto.getEstado());
        return model;
    }

    public static PlanBeneficioDTO toDTO(PlanBeneficio model) {
        if (model == null) return null;
        PlanBeneficioDTO dto = new PlanBeneficioDTO();
        dto.setId(model.getId());
        dto.setPlanSuscripcion(toDTO(model.getPlanSuscripcion()));
        dto.setBeneficio(toDTO(model.getBeneficio()));
        return dto;
    }

    public static PlanBeneficio toModel(PlanBeneficioDTO dto) {
        if (dto == null) return null;
        PlanBeneficio model = new PlanBeneficio();
        model.setId(dto.getId());
        model.setPlanSuscripcion(toModel(dto.getPlanSuscripcion()));
        model.setBeneficio(toModel(dto.getBeneficio()));
        return model;
    }

    public static PlanResolucionDTO toDTO(PlanResolucion model) {
        if (model == null) return null;
        PlanResolucionDTO dto = new PlanResolucionDTO();
        dto.setId(model.getId());
        dto.setPlanSuscripcion(toDTO(model.getPlanSuscripcion()));
        dto.setResolucion(toDTO(model.getResolucion()));
        return dto;
    }

    public static PlanResolucion toModel(PlanResolucionDTO dto) {
        if (dto == null) return null;
        PlanResolucion model = new PlanResolucion();
        model.setId(dto.getId());
        model.setPlanSuscripcion(toModel(dto.getPlanSuscripcion()));
        model.setResolucion(toModel(dto.getResolucion()));
        return model;
    }

    public static PlanSuscripcionDTO toDTO(PlanSuscripcion model) {
        if (model == null) return null;
        PlanSuscripcionDTO dto = new PlanSuscripcionDTO();
        dto.setId(model.getId());
        dto.setNombre(model.getNombre());
        dto.setCostoMensual(model.getCostoMensual());
        return dto;
    }

    public static PlanSuscripcion toModel(PlanSuscripcionDTO dto) {
        if (dto == null) return null;
        PlanSuscripcion model = new PlanSuscripcion();
        model.setId(dto.getId());
        model.setNombre(dto.getNombre());
        model.setCostoMensual(dto.getCostoMensual());
        return model;
    }

    public static ResolucionDTO toDTO(Resolucion model) {
        if (model == null) return null;
        ResolucionDTO dto = new ResolucionDTO();
        dto.setId(model.getId());
        dto.setNombre(model.getNombre());
        dto.setDescripcion(model.getDescripcion());
        return dto;
    }

    public static Resolucion toModel(ResolucionDTO dto) {
        if (dto == null) return null;
        Resolucion model = new Resolucion();
        model.setId(dto.getId());
        model.setNombre(dto.getNombre());
        model.setDescripcion(dto.getDescripcion());
        return model;
    }

    public static UsuarioDTO toDTO(Usuario model) {
        if (model == null) return null;
        UsuarioDTO dto = new UsuarioDTO();
        dto.setId(model.getId());
        dto.setNombreCompleto(model.getNombreCompleto());
        dto.setDni(model.getDni());
        dto.setEdad(model.getEdad());
        dto.setCiudad(model.getCiudad());
        dto.setFechaNacimiento(formatLocalDate(model.getFechaNacimiento()));
        dto.setTelefono(model.getTelefono());
        dto.setCorreo(model.getCorreo());
        dto.setProfesion(model.getProfesion());
        return dto;
    }

    public static Usuario toModel(UsuarioDTO dto) {
        if (dto == null) return null;
        Usuario model = new Usuario();
        model.setId(dto.getId());
        model.setNombreCompleto(dto.getNombreCompleto());
        model.setDni(dto.getDni());
        model.setEdad(dto.getEdad());
        model.setCiudad(dto.getCiudad());
        model.setFechaNacimiento(parseLocalDate(dto.getFechaNacimiento()));
        model.setTelefono(dto.getTelefono());
        model.setCorreo(dto.getCorreo());
        model.setProfesion(dto.getProfesion());
        return model;
    }

    public static UsuarioCanalSuscripcionDTO toDTO(UsuarioCanalSuscripcion model) {
        if (model == null) return null;
        UsuarioCanalSuscripcionDTO dto = new UsuarioCanalSuscripcionDTO();
        dto.setId(model.getId());
        dto.setUsuario(toDTO(model.getUsuario()));
        dto.setCanal(toDTO(model.getCanal()));
        dto.setPlanSuscripcion(toDTO(model.getPlanSuscripcion()));
        dto.setFechaRegistro(formatLocalDateTime(model.getFechaRegistro()));
        dto.setEstado(model.getEstado());
        return dto;
    }

    public static UsuarioCanalSuscripcion toModel(UsuarioCanalSuscripcionDTO dto) {
        if (dto == null) return null;
        UsuarioCanalSuscripcion model = new UsuarioCanalSuscripcion();
        model.setId(dto.getId());
        model.setUsuario(toModel(dto.getUsuario()));
        model.setCanal(toModel(dto.getCanal()));
        model.setPlanSuscripcion(toModel(dto.getPlanSuscripcion()));
        model.setFechaRegistro(parseLocalDateTime(dto.getFechaRegistro()));
        model.setEstado(dto.getEstado());
        return model;
    }
}
