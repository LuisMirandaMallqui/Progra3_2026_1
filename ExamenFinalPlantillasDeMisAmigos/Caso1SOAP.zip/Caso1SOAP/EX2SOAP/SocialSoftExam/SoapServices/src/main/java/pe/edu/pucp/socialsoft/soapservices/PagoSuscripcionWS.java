package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.PagoSuscripcionBO;
import pe.edu.pucp.socialsoft.business.implementsBO.PagoSuscripcionImplementsBO;
import pe.edu.pucp.socialsoft.model.PagoSuscripcion;
import pe.edu.pucp.socialsoft.soapservices.dto.PagoSuscripcionDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "PagoSuscripcionWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/pagoSuscripcion"
)
@XmlSeeAlso({
        PagoSuscripcionDTO.class
})
public class PagoSuscripcionWS {

    private PagoSuscripcionBO pagoSuscripcionBO;

    public PagoSuscripcionWS() {
        pagoSuscripcionBO = new PagoSuscripcionImplementsBO();
    }

    @WebMethod(operationName = "pingPagoSuscripcion")
    public String pingPagoSuscripcion() {
        return "SOAP de pagos de suscripción funcionando";
    }

    @WebMethod(operationName = "listarPagosSuscripcion")
    public PagoSuscripcionDTO[] listarPagosSuscripcion() {
        List<PagoSuscripcion> lista = pagoSuscripcionBO.listarTodos();
        List<PagoSuscripcionDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (PagoSuscripcion item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new PagoSuscripcionDTO[0]);
    }

    @WebMethod(operationName = "buscarPagoSuscripcionPorId")
    public PagoSuscripcionDTO buscarPagoSuscripcionPorId(@WebParam(name = "id") int id) {
        PagoSuscripcion model = pagoSuscripcionBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarPagoSuscripcion")
    public int insertarPagoSuscripcion(@WebParam(name = "pagoSuscripcion") PagoSuscripcionDTO pagoSuscripcion) {
        PagoSuscripcion model = SocialSoftSoapMapper.toModel(pagoSuscripcion);
        return pagoSuscripcionBO.insertar(model);
    }

    @WebMethod(operationName = "modificarPagoSuscripcion")
    public int modificarPagoSuscripcion(
            @WebParam(name = "id") int id,
            @WebParam(name = "pagoSuscripcion") PagoSuscripcionDTO pagoSuscripcion
    ) {
        PagoSuscripcion model = SocialSoftSoapMapper.toModel(pagoSuscripcion);
        model.setId(id);
        return pagoSuscripcionBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarPagoSuscripcion")
    public int eliminarPagoSuscripcion(@WebParam(name = "id") int id) {
        return pagoSuscripcionBO.eliminar(id);
    }
}
