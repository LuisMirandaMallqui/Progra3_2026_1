package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.BeneficioBO;
import pe.edu.pucp.socialsoft.business.implementsBO.BeneficioImplementsBO;
import pe.edu.pucp.socialsoft.model.Beneficio;
import pe.edu.pucp.socialsoft.soapservices.dto.BeneficioDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "BeneficioWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/beneficio"
)
@XmlSeeAlso({
        BeneficioDTO.class
})
public class BeneficioWS {

    private BeneficioBO beneficioBO;

    public BeneficioWS() {
        beneficioBO = new BeneficioImplementsBO();
    }

    @WebMethod(operationName = "pingBeneficio")
    public String pingBeneficio() {
        return "SOAP de beneficios funcionando";
    }

    @WebMethod(operationName = "listarBeneficios")
    public BeneficioDTO[] listarBeneficios() {
        List<Beneficio> lista = beneficioBO.listarTodos();
        List<BeneficioDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (Beneficio item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new BeneficioDTO[0]);
    }

    @WebMethod(operationName = "buscarBeneficioPorId")
    public BeneficioDTO buscarBeneficioPorId(@WebParam(name = "id") int id) {
        Beneficio model = beneficioBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarBeneficio")
    public int insertarBeneficio(@WebParam(name = "beneficio") BeneficioDTO beneficio) {
        Beneficio model = SocialSoftSoapMapper.toModel(beneficio);
        return beneficioBO.insertar(model);
    }

    @WebMethod(operationName = "modificarBeneficio")
    public int modificarBeneficio(
            @WebParam(name = "id") int id,
            @WebParam(name = "beneficio") BeneficioDTO beneficio
    ) {
        Beneficio model = SocialSoftSoapMapper.toModel(beneficio);
        model.setId(id);
        return beneficioBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarBeneficio")
    public int eliminarBeneficio(@WebParam(name = "id") int id) {
        return beneficioBO.eliminar(id);
    }
}
