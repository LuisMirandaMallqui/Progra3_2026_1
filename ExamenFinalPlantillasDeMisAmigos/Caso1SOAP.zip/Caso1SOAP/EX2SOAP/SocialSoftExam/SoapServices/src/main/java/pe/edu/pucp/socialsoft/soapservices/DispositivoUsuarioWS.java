package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.DispositivoUsuarioBO;
import pe.edu.pucp.socialsoft.business.implementsBO.DispositivoUsuarioImplementsBO;
import pe.edu.pucp.socialsoft.model.DispositivoUsuario;
import pe.edu.pucp.socialsoft.soapservices.dto.DispositivoUsuarioDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "DispositivoUsuarioWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/dispositivoUsuario"
)
@XmlSeeAlso({
        DispositivoUsuarioDTO.class
})
public class DispositivoUsuarioWS {

    private DispositivoUsuarioBO dispositivoUsuarioBO;

    public DispositivoUsuarioWS() {
        dispositivoUsuarioBO = new DispositivoUsuarioImplementsBO();
    }

    @WebMethod(operationName = "pingDispositivoUsuario")
    public String pingDispositivoUsuario() {
        return "SOAP de dispositivos de usuario funcionando";
    }

    @WebMethod(operationName = "listarDispositivosUsuario")
    public DispositivoUsuarioDTO[] listarDispositivosUsuario() {
        List<DispositivoUsuario> lista = dispositivoUsuarioBO.listarTodos();
        List<DispositivoUsuarioDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (DispositivoUsuario item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new DispositivoUsuarioDTO[0]);
    }

    @WebMethod(operationName = "buscarDispositivoUsuarioPorId")
    public DispositivoUsuarioDTO buscarDispositivoUsuarioPorId(@WebParam(name = "id") int id) {
        DispositivoUsuario model = dispositivoUsuarioBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarDispositivoUsuario")
    public int insertarDispositivoUsuario(@WebParam(name = "dispositivoUsuario") DispositivoUsuarioDTO dispositivoUsuario) {
        DispositivoUsuario model = SocialSoftSoapMapper.toModel(dispositivoUsuario);
        return dispositivoUsuarioBO.insertar(model);
    }

    @WebMethod(operationName = "modificarDispositivoUsuario")
    public int modificarDispositivoUsuario(
            @WebParam(name = "id") int id,
            @WebParam(name = "dispositivoUsuario") DispositivoUsuarioDTO dispositivoUsuario
    ) {
        DispositivoUsuario model = SocialSoftSoapMapper.toModel(dispositivoUsuario);
        model.setId(id);
        return dispositivoUsuarioBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarDispositivoUsuario")
    public int eliminarDispositivoUsuario(@WebParam(name = "id") int id) {
        return dispositivoUsuarioBO.eliminar(id);
    }
}
