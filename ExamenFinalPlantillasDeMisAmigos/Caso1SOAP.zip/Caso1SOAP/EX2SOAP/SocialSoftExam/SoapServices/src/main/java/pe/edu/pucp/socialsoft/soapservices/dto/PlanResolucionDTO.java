package pe.edu.pucp.socialsoft.soapservices.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

@XmlRootElement(name = "planResolucion")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PlanResolucionDTO", propOrder = {
        "id",
        "planSuscripcion",
        "resolucion"
})
public class PlanResolucionDTO {
    private Integer id;
    private PlanSuscripcionDTO planSuscripcion;
    private ResolucionDTO resolucion;

    public PlanResolucionDTO() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public PlanSuscripcionDTO getPlanSuscripcion() {
        return planSuscripcion;
    }

    public void setPlanSuscripcion(PlanSuscripcionDTO planSuscripcion) {
        this.planSuscripcion = planSuscripcion;
    }

    public ResolucionDTO getResolucion() {
        return resolucion;
    }

    public void setResolucion(ResolucionDTO resolucion) {
        this.resolucion = resolucion;
    }
}
