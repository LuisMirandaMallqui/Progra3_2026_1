package pe.edu.pucp.socialsoft.soapservices.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

@XmlRootElement(name = "metodoPago")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MetodoPagoDTO", propOrder = {
        "id",
        "nombre"
})
public class MetodoPagoDTO {
    private Integer id;
    private String nombre;

    public MetodoPagoDTO() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
