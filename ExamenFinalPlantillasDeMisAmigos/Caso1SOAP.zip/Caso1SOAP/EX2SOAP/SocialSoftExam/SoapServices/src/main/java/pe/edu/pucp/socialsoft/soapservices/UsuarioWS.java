package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.UsuarioBO;
import pe.edu.pucp.socialsoft.business.implementsBO.UsuarioImplementsBO;
import pe.edu.pucp.socialsoft.model.Usuario;
import pe.edu.pucp.socialsoft.soapservices.dto.UsuarioDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "UsuarioWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/usuario"
)
@XmlSeeAlso({
        UsuarioDTO.class
})
public class UsuarioWS {

    private UsuarioBO usuarioBO;

    public UsuarioWS() {
        usuarioBO = new UsuarioImplementsBO();
    }

    @WebMethod(operationName = "pingUsuario")
    public String pingUsuario() {
        return "SOAP de usuarios funcionando";
    }

    @WebMethod(operationName = "listarUsuarios")
    public UsuarioDTO[] listarUsuarios() {
        List<Usuario> lista = usuarioBO.listarTodos();
        List<UsuarioDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (Usuario item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new UsuarioDTO[0]);
    }

    @WebMethod(operationName = "buscarUsuarioPorId")
    public UsuarioDTO buscarUsuarioPorId(@WebParam(name = "id") int id) {
        Usuario model = usuarioBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarUsuario")
    public int insertarUsuario(@WebParam(name = "usuario") UsuarioDTO usuario) {
        Usuario model = SocialSoftSoapMapper.toModel(usuario);
        return usuarioBO.insertar(model);
    }

    @WebMethod(operationName = "modificarUsuario")
    public int modificarUsuario(
            @WebParam(name = "id") int id,
            @WebParam(name = "usuario") UsuarioDTO usuario
    ) {
        Usuario model = SocialSoftSoapMapper.toModel(usuario);
        model.setId(id);
        return usuarioBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarUsuario")
    public int eliminarUsuario(@WebParam(name = "id") int id) {
        return usuarioBO.eliminar(id);
    }
}
