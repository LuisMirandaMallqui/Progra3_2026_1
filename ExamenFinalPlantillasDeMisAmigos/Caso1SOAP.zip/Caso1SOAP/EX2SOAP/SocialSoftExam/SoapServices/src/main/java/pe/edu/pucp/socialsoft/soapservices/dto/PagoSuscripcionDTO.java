package pe.edu.pucp.socialsoft.soapservices.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;
import java.math.BigDecimal;

@XmlRootElement(name = "pagoSuscripcion")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PagoSuscripcionDTO", propOrder = {
        "id",
        "usuarioCanalSuscripcion",
        "metodoPago",
        "monto",
        "fechaPago",
        "estado"
})
public class PagoSuscripcionDTO {
    private Integer id;
    private UsuarioCanalSuscripcionDTO usuarioCanalSuscripcion;
    private MetodoPagoDTO metodoPago;
    private BigDecimal monto;
    private String fechaPago;
    private String estado;

    public PagoSuscripcionDTO() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public UsuarioCanalSuscripcionDTO getUsuarioCanalSuscripcion() {
        return usuarioCanalSuscripcion;
    }

    public void setUsuarioCanalSuscripcion(UsuarioCanalSuscripcionDTO usuarioCanalSuscripcion) {
        this.usuarioCanalSuscripcion = usuarioCanalSuscripcion;
    }

    public MetodoPagoDTO getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(MetodoPagoDTO metodoPago) {
        this.metodoPago = metodoPago;
    }

    public BigDecimal getMonto() {
        return monto;
    }

    public void setMonto(BigDecimal monto) {
        this.monto = monto;
    }

    public String getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(String fechaPago) {
        this.fechaPago = fechaPago;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
