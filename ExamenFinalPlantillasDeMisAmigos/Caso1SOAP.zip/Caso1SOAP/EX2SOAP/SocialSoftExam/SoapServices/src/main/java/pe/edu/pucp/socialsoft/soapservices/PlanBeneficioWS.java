package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.PlanBeneficioBO;
import pe.edu.pucp.socialsoft.business.implementsBO.PlanBeneficioImplementsBO;
import pe.edu.pucp.socialsoft.model.PlanBeneficio;
import pe.edu.pucp.socialsoft.soapservices.dto.PlanBeneficioDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "PlanBeneficioWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/planBeneficio"
)
@XmlSeeAlso({
        PlanBeneficioDTO.class
})
public class PlanBeneficioWS {

    private PlanBeneficioBO planBeneficioBO;

    public PlanBeneficioWS() {
        planBeneficioBO = new PlanBeneficioImplementsBO();
    }

    @WebMethod(operationName = "pingPlanBeneficio")
    public String pingPlanBeneficio() {
        return "SOAP de planes-beneficios funcionando";
    }

    @WebMethod(operationName = "listarPlanBeneficios")
    public PlanBeneficioDTO[] listarPlanBeneficios() {
        List<PlanBeneficio> lista = planBeneficioBO.listarTodos();
        List<PlanBeneficioDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (PlanBeneficio item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new PlanBeneficioDTO[0]);
    }

    @WebMethod(operationName = "buscarPlanBeneficioPorId")
    public PlanBeneficioDTO buscarPlanBeneficioPorId(@WebParam(name = "id") int id) {
        PlanBeneficio model = planBeneficioBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarPlanBeneficio")
    public int insertarPlanBeneficio(@WebParam(name = "planBeneficio") PlanBeneficioDTO planBeneficio) {
        PlanBeneficio model = SocialSoftSoapMapper.toModel(planBeneficio);
        return planBeneficioBO.insertar(model);
    }

    @WebMethod(operationName = "modificarPlanBeneficio")
    public int modificarPlanBeneficio(
            @WebParam(name = "id") int id,
            @WebParam(name = "planBeneficio") PlanBeneficioDTO planBeneficio
    ) {
        PlanBeneficio model = SocialSoftSoapMapper.toModel(planBeneficio);
        model.setId(id);
        return planBeneficioBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarPlanBeneficio")
    public int eliminarPlanBeneficio(@WebParam(name = "id") int id) {
        return planBeneficioBO.eliminar(id);
    }
}
