package pe.edu.pucp.socialsoft.soapservices;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import jakarta.xml.bind.annotation.XmlSeeAlso;

import pe.edu.pucp.socialsoft.business.PlanSuscripcionBO;
import pe.edu.pucp.socialsoft.business.implementsBO.PlanSuscripcionImplementsBO;
import pe.edu.pucp.socialsoft.model.PlanSuscripcion;
import pe.edu.pucp.socialsoft.soapservices.dto.PlanSuscripcionDTO;
import pe.edu.pucp.socialsoft.soapservices.mapper.SocialSoftSoapMapper;

import java.util.ArrayList;
import java.util.List;

@WebService(
        serviceName = "PlanSuscripcionWS",
        targetNamespace = "http://soapservices.socialsoft.pucp.edu.pe/planSuscripcion"
)
@XmlSeeAlso({
        PlanSuscripcionDTO.class
})
public class PlanSuscripcionWS {

    private PlanSuscripcionBO planSuscripcionBO;

    public PlanSuscripcionWS() {
        planSuscripcionBO = new PlanSuscripcionImplementsBO();
    }

    @WebMethod(operationName = "pingPlanSuscripcion")
    public String pingPlanSuscripcion() {
        return "SOAP de planes de suscripción funcionando";
    }

    @WebMethod(operationName = "listarPlanesSuscripcion")
    public PlanSuscripcionDTO[] listarPlanesSuscripcion() {
        List<PlanSuscripcion> lista = planSuscripcionBO.listarTodos();
        List<PlanSuscripcionDTO> respuesta = new ArrayList<>();

        if (lista != null) {
            for (PlanSuscripcion item : lista) {
                respuesta.add(SocialSoftSoapMapper.toDTO(item));
            }
        }

        return respuesta.toArray(new PlanSuscripcionDTO[0]);
    }

    @WebMethod(operationName = "buscarPlanSuscripcionPorId")
    public PlanSuscripcionDTO buscarPlanSuscripcionPorId(@WebParam(name = "id") int id) {
        PlanSuscripcion model = planSuscripcionBO.buscarPorId(id);

        if (model == null) {
            return null;
        }

        return SocialSoftSoapMapper.toDTO(model);
    }

    @WebMethod(operationName = "insertarPlanSuscripcion")
    public int insertarPlanSuscripcion(@WebParam(name = "planSuscripcion") PlanSuscripcionDTO planSuscripcion) {
        PlanSuscripcion model = SocialSoftSoapMapper.toModel(planSuscripcion);
        return planSuscripcionBO.insertar(model);
    }

    @WebMethod(operationName = "modificarPlanSuscripcion")
    public int modificarPlanSuscripcion(
            @WebParam(name = "id") int id,
            @WebParam(name = "planSuscripcion") PlanSuscripcionDTO planSuscripcion
    ) {
        PlanSuscripcion model = SocialSoftSoapMapper.toModel(planSuscripcion);
        model.setId(id);
        return planSuscripcionBO.modificar(model);
    }

    @WebMethod(operationName = "eliminarPlanSuscripcion")
    public int eliminarPlanSuscripcion(@WebParam(name = "id") int id) {
        return planSuscripcionBO.eliminar(id);
    }
}
