# SocialSoft con SOAP agregado

Se mantuvo el proyecto original con REST y se agregó un módulo nuevo:

```text
SocialSoftExam
├── Model
├── DBManager
├── Persistence
├── Business
├── RestServices
└── SoapServices   <-- nuevo
```

REST no fue eliminado. SOAP usa el mismo `Business`, el mismo `DAO` y la misma BD.

## Qué se agregó

En `SoapServices` se agregaron servicios SOAP para:

- BeneficioWS
- CanalWS
- DispositivoUsuarioWS
- MetodoPagoWS
- PagoSuscripcionWS
- PlanBeneficioWS
- PlanResolucionWS
- PlanSuscripcionWS
- ResolucionWS
- UsuarioWS
- UsuarioCanalSuscripcionWS
- TestBDWS

También se agregaron DTOs SOAP porque varias clases del modelo usan `LocalDate` y `LocalDateTime`. Para SOAP/C#, las fechas se envían como `String`:

```text
LocalDate      -> yyyy-MM-dd
LocalDateTime  -> yyyy-MM-ddTHH:mm:ss
```

## Cómo compilar

Desde la carpeta `SocialSoftExam`:

```bash
mvn clean install package
```

El WAR SOAP queda en:

```text
SocialSoftExam/SoapServices/target/SoapServices.war
```

## Cómo desplegar

Despliega en GlassFish:

```text
SoapServices.war
```

Luego prueba primero:

```text
http://localhost:8080/SoapServices/TestBDWS?wsdl
```

Si GlassFish publica el WSDL con sufijo `Service`, prueba también:

```text
http://localhost:8080/SoapServices/TestBDWSService?wsdl
```

## WSDLs esperados

```text
http://localhost:8080/SoapServices/BeneficioWS?wsdl
http://localhost:8080/SoapServices/CanalWS?wsdl
http://localhost:8080/SoapServices/DispositivoUsuarioWS?wsdl
http://localhost:8080/SoapServices/MetodoPagoWS?wsdl
http://localhost:8080/SoapServices/PagoSuscripcionWS?wsdl
http://localhost:8080/SoapServices/PlanBeneficioWS?wsdl
http://localhost:8080/SoapServices/PlanResolucionWS?wsdl
http://localhost:8080/SoapServices/PlanSuscripcionWS?wsdl
http://localhost:8080/SoapServices/ResolucionWS?wsdl
http://localhost:8080/SoapServices/UsuarioWS?wsdl
http://localhost:8080/SoapServices/UsuarioCanalSuscripcionWS?wsdl
```

## Operaciones disponibles

Cada servicio tiene:

```text
ping()
listarTodos()
buscarPorId(int id)
insertar(DTO elemento)
modificar(int id, DTO elemento)
eliminar(int id)
```

## Frontend C#

El frontend original quedó igual. Para consumir SOAP desde C#, agrega el WSDL como Connected Service y crea un manager SOAP nuevo o reemplaza el manager REST por el cliente SOAP generado.

No consumas REST y SOAP para la misma operación al mismo tiempo, porque podrías duplicar registros.
