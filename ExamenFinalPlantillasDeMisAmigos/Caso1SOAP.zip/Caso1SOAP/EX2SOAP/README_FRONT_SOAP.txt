FRONTEND ADAPTADO PARA SOAP
===========================

El frontend ya no inyecta SocialSoftRSManager en la pantalla principal.
Ahora usa:

    SocialSoftSOAPManager

Archivos cambiados:

    SocialSoftFront/SocialSoftFront/Managers/SocialSoftSOAPManager.cs
    SocialSoftFront/SocialSoftFront/Program.cs
    SocialSoftFront/SocialSoftFront/Components/Pages/SocialSoft.razor

IMPORTANTE
----------
El manager SOAP usa reflexión. Eso significa que NO necesita que tú escribas manualmente:

    using CanalSoapReference;
    using UsuarioSoapReference;
    etc.

Lo único que necesitas hacer es agregar los Connected Services SOAP desde Visual Studio.
El manager buscará automáticamente clases generadas con nombres como:

    CanalWSClient
    UsuarioWSClient
    PlanSuscripcionWSClient
    ResolucionWSClient
    BeneficioWSClient
    MetodoPagoWSClient
    UsuarioCanalSuscripcionWSClient
    PagoSuscripcionWSClient
    DispositivoUsuarioWSClient
    PlanBeneficioWSClient
    PlanResolucionWSClient

WSDL que debes agregar en Visual Studio después de desplegar SoapServices.war:

    http://localhost:8080/SoapServices/UsuarioWS?wsdl
    http://localhost:8080/SoapServices/CanalWS?wsdl
    http://localhost:8080/SoapServices/PlanSuscripcionWS?wsdl
    http://localhost:8080/SoapServices/ResolucionWS?wsdl
    http://localhost:8080/SoapServices/BeneficioWS?wsdl
    http://localhost:8080/SoapServices/MetodoPagoWS?wsdl
    http://localhost:8080/SoapServices/UsuarioCanalSuscripcionWS?wsdl
    http://localhost:8080/SoapServices/PagoSuscripcionWS?wsdl
    http://localhost:8080/SoapServices/DispositivoUsuarioWS?wsdl
    http://localhost:8080/SoapServices/PlanBeneficioWS?wsdl
    http://localhost:8080/SoapServices/PlanResolucionWS?wsdl

Si GlassFish publica con sufijo Service, usa:

    http://localhost:8080/SoapServices/CanalWSService?wsdl

RECOMENDACIÓN DE NAMESPACE AL AGREGAR SERVICIOS
-----------------------------------------------
Puedes poner el namespace que quieras, pero para mantener orden se recomienda:

    UsuarioSoapReference
    CanalSoapReference
    PlanSuscripcionSoapReference
    ResolucionSoapReference
    BeneficioSoapReference
    MetodoPagoSoapReference
    UsuarioCanalSuscripcionSoapReference
    PagoSuscripcionSoapReference
    DispositivoUsuarioSoapReference
    PlanBeneficioSoapReference
    PlanResolucionSoapReference

El manager no depende de esos namespaces. Busca por el nombre de la clase Client.

FLUJO
-----
1. Compila backend:

       cd SocialSoftExam
       mvn clean install package

2. Despliega:

       SocialSoftExam/SoapServices/target/SoapServices.war

3. Verifica un WSDL en el navegador:

       http://localhost:8080/SoapServices/CanalWS?wsdl

4. En Visual Studio, en el proyecto Blazor:

       Connected Services
       Add Service Reference / WCF Web Service Reference
       Pegar cada WSDL
       Finalizar

5. Ejecuta el frontend y entra a:

       /socialsoft

