package pe.edu.pucp.socialsoft.pagos.impl;

import pe.edu.pucp.socialsoft.config.DBManager;
import pe.edu.pucp.socialsoft.enums.MetodoPagoTipo;
import pe.edu.pucp.socialsoft.pagos.dao.PagoSuscripcionDAO;
import pe.edu.pucp.socialsoft.pagos.model.MetodoPago;
import pe.edu.pucp.socialsoft.pagos.model.PagoSuscripcion;
import pe.edu.pucp.socialsoft.suscripciones.model.UsuarioCanalSuscripcion;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PagoSuscripcionImpl implements PagoSuscripcionDAO {

    /**
     * Convierte el string devuelto por la BD al enum MetodoPagoTipo.
     * El stored procedure LISTAR_PAGO_SUSCRIPCION_X_ID y LISTAR_PAGOS_SUSCRIPCION_TODOS
     * devuelven la columna 'nombre_metodo' con el nombre del metodo de pago.
     */
    private MetodoPagoTipo mapMetodoPago(String dbNombre) {
        if (dbNombre == null) return null;
        String normalized = dbNombre.trim().toUpperCase();
        if (normalized.contains("CREDITO") || normalized.contains("CRÉDITO")) return MetodoPagoTipo.TARJETA_CREDITO;
        if (normalized.contains("DEBITO") || normalized.contains("DÉBITO")) return MetodoPagoTipo.TARJETA_DEBITO;
        if (normalized.contains("YAPE")) return MetodoPagoTipo.YAPE;
        if (normalized.contains("PLIN")) return MetodoPagoTipo.PLIN;
        if (normalized.contains("TRANSFERENCIA")) return MetodoPagoTipo.TRANSFERENCIA_BANCARIA;
        try {
            return MetodoPagoTipo.valueOf(normalized);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public int insertar(PagoSuscripcion pago) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, pago.getUsuarioCanalSuscripcion().getIdUsuarioCanalSuscripcion());
        parametrosEntrada.put(3, pago.getMetodoPago().getIdMetodoPago());
        parametrosEntrada.put(4, pago.getMonto());
        parametrosEntrada.put(5, pago.getFechaPago());
        parametrosEntrada.put(6, pago.getEstado());
        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_PAGO_SUSCRIPCION", parametrosEntrada, parametrosSalida);
        pago.setIdPagoSuscripcion((int) parametrosSalida.get(1));
        return pago.getIdPagoSuscripcion();
    }

    @Override
    public int modificar(PagoSuscripcion pago) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, pago.getIdPagoSuscripcion());
        parametrosEntrada.put(2, pago.getUsuarioCanalSuscripcion().getIdUsuarioCanalSuscripcion());
        parametrosEntrada.put(3, pago.getMetodoPago().getIdMetodoPago());
        parametrosEntrada.put(4, pago.getMonto());
        parametrosEntrada.put(5, pago.getFechaPago());
        parametrosEntrada.put(6, pago.getEstado());
        return DBManager.getInstance().ejecutarProcedimientoAuto("MODIFICAR_PAGO_SUSCRIPCION", parametrosEntrada, null);
    }

    @Override
    public int eliminar(int id) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_PAGO_SUSCRIPCION", parametrosEntrada, null);
    }

    @Override
    public PagoSuscripcion buscarPorId(int id) {
        PagoSuscripcion pago = null;
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_PAGO_SUSCRIPCION_X_ID", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                if (rs.next()) {
                    pago = new PagoSuscripcion();
                    pago.setIdPagoSuscripcion(rs.getInt("id"));
                    pago.setMonto(rs.getDouble("monto"));
                    pago.setFechaPago(rs.getDate("fecha_pago").toLocalDate());
                    pago.setEstado(rs.getString("estado"));

                    UsuarioCanalSuscripcion ucs = new UsuarioCanalSuscripcion();
                    ucs.setIdUsuarioCanalSuscripcion(rs.getInt("id_usuario_canal_suscripcion"));
                    pago.setUsuarioCanalSuscripcion(ucs);

                    // El SP devuelve el id y el nombre del metodo de pago
                    MetodoPago mp = new MetodoPago();
                    mp.setIdMetodoPago(rs.getInt("id_metodo_pago"));
                    mp.setNombre(mapMetodoPago(rs.getString("nombre_metodo")));
                    pago.setMetodoPago(mp);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar pago por ID: " + ex.getMessage());
        }
        return pago;
    }

    @Override
    public List<PagoSuscripcion> listarTodos() {
        List<PagoSuscripcion> lista = new ArrayList<>();
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_PAGOS_SUSCRIPCION_TODOS", null)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    PagoSuscripcion pago = new PagoSuscripcion();
                    pago.setIdPagoSuscripcion(rs.getInt("id"));
                    pago.setMonto(rs.getDouble("monto"));
                    pago.setFechaPago(rs.getDate("fecha_pago").toLocalDate());
                    pago.setEstado(rs.getString("estado"));

                    UsuarioCanalSuscripcion ucs = new UsuarioCanalSuscripcion();
                    ucs.setIdUsuarioCanalSuscripcion(rs.getInt("id_usuario_canal_suscripcion"));
                    pago.setUsuarioCanalSuscripcion(ucs);

                    // El SP devuelve el id y el nombre del metodo de pago
                    MetodoPago mp = new MetodoPago();
                    mp.setIdMetodoPago(rs.getInt("id_metodo_pago"));
                    mp.setNombre(mapMetodoPago(rs.getString("nombre_metodo")));
                    pago.setMetodoPago(mp);

                    lista.add(pago);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar todos los pagos: " + ex.getMessage());
        }
        return lista;
    }
}
