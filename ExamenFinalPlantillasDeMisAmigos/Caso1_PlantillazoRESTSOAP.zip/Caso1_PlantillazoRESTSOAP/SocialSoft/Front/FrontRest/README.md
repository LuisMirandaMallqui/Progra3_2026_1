# Guía de Integración y Consumo - FrontRest (Blazor Server)

Este proyecto Blazor Server (.NET 10.0) está configurado para consumir **exclusivamente** servicios web REST (JSON) expuestos por el backend Java en GlassFish.

---

## 📂 Estructura de Integración REST

El consumo de servicios REST se realiza utilizando `HttpClient` con serialización y deserialización automática JSON (`System.Net.Http.Json`).

Los archivos principales de esta implementación son:
1. **[Models.cs](file:///d:/Users/DIOGO/Desktop/26-1/Clases/Programacion_3/EX2/SocialSoft/Front/FrontRest/Models/Models.cs):** Contiene la definición de las entidades de dominio y decoradores `[JsonPropertyName]` para emparejar automáticamente las variables camelCase del JSON de Java con las propiedades PascalCase de C#.
2. **Servicios de Consumo:**
   - **`CanalService.cs`:** Consume el servicio REST `CanalRS`.
   - **`PlanSuscripcionService.cs`:** Consume el servicio REST `PlanSuscripcionRS`.
   - **`UsuarioService.cs`:** Consume el servicio REST `UsuarioRS`.
   - **`UsuarioCanalSuscripcionService.cs`:** Consume el servicio REST `UsuarioCanalSuscripcionRS`.
   - **`PagoSuscripcionService.cs`:** Consume el servicio REST `PagoSuscripcionRS`.

---

## 📝 Paso a Paso: Cómo Agregar y Consumir un Nuevo Servicio REST

Si deseas añadir un nuevo método o servicio REST en el futuro, sigue este procedimiento:

### Paso 1: Definir los Modelos C# con Mapeadores JSON
* **¿Dónde agregarlo?** Abre [Models.cs](file:///d:/Users/DIOGO/Desktop/26-1/Clases/Programacion_3/EX2/SocialSoft/Front/FrontRest/Models/Models.cs) e introduce tu nueva clase decorando sus atributos:
```csharp
using System.Text.Json.Serialization;

namespace FrontRest.Models
{
    public class NuevaEntidad
    {
        [JsonPropertyName("id")] // Nombre exacto que devuelve la API JSON de Java
        public int Id { get; set; }

        [JsonPropertyName("descripcion")]
        public string Descripcion { get; set; } = string.Empty;
    }
}
```

### Paso 2: Crear el Cliente de Servicio
* **¿Dónde agregarlo?** Crea un archivo en `Services/NuevaEntidadService.cs`.
* **Código a agregar:**
```csharp
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using FrontRest.Models;

namespace FrontRest.Services
{
    public class NuevaEntidadService
    {
        private readonly HttpClient _httpClient;
        private const string BasePath = "webresources/NuevaEntidadRS"; // Ruta del recurso JAX-RS

        public NuevaEntidadService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<NuevaEntidad>> ListarTodosAsync()
        {
            try
            {
                // Realizar una petición GET y parsear el JSON automáticamente
                var respuesta = await _httpClient.GetFromJsonAsync<List<NuevaEntidad>>(BasePath);
                return respuesta ?? new List<NuevaEntidad>();
            }
            catch
            {
                return new List<NuevaEntidad>();
            }
        }
        
        public async Task<int> InsertarAsync(NuevaEntidad entidad)
        {
            try
            {
                // Realizar una petición POST enviando la entidad serializada en JSON
                var response = await _httpClient.PostAsJsonAsync(BasePath, entidad);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }
    }
}
```

### Paso 3: Registrar el Servicio en el Contenedor de Dependencias
* **¿Dónde agregarlo?** Abre [Program.cs](file:///d:/Users/DIOGO/Desktop/26-1/Clases/Programacion_3/EX2/SocialSoft/Front/FrontRest/Program.cs).
* **Código a agregar:**
```csharp
builder.Services.AddScoped<NuevaEntidadService>();
```

### Paso 4: Consumir en el Componente Razor (.razor)
* **¿Dónde agregarlo?** Crea tu página en `Components/Pages/NuevaPagina.razor`.
* **Código a agregar:**
```razor
@page "/nueva-pagina"
@using FrontRest.Models
@using FrontRest.Services
@inject NuevaEntidadService MiServicio

<h3>Listado desde REST</h3>

<ul>
    @foreach (var item in items)
    {
        <li>@item.Id - @item.Descripcion</li>
    }
</ul>

@code {
    private List<NuevaEntidad> items = new();

    protected override async Task OnInitializedAsync()
    {
        items = await MiServicio.ListarTodosAsync();
    }
}
```

---

## 🚀 Instrucciones de Ejecución

1. **Backend:** Asegúrate de que MySQL y el backend de GlassFish (`SocialSoftServicios`) estén activos y en ejecución en `http://localhost:8080/SocialSoftServicios/`.
2. **Frontend:** Abre la terminal dentro de `Front/FrontRest/` y ejecuta:
   ```bash
   dotnet run
   ```
3. Navega al puerto indicado (habitualmente `http://localhost:5000` o `https://localhost:5001`) para operar con el frontend REST de manera aislada.
