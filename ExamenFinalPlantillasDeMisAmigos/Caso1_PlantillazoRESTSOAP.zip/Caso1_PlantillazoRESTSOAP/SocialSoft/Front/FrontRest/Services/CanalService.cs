using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using FrontRest.Models;

namespace FrontRest.Services
{
    public class CanalService
    {
        private readonly HttpClient _httpClient;
        private const string BasePath = "webresources/CanalRS";

        public CanalService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<Canal>> ListarTodosCanalesAsync()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<Canal>>(BasePath);
                return response ?? new List<Canal>();
            }
            catch
            {
                return new List<Canal>();
            }
        }

        public async Task<Canal?> BuscarCanalPorIdAsync(int idCanal)
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<Canal>($"{BasePath}/{idCanal}");
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarCanalAsync(Canal canal)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync(BasePath, canal);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> ModificarCanalAsync(Canal canal)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync(BasePath, canal);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarCanalAsync(int idCanal)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{BasePath}/{idCanal}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }
    }
}
