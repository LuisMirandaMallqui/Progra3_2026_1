using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using FrontRest.Models;

namespace FrontRest.Services
{
    public class UsuarioService
    {
        private readonly HttpClient _httpClient;
        private const string BasePath = "webresources/UsuarioRS";

        public UsuarioService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<Usuario>> ListarTodosUsuariosAsync()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<Usuario>>(BasePath);
                return response ?? new List<Usuario>();
            }
            catch
            {
                return new List<Usuario>();
            }
        }

        public async Task<Usuario?> BuscarUsuarioPorIdAsync(int idUsuario)
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<Usuario>($"{BasePath}/{idUsuario}");
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarUsuarioAsync(Usuario usuario)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync(BasePath, usuario);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> ModificarUsuarioAsync(Usuario usuario)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync(BasePath, usuario);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarUsuarioAsync(int idUsuario)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{BasePath}/{idUsuario}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }
    }
}
