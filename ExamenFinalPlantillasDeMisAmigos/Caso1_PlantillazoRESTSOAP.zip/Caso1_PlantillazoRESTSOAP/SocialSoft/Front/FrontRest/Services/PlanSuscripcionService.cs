using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using FrontRest.Models;

namespace FrontRest.Services
{
    public class PlanSuscripcionService
    {
        private readonly HttpClient _httpClient;
        private const string BasePath = "webresources/PlanSuscripcionRS";

        public PlanSuscripcionService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<PlanSuscripcion>> ListarTodosPlanesAsync()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<PlanSuscripcion>>(BasePath);
                return response ?? new List<PlanSuscripcion>();
            }
            catch
            {
                return new List<PlanSuscripcion>();
            }
        }

        public async Task<PlanSuscripcion?> BuscarPlanPorIdAsync(int idPlan)
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<PlanSuscripcion>($"{BasePath}/{idPlan}");
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarPlanAsync(PlanSuscripcion plan)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync(BasePath, plan);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> ModificarPlanAsync(PlanSuscripcion plan)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync(BasePath, plan);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarPlanAsync(int idPlan)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{BasePath}/{idPlan}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }
    }
}
