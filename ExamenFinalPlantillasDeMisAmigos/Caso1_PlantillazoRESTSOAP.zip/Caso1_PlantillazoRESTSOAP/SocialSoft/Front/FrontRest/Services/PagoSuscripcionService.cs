using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using FrontRest.Models;

namespace FrontRest.Services
{
    public class PagoSuscripcionService
    {
        private readonly HttpClient _httpClient;
        private const string BasePath = "webresources/PagoSuscripcionRS";

        public PagoSuscripcionService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<PagoSuscripcion>> ListarTodosPagosAsync()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<PagoSuscripcion>>(BasePath);
                return response ?? new List<PagoSuscripcion>();
            }
            catch
            {
                return new List<PagoSuscripcion>();
            }
        }

        public async Task<PagoSuscripcion?> BuscarPagoPorIdAsync(int idPago)
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<PagoSuscripcion>($"{BasePath}/{idPago}");
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarPagoAsync(PagoSuscripcion pago)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync(BasePath, pago);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> ModificarPagoAsync(PagoSuscripcion pago)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync(BasePath, pago);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarPagoAsync(int idPago)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{BasePath}/{idPago}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }
    }
}
