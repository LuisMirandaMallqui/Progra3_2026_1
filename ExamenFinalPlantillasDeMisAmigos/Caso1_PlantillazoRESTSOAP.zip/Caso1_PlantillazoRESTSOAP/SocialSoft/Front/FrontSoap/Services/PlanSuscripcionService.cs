using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrontSoap.Models;

namespace FrontSoap.Services
{
    public class PlanSuscripcionService
    {
        private readonly SoapHelper _soapHelper;
        private const string SoapUrl = "PlanSuscripcionWS";

        public PlanSuscripcionService(SoapHelper soapHelper)
        {
            _soapHelper = soapHelper;
        }

        public async Task<List<PlanSuscripcion>> ListarTodosPlanesAsync()
        {
            try
            {
                var bodyXml = "<ser:listarTodosPlanes/>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                
                var returns = doc.Descendants().Where(x => x.Name.LocalName == "return");
                var list = new List<PlanSuscripcion>();
                foreach (var el in returns)
                {
                    list.Add(ParsePlan(el));
                }
                return list;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in ListarTodosPlanesAsync: " + ex.Message);
                return new List<PlanSuscripcion>();
            }
        }

        public async Task<PlanSuscripcion?> BuscarPlanPorIdAsync(int idPlan)
        {
            try
            {
                var bodyXml = $"<ser:buscarPlanPorId><idPlan>{idPlan}</idPlan></ser:buscarPlanPorId>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                if (ret != null)
                {
                    return ParsePlan(ret);
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarPlanAsync(PlanSuscripcion plan)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("<ser:insertarPlan><plan>");
                sb.Append($"<nombre>{plan.Nombre}</nombre>");
                sb.Append($"<costoMensual>{plan.CostoMensual}</costoMensual>");
                sb.Append("</plan></ser:insertarPlan>");

                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", sb.ToString());
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in InsertarPlanAsync: " + ex.Message);
                return 0;
            }
        }

        public async Task<int> ModificarPlanAsync(PlanSuscripcion plan)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("<ser:modificarPlan><plan>");
                sb.Append($"<idPlanSuscripcion>{plan.IdPlanSuscripcion}</idPlanSuscripcion>");
                sb.Append($"<nombre>{plan.Nombre}</nombre>");
                sb.Append($"<costoMensual>{plan.CostoMensual}</costoMensual>");
                sb.Append("</plan></ser:modificarPlan>");

                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", sb.ToString());
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarPlanAsync(int idPlan)
        {
            try
            {
                var bodyXml = $"<ser:eliminarPlan><idPlan>{idPlan}</idPlan></ser:eliminarPlan>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch
            {
                return 0;
            }
        }

        private PlanSuscripcion ParsePlan(XElement el)
        {
            var p = new PlanSuscripcion();
            p.IdPlanSuscripcion = int.Parse(el.Element("idPlanSuscripcion")?.Value ?? "0");
            Enum.TryParse<TipoPlan>(el.Element("nombre")?.Value, out var tp);
            p.Nombre = tp;
            p.CostoMensual = double.Parse(el.Element("costoMensual")?.Value ?? "0");

            var resEls = el.Elements("resoluciones");
            foreach (var rEl in resEls)
            {
                p.Resoluciones.Add(new Resolucion {
                    IdResolucion = int.Parse(rEl.Element("idResolucion")?.Value ?? "0"),
                    Nombre = rEl.Element("nombre")?.Value ?? "",
                    Descripcion = rEl.Element("descripcion")?.Value ?? ""
                });
            }

            var benEls = el.Elements("beneficios");
            foreach (var bEl in benEls)
            {
                p.Beneficios.Add(new Beneficio {
                    IdBeneficio = int.Parse(bEl.Element("idBeneficio")?.Value ?? "0"),
                    Nombre = bEl.Element("nombre")?.Value ?? "",
                    Descripcion = bEl.Element("descripcion")?.Value ?? ""
                });
            }

            return p;
        }
    }
}
