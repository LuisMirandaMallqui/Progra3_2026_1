using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrontSoap.Models;

namespace FrontSoap.Services
{
    public class PagoSuscripcionService
    {
        private readonly SoapHelper _soapHelper;
        private const string SoapUrl = "PagoSuscripcionWS";

        public PagoSuscripcionService(SoapHelper soapHelper)
        {
            _soapHelper = soapHelper;
        }

        public async Task<List<PagoSuscripcion>> ListarTodosPagosAsync()
        {
            try
            {
                var bodyXml = "<ser:listarTodosPagos/>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                
                var returns = doc.Descendants().Where(x => x.Name.LocalName == "return");
                var list = new List<PagoSuscripcion>();
                foreach (var el in returns)
                {
                    list.Add(ParsePago(el));
                }
                return list;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in ListarTodosPagosAsync: " + ex.Message);
                return new List<PagoSuscripcion>();
            }
        }

        public async Task<PagoSuscripcion?> BuscarPagoPorIdAsync(int idPago)
        {
            try
            {
                var bodyXml = $"<ser:buscarPagoPorId><idPago>{idPago}</idPago></ser:buscarPagoPorId>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                if (ret != null)
                {
                    return ParsePago(ret);
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarPagoAsync(PagoSuscripcion pago)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("<ser:insertarPago><pago>");
                if (pago.UsuarioCanalSuscripcion != null)
                {
                    sb.Append("<usuarioCanalSuscripcion>");
                    sb.Append($"<idUsuarioCanalSuscripcion>{pago.UsuarioCanalSuscripcion.IdUsuarioCanalSuscripcion}</idUsuarioCanalSuscripcion>");
                    sb.Append("</usuarioCanalSuscripcion>");
                }
                if (pago.MetodoPago != null)
                {
                    sb.Append("<metodoPago>");
                    sb.Append($"<idMetodoPago>{pago.MetodoPago.IdMetodoPago}</idMetodoPago>");
                    sb.Append("</metodoPago>");
                }
                sb.Append($"<monto>{pago.Monto}</monto>");
                if (pago.FechaPago.HasValue)
                {
                    sb.Append($"<fechaPago>{pago.FechaPago.Value:yyyy-MM-dd}</fechaPago>");
                }
                sb.Append($"<estado>{EscapeXml(pago.Estado)}</estado>");
                sb.Append("</pago></ser:insertarPago>");

                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", sb.ToString());
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in InsertarPagoAsync: " + ex.Message);
                return 0;
            }
        }

        public async Task<int> ModificarPagoAsync(PagoSuscripcion pago)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("<ser:modificarPago><pago>");
                sb.Append($"<idPagoSuscripcion>{pago.IdPagoSuscripcion}</idPagoSuscripcion>");
                if (pago.UsuarioCanalSuscripcion != null)
                {
                    sb.Append("<usuarioCanalSuscripcion>");
                    sb.Append($"<idUsuarioCanalSuscripcion>{pago.UsuarioCanalSuscripcion.IdUsuarioCanalSuscripcion}</idUsuarioCanalSuscripcion>");
                    sb.Append("</usuarioCanalSuscripcion>");
                }
                if (pago.MetodoPago != null)
                {
                    sb.Append("<metodoPago>");
                    sb.Append($"<idMetodoPago>{pago.MetodoPago.IdMetodoPago}</idMetodoPago>");
                    sb.Append("</metodoPago>");
                }
                sb.Append($"<monto>{pago.Monto}</monto>");
                if (pago.FechaPago.HasValue)
                {
                    sb.Append($"<fechaPago>{pago.FechaPago.Value:yyyy-MM-dd}</fechaPago>");
                }
                sb.Append($"<estado>{EscapeXml(pago.Estado)}</estado>");
                sb.Append("</pago></ser:modificarPago>");

                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", sb.ToString());
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarPagoAsync(int idPago)
        {
            try
            {
                var bodyXml = $"<ser:eliminarPago><idPago>{idPago}</idPago></ser:eliminarPago>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch
            {
                return 0;
            }
        }

        private PagoSuscripcion ParsePago(XElement el)
        {
            var p = new PagoSuscripcion();
            p.IdPagoSuscripcion = int.Parse(el.Element("idPagoSuscripcion")?.Value ?? "0");
            p.Monto = double.Parse(el.Element("monto")?.Value ?? "0");
            p.Estado = el.Element("estado")?.Value ?? "";
            
            if (DateTime.TryParse(el.Element("fechaPago")?.Value, out var dt))
            {
                p.FechaPago = dt;
            }

            var ucsEl = el.Element("usuarioCanalSuscripcion");
            if (ucsEl != null)
            {
                p.UsuarioCanalSuscripcion = new UsuarioCanalSuscripcion {
                    IdUsuarioCanalSuscripcion = int.Parse(ucsEl.Element("idUsuarioCanalSuscripcion")?.Value ?? "0")
                };

                var uEl = ucsEl.Element("usuario");
                if (uEl != null)
                {
                    p.UsuarioCanalSuscripcion.Usuario = new Usuario {
                        IdUsuario = int.Parse(uEl.Element("idUsuario")?.Value ?? "0"),
                        NombreCompleto = uEl.Element("nombreCompleto")?.Value ?? ""
                    };
                }

                var cEl = ucsEl.Element("canal");
                if (cEl != null)
                {
                    p.UsuarioCanalSuscripcion.Canal = new Canal {
                        IdCanal = int.Parse(cEl.Element("idCanal")?.Value ?? "0"),
                        Nombre = cEl.Element("nombre")?.Value ?? ""
                    };
                }
            }

            var mpEl = el.Element("metodoPago");
            if (mpEl != null)
            {
                var nameVal = mpEl.Element("nombre")?.Value ?? "TARJETA_CREDITO";
                
                MetodoPagoTipo mpt = MetodoPagoTipo.TARJETA_CREDITO;
                if (nameVal.Equals("Tarjeta de crédito", StringComparison.OrdinalIgnoreCase) || nameVal.Equals("TARJETA_CREDITO", StringComparison.OrdinalIgnoreCase))
                    mpt = MetodoPagoTipo.TARJETA_CREDITO;
                else if (nameVal.Equals("Tarjeta de débito", StringComparison.OrdinalIgnoreCase) || nameVal.Equals("TARJETA_DEBITO", StringComparison.OrdinalIgnoreCase))
                    mpt = MetodoPagoTipo.TARJETA_DEBITO;
                else if (nameVal.Equals("Yape", StringComparison.OrdinalIgnoreCase) || nameVal.Equals("YAPE", StringComparison.OrdinalIgnoreCase))
                    mpt = MetodoPagoTipo.YAPE;
                else if (nameVal.Equals("Plin", StringComparison.OrdinalIgnoreCase) || nameVal.Equals("PLIN", StringComparison.OrdinalIgnoreCase))
                    mpt = MetodoPagoTipo.PLIN;
                else if (nameVal.Equals("Transferencia", StringComparison.OrdinalIgnoreCase) || nameVal.Equals("TRANSFERENCIA_BANCARIA", StringComparison.OrdinalIgnoreCase))
                    mpt = MetodoPagoTipo.TRANSFERENCIA_BANCARIA;

                p.MetodoPago = new MetodoPago {
                    IdMetodoPago = int.Parse(mpEl.Element("idMetodoPago")?.Value ?? "0"),
                    Nombre = mpt
                };
            }

            return p;
        }

        private string EscapeXml(string value)
        {
            if (string.IsNullOrEmpty(value)) return "";
            return System.Security.SecurityElement.Escape(value);
        }
    }
}
