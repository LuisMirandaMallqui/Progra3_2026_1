using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace FrontSoap.Services
{
    public class SoapHelper
    {
        private readonly HttpClient _httpClient;

        public SoapHelper(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<XDocument> SendSoapRequestAsync(string url, string action, string bodyXml)
        {
            string soapEnvelope = $@"<?xml version=""1.0"" encoding=""utf-8""?>
<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:ser=""http://services.socialsoft.pucp.edu.pe/"">
   <soapenv:Header/>
   <soapenv:Body>
      {bodyXml}
   </soapenv:Body>
</soapenv:Envelope>";

            using var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Content = new StringContent(soapEnvelope, Encoding.UTF8, "text/xml");
            
            if (!string.IsNullOrEmpty(action))
            {
                request.Headers.Add("SOAPAction", action);
            }

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var responseString = await response.Content.ReadAsStringAsync();
            return XDocument.Parse(responseString);
        }
    }
}
