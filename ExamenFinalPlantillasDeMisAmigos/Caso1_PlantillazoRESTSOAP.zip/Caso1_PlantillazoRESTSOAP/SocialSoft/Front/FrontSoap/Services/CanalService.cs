using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrontSoap.Models;

namespace FrontSoap.Services
{
    public class CanalService
    {
        private readonly SoapHelper _soapHelper;
        private const string SoapUrl = "CanalWS";

        public CanalService(SoapHelper soapHelper)
        {
            _soapHelper = soapHelper;
        }

        public async Task<List<Canal>> ListarTodosCanalesAsync()
        {
            try
            {
                var bodyXml = "<ser:listarTodosCanales/>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                
                var returns = doc.Descendants().Where(x => x.Name.LocalName == "return");
                var list = new List<Canal>();
                foreach (var el in returns)
                {
                    list.Add(ParseCanal(el));
                }
                return list;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in ListarTodosCanalesAsync: " + ex.Message);
                return new List<Canal>();
            }
        }

        public async Task<Canal?> BuscarCanalPorIdAsync(int idCanal)
        {
            try
            {
                var bodyXml = $"<ser:buscarCanalPorId><idCanal>{idCanal}</idCanal></ser:buscarCanalPorId>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                if (ret != null)
                {
                    return ParseCanal(ret);
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarCanalAsync(Canal canal)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("<ser:insertarCanal><canal>");
                sb.Append($"<nombre>{EscapeXml(canal.Nombre)}</nombre>");
                sb.Append($"<descripcion>{EscapeXml(canal.Descripcion)}</descripcion>");
                if (canal.FechaCreacion.HasValue)
                {
                    sb.Append($"<fechaCreacion>{canal.FechaCreacion.Value:yyyy-MM-dd}</fechaCreacion>");
                }
                sb.Append($"<numeroSeguidores>{canal.NumeroSeguidores}</numeroSeguidores>");
                sb.Append($"<categoria>{EscapeXml(canal.Categoria)}</categoria>");
                sb.Append("</canal></ser:insertarCanal>");

                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", sb.ToString());
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in InsertarCanalAsync: " + ex.Message);
                return 0;
            }
        }

        public async Task<int> ModificarCanalAsync(Canal canal)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("<ser:modificarCanal><canal>");
                sb.Append($"<idCanal>{canal.IdCanal}</idCanal>");
                sb.Append($"<nombre>{EscapeXml(canal.Nombre)}</nombre>");
                sb.Append($"<descripcion>{EscapeXml(canal.Descripcion)}</descripcion>");
                if (canal.FechaCreacion.HasValue)
                {
                    sb.Append($"<fechaCreacion>{canal.FechaCreacion.Value:yyyy-MM-dd}</fechaCreacion>");
                }
                sb.Append($"<numeroSeguidores>{canal.NumeroSeguidores}</numeroSeguidores>");
                sb.Append($"<categoria>{EscapeXml(canal.Categoria)}</categoria>");
                sb.Append("</canal></ser:modificarCanal>");

                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", sb.ToString());
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarCanalAsync(int idCanal)
        {
            try
            {
                var bodyXml = $"<ser:eliminarCanal><idCanal>{idCanal}</idCanal></ser:eliminarCanal>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch
            {
                return 0;
            }
        }

        private Canal ParseCanal(XElement el)
        {
            var c = new Canal();
            c.IdCanal = int.Parse(el.Element("idCanal")?.Value ?? "0");
            c.Nombre = el.Element("nombre")?.Value ?? "";
            c.Descripcion = el.Element("descripcion")?.Value ?? "";
            
            if (DateTime.TryParse(el.Element("fechaCreacion")?.Value, out var dt))
            {
                c.FechaCreacion = dt;
            }
            c.NumeroSeguidores = int.Parse(el.Element("numeroSeguidores")?.Value ?? "0");
            c.Categoria = el.Element("categoria")?.Value ?? "";
            return c;
        }

        private string EscapeXml(string value)
        {
            if (string.IsNullOrEmpty(value)) return "";
            return System.Security.SecurityElement.Escape(value);
        }
    }
}
