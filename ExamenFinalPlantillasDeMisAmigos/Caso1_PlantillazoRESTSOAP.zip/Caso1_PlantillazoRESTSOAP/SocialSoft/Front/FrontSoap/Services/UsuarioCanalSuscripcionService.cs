using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrontSoap.Models;

namespace FrontSoap.Services
{
    public class UsuarioCanalSuscripcionService
    {
        private readonly SoapHelper _soapHelper;
        private const string SoapUrl = "UsuarioCanalSuscripcionWS";

        public UsuarioCanalSuscripcionService(SoapHelper soapHelper)
        {
            _soapHelper = soapHelper;
        }

        public async Task<List<UsuarioCanalSuscripcion>> ListarTodasSuscripcionesAsync()
        {
            try
            {
                var bodyXml = "<ser:listarTodasSuscripciones/>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                
                var returns = doc.Descendants().Where(x => x.Name.LocalName == "return");
                var list = new List<UsuarioCanalSuscripcion>();
                foreach (var el in returns)
                {
                    list.Add(ParseSuscripcion(el));
                }
                return list;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in ListarTodasSuscripcionesAsync: " + ex.Message);
                return new List<UsuarioCanalSuscripcion>();
            }
        }

        public async Task<UsuarioCanalSuscripcion?> BuscarSuscripcionPorIdAsync(int idSuscripcion)
        {
            try
            {
                var bodyXml = $"<ser:buscarSuscripcionPorId><idSuscripcion>{idSuscripcion}</idSuscripcion></ser:buscarSuscripcionPorId>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                if (ret != null)
                {
                    return ParseSuscripcion(ret);
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarSuscripcionAsync(UsuarioCanalSuscripcion suscripcion)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("<ser:insertarSuscripcion><suscripcion>");
                if (suscripcion.Usuario != null)
                {
                    sb.Append("<usuario>");
                    sb.Append($"<idUsuario>{suscripcion.Usuario.IdUsuario}</idUsuario>");
                    sb.Append("</usuario>");
                }
                if (suscripcion.Canal != null)
                {
                    sb.Append("<canal>");
                    sb.Append($"<idCanal>{suscripcion.Canal.IdCanal}</idCanal>");
                    sb.Append("</canal>");
                }
                if (suscripcion.PlanSuscripcion != null)
                {
                    sb.Append("<planSuscripcion>");
                    sb.Append($"<idPlanSuscripcion>{suscripcion.PlanSuscripcion.IdPlanSuscripcion}</idPlanSuscripcion>");
                    sb.Append("</planSuscripcion>");
                }
                sb.Append($"<estado>{EscapeXml(suscripcion.Estado)}</estado>");
                sb.Append("</suscripcion></ser:insertarSuscripcion>");

                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", sb.ToString());
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in InsertarSuscripcionAsync: " + ex.Message);
                return 0;
            }
        }

        public async Task<int> ModificarSuscripcionAsync(UsuarioCanalSuscripcion suscripcion)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("<ser:modificarSuscripcion><suscripcion>");
                sb.Append($"<idUsuarioCanalSuscripcion>{suscripcion.IdUsuarioCanalSuscripcion}</idUsuarioCanalSuscripcion>");
                if (suscripcion.Usuario != null)
                {
                    sb.Append("<usuario>");
                    sb.Append($"<idUsuario>{suscripcion.Usuario.IdUsuario}</idUsuario>");
                    sb.Append("</usuario>");
                }
                if (suscripcion.Canal != null)
                {
                    sb.Append("<canal>");
                    sb.Append($"<idCanal>{suscripcion.Canal.IdCanal}</idCanal>");
                    sb.Append("</canal>");
                }
                if (suscripcion.PlanSuscripcion != null)
                {
                    sb.Append("<planSuscripcion>");
                    sb.Append($"<idPlanSuscripcion>{suscripcion.PlanSuscripcion.IdPlanSuscripcion}</idPlanSuscripcion>");
                    sb.Append("</planSuscripcion>");
                }
                sb.Append($"<estado>{EscapeXml(suscripcion.Estado)}</estado>");
                sb.Append("</suscripcion></ser:modificarSuscripcion>");

                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", sb.ToString());
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarSuscripcionAsync(int idSuscripcion)
        {
            try
            {
                var bodyXml = $"<ser:eliminarSuscripcion><idSuscripcion>{idSuscripcion}</idSuscripcion></ser:eliminarSuscripcion>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch
            {
                return 0;
            }
        }

        private UsuarioCanalSuscripcion ParseSuscripcion(XElement el)
        {
            var s = new UsuarioCanalSuscripcion();
            s.IdUsuarioCanalSuscripcion = int.Parse(el.Element("idUsuarioCanalSuscripcion")?.Value ?? "0");
            s.Estado = el.Element("estado")?.Value ?? "";
            
            if (DateTime.TryParse(el.Element("fechaRegistro")?.Value, out var dt))
            {
                s.FechaRegistro = dt;
            }

            var uEl = el.Element("usuario");
            if (uEl != null)
            {
                s.Usuario = new Usuario {
                    IdUsuario = int.Parse(uEl.Element("idUsuario")?.Value ?? "0"),
                    NombreCompleto = uEl.Element("nombreCompleto")?.Value ?? "",
                    DNI = uEl.Element("DNI")?.Value ?? uEl.Element("dni")?.Value ?? "",
                    Correo = uEl.Element("correo")?.Value ?? ""
                };
            }

            var cEl = el.Element("canal");
            if (cEl != null)
            {
                s.Canal = new Canal {
                    IdCanal = int.Parse(cEl.Element("idCanal")?.Value ?? "0"),
                    Nombre = cEl.Element("nombre")?.Value ?? "",
                    Descripcion = cEl.Element("descripcion")?.Value ?? ""
                };
            }

            var pEl = el.Element("planSuscripcion");
            if (pEl != null)
            {
                Enum.TryParse<TipoPlan>(pEl.Element("nombre")?.Value, out var tp);
                s.PlanSuscripcion = new PlanSuscripcion {
                    IdPlanSuscripcion = int.Parse(pEl.Element("idPlanSuscripcion")?.Value ?? "0"),
                    Nombre = tp,
                    CostoMensual = double.Parse(pEl.Element("costoMensual")?.Value ?? "0")
                };
            }

            return s;
        }

        private string EscapeXml(string value)
        {
            if (string.IsNullOrEmpty(value)) return "";
            return System.Security.SecurityElement.Escape(value);
        }
    }
}
