using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrontSoap.Models;

namespace FrontSoap.Services
{
    public class UsuarioService
    {
        private readonly SoapHelper _soapHelper;
        private const string SoapUrl = "UsuarioWS";

        public UsuarioService(SoapHelper soapHelper)
        {
            _soapHelper = soapHelper;
        }

        public async Task<List<Usuario>> ListarTodosUsuariosAsync()
        {
            try
            {
                var bodyXml = "<ser:listarTodosUsuarios/>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                
                var returns = doc.Descendants().Where(x => x.Name.LocalName == "return");
                var list = new List<Usuario>();
                foreach (var el in returns)
                {
                    list.Add(ParseUsuario(el));
                }
                return list;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in ListarTodosUsuariosAsync: " + ex.Message);
                return new List<Usuario>();
            }
        }

        public async Task<Usuario?> BuscarUsuarioPorIdAsync(int idUsuario)
        {
            try
            {
                var bodyXml = $"<ser:buscarUsuarioPorId><idUsuario>{idUsuario}</idUsuario></ser:buscarUsuarioPorId>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                if (ret != null)
                {
                    return ParseUsuario(ret);
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarUsuarioAsync(Usuario usuario)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("<ser:insertarUsuario><usuario>");
                sb.Append($"<nombreCompleto>{EscapeXml(usuario.NombreCompleto)}</nombreCompleto>");
                sb.Append($"<DNI>{EscapeXml(usuario.DNI)}</DNI>");
                sb.Append($"<edad>{usuario.Edad}</edad>");
                sb.Append($"<ciudad>{EscapeXml(usuario.Ciudad)}</ciudad>");
                if (usuario.FechaNacimiento.HasValue)
                {
                    sb.Append($"<fechaNacimiento>{usuario.FechaNacimiento.Value:yyyy-MM-dd}</fechaNacimiento>");
                }
                sb.Append($"<telefono>{EscapeXml(usuario.Telefono)}</telefono>");
                sb.Append($"<correo>{EscapeXml(usuario.Correo)}</correo>");
                sb.Append($"<profesion>{EscapeXml(usuario.Profesion)}</profesion>");
                sb.Append(GetDispositivosXml(usuario.Dispositivos));
                sb.Append("</usuario></ser:insertarUsuario>");

                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", sb.ToString());
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in InsertarUsuarioAsync: " + ex.Message);
                return 0;
            }
        }

        public async Task<int> ModificarUsuarioAsync(Usuario usuario)
        {
            try
            {
                var sb = new StringBuilder();
                sb.Append("<ser:modificarUsuario><usuario>");
                sb.Append($"<idUsuario>{usuario.IdUsuario}</idUsuario>");
                sb.Append($"<nombreCompleto>{EscapeXml(usuario.NombreCompleto)}</nombreCompleto>");
                sb.Append($"<DNI>{EscapeXml(usuario.DNI)}</DNI>");
                sb.Append($"<edad>{usuario.Edad}</edad>");
                sb.Append($"<ciudad>{EscapeXml(usuario.Ciudad)}</ciudad>");
                if (usuario.FechaNacimiento.HasValue)
                {
                    sb.Append($"<fechaNacimiento>{usuario.FechaNacimiento.Value:yyyy-MM-dd}</fechaNacimiento>");
                }
                sb.Append($"<telefono>{EscapeXml(usuario.Telefono)}</telefono>");
                sb.Append($"<correo>{EscapeXml(usuario.Correo)}</correo>");
                sb.Append($"<profesion>{EscapeXml(usuario.Profesion)}</profesion>");
                sb.Append(GetDispositivosXml(usuario.Dispositivos));
                sb.Append("</usuario></ser:modificarUsuario>");

                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", sb.ToString());
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarUsuarioAsync(int idUsuario)
        {
            try
            {
                var bodyXml = $"<ser:eliminarUsuario><idUsuario>{idUsuario}</idUsuario></ser:eliminarUsuario>";
                var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
                var ret = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "return");
                return int.Parse(ret?.Value ?? "0");
            }
            catch
            {
                return 0;
            }
        }

        private string GetDispositivosXml(List<DispositivoUsuario> dispositivos)
        {
            var sb = new StringBuilder();
            foreach (var d in dispositivos)
            {
                sb.Append("<dispositivos>");
                if (d.IdDispositivoUsuario > 0)
                {
                    sb.Append($"<idDispositivoUsuario>{d.IdDispositivoUsuario}</idDispositivoUsuario>");
                }
                sb.Append($"<nombre>{EscapeXml(d.Nombre)}</nombre>");
                sb.Append($"<tipo>{EscapeXml(d.Tipo)}</tipo>");
                sb.Append($"<sistemaOperativo>{EscapeXml(d.SistemaOperativo)}</sistemaOperativo>");
                sb.Append($"<activo>{(d.Activo ? "true" : "false")}</activo>");
                sb.Append("</dispositivos>");
            }
            return sb.ToString();
        }

        private Usuario ParseUsuario(XElement el)
        {
            var u = new Usuario();
            u.IdUsuario = int.Parse(el.Element("idUsuario")?.Value ?? "0");
            u.NombreCompleto = el.Element("nombreCompleto")?.Value ?? "";
            u.DNI = el.Element("DNI")?.Value ?? el.Element("dni")?.Value ?? "";
            u.Edad = int.Parse(el.Element("edad")?.Value ?? "0");
            u.Ciudad = el.Element("ciudad")?.Value ?? "";
            
            if (DateTime.TryParse(el.Element("fechaNacimiento")?.Value, out var dt))
            {
                u.FechaNacimiento = dt;
            }
            u.Telefono = el.Element("telefono")?.Value ?? "";
            u.Correo = el.Element("correo")?.Value ?? "";
            u.Profesion = el.Element("profesion")?.Value ?? "";
            
            var dispEls = el.Elements("dispositivos");
            foreach (var dispEl in dispEls)
            {
                u.Dispositivos.Add(new DispositivoUsuario {
                    IdDispositivoUsuario = int.Parse(dispEl.Element("idDispositivoUsuario")?.Value ?? "0"),
                    Nombre = dispEl.Element("nombre")?.Value ?? "",
                    Tipo = dispEl.Element("tipo")?.Value ?? "",
                    SistemaOperativo = dispEl.Element("sistemaOperativo")?.Value ?? "",
                    Activo = bool.Parse(dispEl.Element("activo")?.Value ?? "true")
                });
            }
            return u;
        }

        private string EscapeXml(string value)
        {
            if (string.IsNullOrEmpty(value)) return "";
            return System.Security.SecurityElement.Escape(value);
        }
    }
}
