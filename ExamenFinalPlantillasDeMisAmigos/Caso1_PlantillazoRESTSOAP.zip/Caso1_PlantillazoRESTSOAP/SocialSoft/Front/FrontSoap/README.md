# Guía de Integración y Consumo - FrontSoap (Blazor Server)

Este proyecto Blazor Server (.NET 10.0) está configurado para consumir **exclusivamente** servicios web SOAP expuestos por el backend Java en GlassFish.

---

## 📂 Estructura de Integración SOAP

El consumo de servicios SOAP se realiza mediante la construcción dinámica de sobres (Envelopes) XML, enviados por `HttpClient`, y la posterior extracción de datos del XML de respuesta mediante consultas LINQ to XML (`XDocument`).

Los archivos principales de esta implementación son:
1. **[Models.cs](file:///d:/Users/DIOGO/Desktop/26-1/Clases/Programacion_3/EX2/SocialSoft/Front/FrontSoap/Models/Models.cs):** Contiene la definición de las entidades del dominio mapeadas a clases C#.
2. **[SoapHelper.cs](file:///d:/Users/DIOGO/Desktop/26-1/Clases/Programacion_3/EX2/SocialSoft/Front/FrontSoap/Services/SoapHelper.cs):** Helper reutilizable encargado de encapsular la envoltura XML y realizar la petición HTTP POST hacia GlassFish.
3. **Servicios de Consumo:**
   - **`CanalService.cs`:** Consume el servicio SOAP `CanalWS`.
   - **`PlanSuscripcionService.cs`:** Consume el servicio SOAP `PlanSuscripcionWS`.
   - **`UsuarioService.cs`:** Consume el servicio SOAP `UsuarioWS`.
   - **`UsuarioCanalSuscripcionService.cs`:** Consume el servicio SOAP `UsuarioCanalSuscripcionWS`.
   - **`PagoSuscripcionService.cs`:** Consume el servicio SOAP `PagoSuscripcionWS`.

---

## 📝 Paso a Paso: Cómo Agregar y Consumir un Nuevo Servicio SOAP

Si necesitas añadir un nuevo método o servicio SOAP en el futuro, sigue este procedimiento:

### Paso 1: Definir los Modelos C#
* **¿Dónde agregarlo?** Abre [Models.cs](file:///d:/Users/DIOGO/Desktop/26-1/Clases/Programacion_3/EX2/SocialSoft/Front/FrontSoap/Models/Models.cs) e introduce tu nueva clase:
```csharp
namespace FrontSoap.Models
{
    public class NuevaEntidad
    {
        public int Id { get; set; }
        public string Descripcion { get; set; } = string.Empty;
    }
}
```

### Paso 2: Crear el Cliente de Servicio
* **¿Dónde agregarlo?** Crea un archivo en `Services/NuevaEntidadService.cs`.
* **Código a agregar:**
```csharp
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrontSoap.Models;

namespace FrontSoap.Services
{
    public class NuevaEntidadService
    {
        private readonly SoapHelper _soapHelper;
        private const string SoapUrl = "NuevaEntidadWS"; // Nombre del servicio en GlassFish

        public NuevaEntidadService(SoapHelper soapHelper)
        {
            _soapHelper = soapHelper;
        }

        public async Task<List<NuevaEntidad>> ListarTodosAsync()
        {
            // 1. Cuerpo XML SOAP de la función a invocar
            string bodyXml = "<ser:listarTodasNuevasEntidades/>";
            
            // 2. Ejecutar la petición HTTP POST XML a través de SoapHelper
            var doc = await _soapHelper.SendSoapRequestAsync(SoapUrl, "", bodyXml);
            
            // 3. Parsear la respuesta XML usando LINQ
            var returns = doc.Descendants().Where(x => x.Name.LocalName == "return");
            var lista = new List<NuevaEntidad>();
            foreach (var el in returns)
            {
                lista.Add(new NuevaEntidad {
                    Id = int.Parse(el.Element("id")?.Value ?? "0"),
                    Descripcion = el.Element("descripcion")?.Value ?? ""
                });
            }
            return lista;
        }
    }
}
```

### Paso 3: Registrar el Servicio en el Contenedor de Dependencias
* **¿Dónde agregarlo?** Abre [Program.cs](file:///d:/Users/DIOGO/Desktop/26-1/Clases/Programacion_3/EX2/SocialSoft/Front/FrontSoap/Program.cs).
* **Código a agregar:**
```csharp
builder.Services.AddScoped<NuevaEntidadService>();
```

### Paso 4: Consumir en el Componente Razor (.razor)
* **¿Dónde agregarlo?** Crea o modifica tu página en `Components/Pages/NuevaPagina.razor`.
* **Código a agregar:**
```razor
@page "/nueva-pagina"
@using FrontSoap.Models
@using FrontSoap.Services
@inject NuevaEntidadService MiServicio

<h3>Listado desde SOAP</h3>

<ul>
    @foreach (var item in items)
    {
        <li>@item.Id - @item.Descripcion</li>
    }
</ul>

@code {
    private List<NuevaEntidad> items = new();

    protected override async Task OnInitializedAsync()
    {
        items = await MiServicio.ListarTodosAsync();
    }
}
```

---

## 🚀 Instrucciones de Ejecución

1. **Backend:** Asegúrate de que MySQL y el backend de GlassFish (`SocialSoftServicios`) estén activos y en ejecución en `http://localhost:8080/SocialSoftServicios/`.
2. **Frontend:** Abre la terminal dentro de `Front/FrontSoap/` y ejecuta:
   ```bash
   dotnet run
   ```
3. Navega al puerto indicado (habitualmente `http://localhost:5000` o `https://localhost:5001`) para operar con el frontend SOAP de manera aislada.
