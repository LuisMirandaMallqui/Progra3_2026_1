package pe.edu.pucp.socialsoft.enums;

public enum TipoPlan {
    BASICA,
    PREMIUM,
    VIP
}
