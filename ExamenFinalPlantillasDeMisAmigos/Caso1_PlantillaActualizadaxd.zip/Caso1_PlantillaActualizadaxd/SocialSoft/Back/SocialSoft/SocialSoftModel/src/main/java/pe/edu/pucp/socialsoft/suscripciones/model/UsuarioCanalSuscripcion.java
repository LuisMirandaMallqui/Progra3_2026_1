package pe.edu.pucp.socialsoft.suscripciones.model;

import java.time.LocalDate;
import pe.edu.pucp.socialsoft.clientes.model.Usuario;
import pe.edu.pucp.socialsoft.canales.model.Canal;

public class UsuarioCanalSuscripcion {
    private int idUsuarioCanalSuscripcion;
    private Usuario usuario;
    private Canal canal;
    private PlanSuscripcion planSuscripcion;
    private LocalDate fechaRegistro;
    private String estado;

    public UsuarioCanalSuscripcion() {}

    public int getIdUsuarioCanalSuscripcion() {
        return idUsuarioCanalSuscripcion;
    }

    public void setIdUsuarioCanalSuscripcion(int idUsuarioCanalSuscripcion) {
        this.idUsuarioCanalSuscripcion = idUsuarioCanalSuscripcion;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Canal getCanal() {
        return canal;
    }

    public void setCanal(Canal canal) {
        this.canal = canal;
    }

    public PlanSuscripcion getPlanSuscripcion() {
        return planSuscripcion;
    }

    public void setPlanSuscripcion(PlanSuscripcion planSuscripcion) {
        this.planSuscripcion = planSuscripcion;
    }

    public LocalDate getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDate fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
