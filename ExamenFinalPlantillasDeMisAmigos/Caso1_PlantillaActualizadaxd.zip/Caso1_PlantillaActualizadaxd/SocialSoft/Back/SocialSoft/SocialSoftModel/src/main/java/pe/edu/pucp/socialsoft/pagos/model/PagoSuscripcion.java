package pe.edu.pucp.socialsoft.pagos.model;

import java.time.LocalDate;
import pe.edu.pucp.socialsoft.suscripciones.model.UsuarioCanalSuscripcion;

public class PagoSuscripcion {
    private int idPagoSuscripcion;
    private UsuarioCanalSuscripcion usuarioCanalSuscripcion;
    private MetodoPago metodoPago;
    private double monto;
    private LocalDate fechaPago;
    private String estado;

    public PagoSuscripcion() {}

    public int getIdPagoSuscripcion() {
        return idPagoSuscripcion;
    }

    public void setIdPagoSuscripcion(int idPagoSuscripcion) {
        this.idPagoSuscripcion = idPagoSuscripcion;
    }

    public UsuarioCanalSuscripcion getUsuarioCanalSuscripcion() {
        return usuarioCanalSuscripcion;
    }

    public void setUsuarioCanalSuscripcion(UsuarioCanalSuscripcion usuarioCanalSuscripcion) {
        this.usuarioCanalSuscripcion = usuarioCanalSuscripcion;
    }

    public MetodoPago getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(MetodoPago metodoPago) {
        this.metodoPago = metodoPago;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public LocalDate getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(LocalDate fechaPago) {
        this.fechaPago = fechaPago;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
