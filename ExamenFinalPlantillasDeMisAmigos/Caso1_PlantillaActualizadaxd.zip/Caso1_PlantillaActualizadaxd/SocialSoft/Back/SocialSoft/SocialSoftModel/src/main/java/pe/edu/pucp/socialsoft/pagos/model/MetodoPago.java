package pe.edu.pucp.socialsoft.pagos.model;

import pe.edu.pucp.socialsoft.enums.MetodoPagoTipo;

public class MetodoPago {
    private int idMetodoPago;
    private MetodoPagoTipo nombre;

    public MetodoPago() {}

    public MetodoPago(MetodoPagoTipo nombre) {
        this.nombre = nombre;
    }

    public MetodoPago(int idMetodoPago, MetodoPagoTipo nombre) {
        this.idMetodoPago = idMetodoPago;
        this.nombre = nombre;
    }

    public int getIdMetodoPago() {
        return idMetodoPago;
    }

    public void setIdMetodoPago(int idMetodoPago) {
        this.idMetodoPago = idMetodoPago;
    }

    public MetodoPagoTipo getNombre() {
        return nombre;
    }

    public void setNombre(MetodoPagoTipo nombre) {
        this.nombre = nombre;
    }
}
