package pe.edu.pucp.socialsoft.suscripciones.model;

import pe.edu.pucp.socialsoft.enums.TipoPlan;
import java.util.ArrayList;
import java.util.List;

public class PlanSuscripcion {
    private int idPlanSuscripcion;
    private TipoPlan nombre;
    private double costoMensual;
    private List<Resolucion> resoluciones;
    private List<Beneficio> beneficios;

    public PlanSuscripcion() {
        this.resoluciones = new ArrayList<>();
        this.beneficios = new ArrayList<>();
    }

    public PlanSuscripcion(TipoPlan nombre, double costoMensual) {
        this();
        this.nombre = nombre;
        this.costoMensual = costoMensual;
    }

    public int getIdPlanSuscripcion() {
        return idPlanSuscripcion;
    }

    public void setIdPlanSuscripcion(int idPlanSuscripcion) {
        this.idPlanSuscripcion = idPlanSuscripcion;
    }

    public TipoPlan getNombre() {
        return nombre;
    }

    public void setNombre(TipoPlan nombre) {
        this.nombre = nombre;
    }

    public double getCostoMensual() {
        return costoMensual;
    }

    public void setCostoMensual(double costoMensual) {
        this.costoMensual = costoMensual;
    }

    public List<Resolucion> getResoluciones() {
        return resoluciones;
    }

    public void setResoluciones(List<Resolucion> resoluciones) {
        this.resoluciones = resoluciones;
    }

    public List<Beneficio> getBeneficios() {
        return beneficios;
    }

    public void setBeneficios(List<Beneficio> beneficios) {
        this.beneficios = beneficios;
    }
}
