package pe.edu.pucp.socialsoft.enums;

public enum MetodoPagoTipo {
    TARJETA_CREDITO,
    TARJETA_DEBITO,
    YAPE,
    PLIN,
    TRANSFERENCIA_BANCARIA
}
