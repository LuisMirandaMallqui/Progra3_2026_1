package pe.edu.pucp.socialsoft.suscripciones.model;

import pe.edu.pucp.socialsoft.enums.ResolucionTipo;

public class Resolucion {
    private int idResolucion;
    private ResolucionTipo nombre;
    private String descripcion;

    public Resolucion() {}

    public Resolucion(ResolucionTipo nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public int getIdResolucion() {
        return idResolucion;
    }

    public void setIdResolucion(int idResolucion) {
        this.idResolucion = idResolucion;
    }

    public ResolucionTipo getNombre() {
        return nombre;
    }

    public void setNombre(ResolucionTipo nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
