package pe.edu.pucp.socialsoft.enums;

public enum ResolucionTipo {
    SD,
    HD,
    _4K
}
