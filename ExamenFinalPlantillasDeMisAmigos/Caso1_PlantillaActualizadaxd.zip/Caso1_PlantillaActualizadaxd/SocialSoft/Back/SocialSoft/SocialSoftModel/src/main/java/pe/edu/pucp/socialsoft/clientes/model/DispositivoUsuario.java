package pe.edu.pucp.socialsoft.clientes.model;

public class DispositivoUsuario {
    private int idDispositivoUsuario;
    private int idUsuario;
    private String nombre;
    private String tipo;
    private String sistemaOperativo;
    private boolean activo;

    public DispositivoUsuario() {}

    public DispositivoUsuario(int idUsuario, String nombre, String tipo, String sistemaOperativo, boolean activo) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.tipo = tipo;
        this.sistemaOperativo = sistemaOperativo;
        this.activo = activo;
    }

    public int getIdDispositivoUsuario() {
        return idDispositivoUsuario;
    }

    public void setIdDispositivoUsuario(int idDispositivoUsuario) {
        this.idDispositivoUsuario = idDispositivoUsuario;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getSistemaOperativo() {
        return sistemaOperativo;
    }

    public void setSistemaOperativo(String sistemaOperativo) {
        this.sistemaOperativo = sistemaOperativo;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}
