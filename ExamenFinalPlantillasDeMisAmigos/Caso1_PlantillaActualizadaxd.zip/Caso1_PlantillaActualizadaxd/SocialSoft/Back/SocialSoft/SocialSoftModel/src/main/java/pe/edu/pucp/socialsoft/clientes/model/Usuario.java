package pe.edu.pucp.socialsoft.clientes.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Usuario {
    private int idUsuario;
    private String nombreCompleto;
    private String DNI;
    private int edad;
    private String ciudad;
    private LocalDate fechaNacimiento;
    private String telefono;
    private String correo;
    private String profesion;
    private List<DispositivoUsuario> dispositivos;

    public Usuario() {
        this.dispositivos = new ArrayList<>();
    }

    public Usuario(String nombreCompleto, String DNI, int edad, String ciudad, LocalDate fechaNacimiento,
                   String telefono, String correo, String profesion) {
        this();
        this.nombreCompleto = nombreCompleto;
        this.DNI = DNI;
        this.edad = edad;
        this.ciudad = ciudad;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correo = correo;
        this.profesion = profesion;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public List<DispositivoUsuario> getDispositivos() {
        return dispositivos;
    }

    public void setDispositivos(List<DispositivoUsuario> dispositivos) {
        this.dispositivos = dispositivos;
    }
}
