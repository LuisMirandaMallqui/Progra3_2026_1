// Archivo no utilizado.
package pe.edu.pucp.socialsoft.pagos.model;
