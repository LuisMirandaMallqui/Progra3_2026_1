package pe.edu.pucp.socialsoft.clientes.dao;

import pe.edu.pucp.socialsoft.clientes.model.DispositivoUsuario;
import pe.edu.pucp.socialsoft.dao.IDAO;

import java.util.List;

public interface DispositivoUsuarioDAO extends IDAO<DispositivoUsuario> {
    List<DispositivoUsuario> listarPorUsuario(int idUsuario);
}
