package pe.edu.pucp.socialsoft.canales.impl;

import pe.edu.pucp.socialsoft.canales.dao.CanalDAO;
import pe.edu.pucp.socialsoft.canales.model.Canal;
import pe.edu.pucp.socialsoft.config.DBManager;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CanalImpl implements CanalDAO {

    @Override
    public int insertar(Canal canal) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, canal.getNombre());
        parametrosEntrada.put(3, canal.getDescripcion());
        parametrosEntrada.put(4, canal.getFechaCreacion());
        parametrosEntrada.put(5, canal.getNumeroSeguidores());
        parametrosEntrada.put(6, canal.getCategoria());

        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_CANAL", parametrosEntrada, parametrosSalida);
        canal.setIdCanal((int) parametrosSalida.get(1));
        return canal.getIdCanal();
    }

    @Override
    public int modificar(Canal canal) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, canal.getIdCanal());
        parametrosEntrada.put(2, canal.getNombre());
        parametrosEntrada.put(3, canal.getDescripcion());
        parametrosEntrada.put(4, canal.getFechaCreacion());
        parametrosEntrada.put(5, canal.getNumeroSeguidores());
        parametrosEntrada.put(6, canal.getCategoria());

        return DBManager.getInstance().ejecutarProcedimientoAuto("MODIFICAR_CANAL", parametrosEntrada, null);
    }

    @Override
    public int eliminar(int id) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_CANAL", parametrosEntrada, null);
    }

    @Override
    public Canal buscarPorId(int id) {
        Canal canal = null;
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_CANAL_X_ID", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                if (rs.next()) {
                    canal = new Canal();
                    canal.setIdCanal(rs.getInt("id"));
                    canal.setNombre(rs.getString("nombre"));
                    canal.setDescripcion(rs.getString("descripcion"));
                    canal.setFechaCreacion(rs.getDate("fecha_creacion").toLocalDate());
                    canal.setNumeroSeguidores(rs.getInt("numero_seguidores"));
                    canal.setCategoria(rs.getString("categoria"));
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar canal por ID: " + ex.getMessage());
        }
        return canal;
    }

    @Override
    public List<Canal> listarTodos() {
        List<Canal> canales = new ArrayList<>();
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_CANALES_TODOS", null)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    Canal canal = new Canal();
                    canal.setIdCanal(rs.getInt("id"));
                    canal.setNombre(rs.getString("nombre"));
                    canal.setDescripcion(rs.getString("descripcion"));
                    canal.setFechaCreacion(rs.getDate("fecha_creacion").toLocalDate());
                    canal.setNumeroSeguidores(rs.getInt("numero_seguidores"));
                    canal.setCategoria(rs.getString("categoria"));
                    canales.add(canal);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar todos los canales: " + ex.getMessage());
        }
        return canales;
    }
}
