package pe.edu.pucp.socialsoft.suscripciones.impl;

import pe.edu.pucp.socialsoft.canales.model.Canal;
import pe.edu.pucp.socialsoft.clientes.model.Usuario;
import pe.edu.pucp.socialsoft.config.DBManager;
import pe.edu.pucp.socialsoft.suscripciones.dao.UsuarioCanalSuscripcionDAO;
import pe.edu.pucp.socialsoft.suscripciones.model.PlanSuscripcion;
import pe.edu.pucp.socialsoft.enums.TipoPlan;
import pe.edu.pucp.socialsoft.suscripciones.model.UsuarioCanalSuscripcion;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsuarioCanalSuscripcionImpl implements UsuarioCanalSuscripcionDAO {

    /**
     * Convierte el string de la BD al enum TipoPlan.
     * Los valores en BD son: 'BASICA', 'PREMIUM', 'VIP' (mayúsculas según DML).
     */
    private TipoPlan mapTipoPlan(String dbNombre) {
        if (dbNombre == null) return null;
        try {
            return TipoPlan.valueOf(dbNombre.trim().toUpperCase());
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public int insertar(UsuarioCanalSuscripcion suscripcion) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, suscripcion.getUsuario().getIdUsuario());
        parametrosEntrada.put(3, suscripcion.getCanal().getIdCanal());
        parametrosEntrada.put(4, suscripcion.getPlanSuscripcion().getIdPlanSuscripcion());
        parametrosEntrada.put(5, suscripcion.getEstado());

        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_USUARIO_CANAL_SUSCRIPCION", parametrosEntrada, parametrosSalida);
        suscripcion.setIdUsuarioCanalSuscripcion((int) parametrosSalida.get(1));
        return suscripcion.getIdUsuarioCanalSuscripcion();
    }

    @Override
    public int modificar(UsuarioCanalSuscripcion suscripcion) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, suscripcion.getIdUsuarioCanalSuscripcion());
        parametrosEntrada.put(2, suscripcion.getUsuario().getIdUsuario());
        parametrosEntrada.put(3, suscripcion.getCanal().getIdCanal());
        parametrosEntrada.put(4, suscripcion.getPlanSuscripcion().getIdPlanSuscripcion());
        parametrosEntrada.put(5, suscripcion.getEstado());

        return DBManager.getInstance().ejecutarProcedimientoAuto("MODIFICAR_USUARIO_CANAL_SUSCRIPCION", parametrosEntrada, null);
    }

    @Override
    public int eliminar(int id) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_USUARIO_CANAL_SUSCRIPCION", parametrosEntrada, null);
    }

    @Override
    public UsuarioCanalSuscripcion buscarPorId(int id) {
        UsuarioCanalSuscripcion suscripcion = null;
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_USUARIO_CANAL_SUSCRIPCION_X_ID", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                if (rs.next()) {
                    suscripcion = new UsuarioCanalSuscripcion();
                    suscripcion.setIdUsuarioCanalSuscripcion(rs.getInt("id"));
                    suscripcion.setFechaRegistro(rs.getTimestamp("fecha_registro").toLocalDateTime().toLocalDate());
                    suscripcion.setEstado(rs.getString("estado"));

                    Usuario u = new Usuario();
                    u.setIdUsuario(rs.getInt("id_usuario"));
                    u.setNombreCompleto(rs.getString("nombre_completo_usuario"));
                    u.setDNI(rs.getString("dni_usuario"));
                    suscripcion.setUsuario(u);

                    Canal c = new Canal();
                    c.setIdCanal(rs.getInt("id_canal"));
                    c.setNombre(rs.getString("nombre_canal"));
                    suscripcion.setCanal(c);

                    PlanSuscripcion p = new PlanSuscripcion();
                    p.setIdPlanSuscripcion(rs.getInt("id_plan_suscripcion"));
                    p.setNombre(mapTipoPlan(rs.getString("nombre_plan")));
                    p.setCostoMensual(rs.getDouble("costo_mensual"));
                    suscripcion.setPlanSuscripcion(p);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar suscripción por ID: " + ex.getMessage());
        }
        return suscripcion;
    }

    @Override
    public List<UsuarioCanalSuscripcion> listarTodos() {
        List<UsuarioCanalSuscripcion> lista = new ArrayList<>();
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_USUARIO_CANAL_SUSCRIPCION_TODOS", null)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    UsuarioCanalSuscripcion suscripcion = new UsuarioCanalSuscripcion();
                    suscripcion.setIdUsuarioCanalSuscripcion(rs.getInt("id"));
                    suscripcion.setFechaRegistro(rs.getTimestamp("fecha_registro").toLocalDateTime().toLocalDate());
                    suscripcion.setEstado(rs.getString("estado"));

                    Usuario u = new Usuario();
                    u.setIdUsuario(rs.getInt("id_usuario"));
                    u.setNombreCompleto(rs.getString("nombre_completo_usuario"));
                    u.setDNI(rs.getString("dni_usuario"));
                    suscripcion.setUsuario(u);

                    Canal c = new Canal();
                    c.setIdCanal(rs.getInt("id_canal"));
                    c.setNombre(rs.getString("nombre_canal"));
                    suscripcion.setCanal(c);

                    PlanSuscripcion p = new PlanSuscripcion();
                    p.setIdPlanSuscripcion(rs.getInt("id_plan_suscripcion"));
                    p.setNombre(mapTipoPlan(rs.getString("nombre_plan")));
                    p.setCostoMensual(rs.getDouble("costo_mensual"));
                    suscripcion.setPlanSuscripcion(p);

                    lista.add(suscripcion);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar todas las suscripciones: " + ex.getMessage());
        }
        return lista;
    }
}
