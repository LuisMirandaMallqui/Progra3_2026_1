package pe.edu.pucp.socialsoft.pagos.dao;

import pe.edu.pucp.socialsoft.dao.IDAO;
import pe.edu.pucp.socialsoft.pagos.model.MetodoPago;

public interface MetodoPagoDAO extends IDAO<MetodoPago> {
}
