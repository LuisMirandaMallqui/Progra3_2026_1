package pe.edu.pucp.socialsoft.suscripciones.dao;

import pe.edu.pucp.socialsoft.dao.IDAO;
import pe.edu.pucp.socialsoft.suscripciones.model.UsuarioCanalSuscripcion;

public interface UsuarioCanalSuscripcionDAO extends IDAO<UsuarioCanalSuscripcion> {
}
