package pe.edu.pucp.socialsoft.suscripciones.dao;

import pe.edu.pucp.socialsoft.suscripciones.model.Resolucion;
import java.util.List;

public interface PlanResolucionDAO {
    int asociarResolucionAPlan(int idPlan, int idResolucion);
    int desasociarResolucionDePlan(int idPlan, int idResolucion);
    List<Resolucion> listarResolucionesPorPlan(int idPlan);
}
