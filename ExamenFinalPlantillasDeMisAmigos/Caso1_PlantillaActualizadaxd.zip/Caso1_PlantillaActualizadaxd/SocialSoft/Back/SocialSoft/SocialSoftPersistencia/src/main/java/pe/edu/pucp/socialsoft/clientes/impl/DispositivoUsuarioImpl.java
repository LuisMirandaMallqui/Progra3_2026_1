package pe.edu.pucp.socialsoft.clientes.impl;

import pe.edu.pucp.socialsoft.clientes.dao.DispositivoUsuarioDAO;
import pe.edu.pucp.socialsoft.clientes.model.DispositivoUsuario;
import pe.edu.pucp.socialsoft.config.DBManager;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DispositivoUsuarioImpl implements DispositivoUsuarioDAO {

    @Override
    public int insertar(DispositivoUsuario dispositivo) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, dispositivo.getIdUsuario());
        parametrosEntrada.put(3, dispositivo.getNombre());
        parametrosEntrada.put(4, dispositivo.getTipo());
        parametrosEntrada.put(5, dispositivo.getSistemaOperativo());
        parametrosEntrada.put(6, dispositivo.isActivo());

        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_DISPOSITIVO_USUARIO", parametrosEntrada, parametrosSalida);
        dispositivo.setIdDispositivoUsuario((int) parametrosSalida.get(1));
        return dispositivo.getIdDispositivoUsuario();
    }

    @Override
    public int modificar(DispositivoUsuario dispositivo) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, dispositivo.getIdDispositivoUsuario());
        parametrosEntrada.put(2, dispositivo.getIdUsuario());
        parametrosEntrada.put(3, dispositivo.getNombre());
        parametrosEntrada.put(4, dispositivo.getTipo());
        parametrosEntrada.put(5, dispositivo.getSistemaOperativo());
        parametrosEntrada.put(6, dispositivo.isActivo());

        return DBManager.getInstance().ejecutarProcedimientoAuto("MODIFICAR_DISPOSITIVO_USUARIO", parametrosEntrada, null);
    }

    @Override
    public int eliminar(int id) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_DISPOSITIVO_USUARIO", parametrosEntrada, null);
    }

    @Override
    public DispositivoUsuario buscarPorId(int id) {
        DispositivoUsuario dispositivo = null;
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_DISPOSITIVO_USUARIO_X_ID", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                if (rs.next()) {
                    dispositivo = new DispositivoUsuario();
                    dispositivo.setIdDispositivoUsuario(rs.getInt("id"));
                    dispositivo.setIdUsuario(rs.getInt("id_usuario"));
                    dispositivo.setNombre(rs.getString("nombre"));
                    dispositivo.setTipo(rs.getString("tipo"));
                    dispositivo.setSistemaOperativo(rs.getString("sistema_operativo"));
                    dispositivo.setActivo(rs.getBoolean("activo"));
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar dispositivo por ID: " + ex.getMessage());
        }
        return dispositivo;
    }

    @Override
    public List<DispositivoUsuario> listarTodos() {
        List<DispositivoUsuario> dispositivos = new ArrayList<>();
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_DISPOSITIVOS_USUARIO_TODOS", null)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    DispositivoUsuario dispositivo = new DispositivoUsuario();
                    dispositivo.setIdDispositivoUsuario(rs.getInt("id"));
                    dispositivo.setIdUsuario(rs.getInt("id_usuario"));
                    dispositivo.setNombre(rs.getString("nombre"));
                    dispositivo.setTipo(rs.getString("tipo"));
                    dispositivo.setSistemaOperativo(rs.getString("sistema_operativo"));
                    dispositivo.setActivo(rs.getBoolean("activo"));
                    dispositivos.add(dispositivo);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar todos los dispositivos: " + ex.getMessage());
        }
        return dispositivos;
    }

    @Override
    public List<DispositivoUsuario> listarPorUsuario(int idUsuario) {
        List<DispositivoUsuario> dispositivos = new ArrayList<>();
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, idUsuario);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_DISPOSITIVOS_X_USUARIO", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    DispositivoUsuario dispositivo = new DispositivoUsuario();
                    dispositivo.setIdDispositivoUsuario(rs.getInt("id"));
                    dispositivo.setIdUsuario(rs.getInt("id_usuario"));
                    dispositivo.setNombre(rs.getString("nombre"));
                    dispositivo.setTipo(rs.getString("tipo"));
                    dispositivo.setSistemaOperativo(rs.getString("sistema_operativo"));
                    dispositivo.setActivo(rs.getBoolean("activo"));
                    dispositivos.add(dispositivo);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar dispositivos por usuario: " + ex.getMessage());
        }
        return dispositivos;
    }
}
