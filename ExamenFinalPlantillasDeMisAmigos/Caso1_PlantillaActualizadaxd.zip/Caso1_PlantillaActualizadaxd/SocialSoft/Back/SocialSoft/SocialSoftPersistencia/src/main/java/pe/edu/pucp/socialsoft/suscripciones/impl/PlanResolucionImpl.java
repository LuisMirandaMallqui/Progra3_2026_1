package pe.edu.pucp.socialsoft.suscripciones.impl;

import pe.edu.pucp.socialsoft.config.DBManager;
import pe.edu.pucp.socialsoft.suscripciones.dao.PlanResolucionDAO;
import pe.edu.pucp.socialsoft.suscripciones.model.Resolucion;
import pe.edu.pucp.socialsoft.enums.ResolucionTipo;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlanResolucionImpl implements PlanResolucionDAO {

    private ResolucionTipo mapResolucionTipo(String dbNombre) {
        if (dbNombre == null) return null;
        dbNombre = dbNombre.trim().toUpperCase();
        if (dbNombre.equals("4K")) return ResolucionTipo._4K;
        try {
            return ResolucionTipo.valueOf(dbNombre);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public int asociarResolucionAPlan(int idPlan, int idResolucion) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, idPlan);
        parametrosEntrada.put(3, idResolucion);

        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_PLAN_RESOLUCION", parametrosEntrada, parametrosSalida);
        return (int) parametrosSalida.get(1);
    }

    @Override
    public int desasociarResolucionDePlan(int idPlan, int idResolucion) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, idPlan);
        parametrosEntrada.put(2, idResolucion);

        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_PLAN_RESOLUCION", parametrosEntrada, null);
    }

    @Override
    public List<Resolucion> listarResolucionesPorPlan(int idPlan) {
        List<Resolucion> resoluciones = new ArrayList<>();
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, idPlan);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_RESOLUCIONES_X_PLAN", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    Resolucion resolucion = new Resolucion();
                    resolucion.setIdResolucion(rs.getInt("id"));
                    resolucion.setNombre(mapResolucionTipo(rs.getString("nombre")));
                    resolucion.setDescripcion(rs.getString("descripcion"));
                    resoluciones.add(resolucion);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar resoluciones por plan: " + ex.getMessage());
        }
        return resoluciones;
    }
}
