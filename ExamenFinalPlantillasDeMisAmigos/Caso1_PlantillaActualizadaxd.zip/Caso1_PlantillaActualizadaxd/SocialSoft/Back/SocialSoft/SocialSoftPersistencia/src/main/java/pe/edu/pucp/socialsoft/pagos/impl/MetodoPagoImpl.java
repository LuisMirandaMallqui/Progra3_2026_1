package pe.edu.pucp.socialsoft.pagos.impl;

import pe.edu.pucp.socialsoft.config.DBManager;
import pe.edu.pucp.socialsoft.enums.MetodoPagoTipo;
import pe.edu.pucp.socialsoft.pagos.dao.MetodoPagoDAO;
import pe.edu.pucp.socialsoft.pagos.model.MetodoPago;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MetodoPagoImpl implements MetodoPagoDAO {

    /**
     * Convierte el string devuelto por la BD al enum MetodoPagoTipo.
     * Los valores en la BD son: 'Tarjeta de crédito', 'Tarjeta de débito',
     * 'Yape', 'Plin', 'Transferencia'.
     */
    private MetodoPagoTipo mapMetodoPago(String dbNombre) {
        if (dbNombre == null) return null;
        String normalized = dbNombre.trim().toUpperCase();
        if (normalized.contains("CREDITO") || normalized.contains("CRÉDITO")) return MetodoPagoTipo.TARJETA_CREDITO;
        if (normalized.contains("DEBITO") || normalized.contains("DÉBITO")) return MetodoPagoTipo.TARJETA_DEBITO;
        if (normalized.contains("YAPE")) return MetodoPagoTipo.YAPE;
        if (normalized.contains("PLIN")) return MetodoPagoTipo.PLIN;
        if (normalized.contains("TRANSFERENCIA")) return MetodoPagoTipo.TRANSFERENCIA_BANCARIA;
        try {
            return MetodoPagoTipo.valueOf(normalized);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Convierte el enum MetodoPagoTipo al string que espera/almacena la BD.
     * Los valores insertados por DML son: 'Tarjeta de crédito', 'Tarjeta de débito',
     * 'Yape', 'Plin', 'Transferencia'.
     */
    private String getDbNombre(MetodoPagoTipo metodo) {
        if (metodo == null) return null;
        switch (metodo) {
            case TARJETA_CREDITO:       return "Tarjeta de crédito";
            case TARJETA_DEBITO:        return "Tarjeta de débito";
            case YAPE:                  return "Yape";
            case PLIN:                  return "Plin";
            case TRANSFERENCIA_BANCARIA: return "Transferencia";
            default:                    return metodo.name();
        }
    }

    @Override
    public int insertar(MetodoPago metodo) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, getDbNombre(metodo.getNombre()));
        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_METODO_PAGO", parametrosEntrada, parametrosSalida);
        metodo.setIdMetodoPago((int) parametrosSalida.get(1));
        return metodo.getIdMetodoPago();
    }

    @Override
    public int modificar(MetodoPago metodo) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, metodo.getIdMetodoPago());
        parametrosEntrada.put(2, getDbNombre(metodo.getNombre()));
        return DBManager.getInstance().ejecutarProcedimientoAuto("MODIFICAR_METODO_PAGO", parametrosEntrada, null);
    }

    @Override
    public int eliminar(int id) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_METODO_PAGO", parametrosEntrada, null);
    }

    @Override
    public MetodoPago buscarPorId(int id) {
        MetodoPago metodo = null;
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_METODO_PAGO_X_ID", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                if (rs.next()) {
                    metodo = new MetodoPago();
                    metodo.setIdMetodoPago(rs.getInt("id"));
                    metodo.setNombre(mapMetodoPago(rs.getString("nombre")));
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar metodo de pago por ID: " + ex.getMessage());
        }
        return metodo;
    }

    @Override
    public List<MetodoPago> listarTodos() {
        List<MetodoPago> lista = new ArrayList<>();
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_METODOS_PAGO_TODOS", null)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    MetodoPago metodo = new MetodoPago();
                    metodo.setIdMetodoPago(rs.getInt("id"));
                    metodo.setNombre(mapMetodoPago(rs.getString("nombre")));
                    lista.add(metodo);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar todos los metodos de pago: " + ex.getMessage());
        }
        return lista;
    }
}
