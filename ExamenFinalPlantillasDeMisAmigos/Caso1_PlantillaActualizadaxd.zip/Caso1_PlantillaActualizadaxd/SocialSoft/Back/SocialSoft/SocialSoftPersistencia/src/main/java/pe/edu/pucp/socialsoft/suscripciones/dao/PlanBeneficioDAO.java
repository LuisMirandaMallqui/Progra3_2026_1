package pe.edu.pucp.socialsoft.suscripciones.dao;

import pe.edu.pucp.socialsoft.suscripciones.model.Beneficio;
import java.util.List;

public interface PlanBeneficioDAO {
    int asociarBeneficioAPlan(int idPlan, int idBeneficio);
    int desasociarBeneficioDePlan(int idPlan, int idBeneficio);
    List<Beneficio> listarBeneficiosPorPlan(int idPlan);
}
