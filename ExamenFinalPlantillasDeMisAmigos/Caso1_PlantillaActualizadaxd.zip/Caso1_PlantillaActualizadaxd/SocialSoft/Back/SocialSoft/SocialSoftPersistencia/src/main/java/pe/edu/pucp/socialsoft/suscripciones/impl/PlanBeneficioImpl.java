package pe.edu.pucp.socialsoft.suscripciones.impl;

import pe.edu.pucp.socialsoft.config.DBManager;
import pe.edu.pucp.socialsoft.suscripciones.dao.PlanBeneficioDAO;
import pe.edu.pucp.socialsoft.suscripciones.model.Beneficio;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlanBeneficioImpl implements PlanBeneficioDAO {

    @Override
    public int asociarBeneficioAPlan(int idPlan, int idBeneficio) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, idPlan);
        parametrosEntrada.put(3, idBeneficio);

        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_PLAN_BENEFICIO", parametrosEntrada, parametrosSalida);
        return (int) parametrosSalida.get(1);
    }

    @Override
    public int desasociarBeneficioDePlan(int idPlan, int idBeneficio) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, idPlan);
        parametrosEntrada.put(2, idBeneficio);

        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_PLAN_BENEFICIO", parametrosEntrada, null);
    }

    @Override
    public List<Beneficio> listarBeneficiosPorPlan(int idPlan) {
        List<Beneficio> beneficios = new ArrayList<>();
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, idPlan);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_BENEFICIOS_X_PLAN", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    Beneficio beneficio = new Beneficio();
                    beneficio.setIdBeneficio(rs.getInt("id"));
                    beneficio.setNombre(rs.getString("nombre"));
                    beneficio.setDescripcion(rs.getString("descripcion"));
                    beneficios.add(beneficio);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar beneficios por plan: " + ex.getMessage());
        }
        return beneficios;
    }
}
