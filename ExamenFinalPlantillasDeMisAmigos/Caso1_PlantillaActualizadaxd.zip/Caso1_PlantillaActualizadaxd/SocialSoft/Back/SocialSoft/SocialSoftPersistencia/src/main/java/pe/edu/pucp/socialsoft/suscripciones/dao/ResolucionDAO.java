package pe.edu.pucp.socialsoft.suscripciones.dao;

import pe.edu.pucp.socialsoft.dao.IDAO;
import pe.edu.pucp.socialsoft.suscripciones.model.Resolucion;

public interface ResolucionDAO extends IDAO<Resolucion> {
}
