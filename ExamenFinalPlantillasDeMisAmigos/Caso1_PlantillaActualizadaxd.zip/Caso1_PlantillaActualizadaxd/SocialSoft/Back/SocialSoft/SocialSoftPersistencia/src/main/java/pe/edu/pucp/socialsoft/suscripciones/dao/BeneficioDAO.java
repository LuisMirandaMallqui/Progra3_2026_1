package pe.edu.pucp.socialsoft.suscripciones.dao;

import pe.edu.pucp.socialsoft.dao.IDAO;
import pe.edu.pucp.socialsoft.suscripciones.model.Beneficio;

public interface BeneficioDAO extends IDAO<Beneficio> {
}
