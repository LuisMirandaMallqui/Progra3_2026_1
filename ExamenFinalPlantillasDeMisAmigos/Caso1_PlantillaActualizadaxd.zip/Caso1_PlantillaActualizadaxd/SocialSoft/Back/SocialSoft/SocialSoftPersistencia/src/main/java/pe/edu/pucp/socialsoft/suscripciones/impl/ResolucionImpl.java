package pe.edu.pucp.socialsoft.suscripciones.impl;

import pe.edu.pucp.socialsoft.config.DBManager;
import pe.edu.pucp.socialsoft.suscripciones.dao.ResolucionDAO;
import pe.edu.pucp.socialsoft.suscripciones.model.Resolucion;
import pe.edu.pucp.socialsoft.enums.ResolucionTipo;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ResolucionImpl implements ResolucionDAO {

    private ResolucionTipo mapResolucionTipo(String dbNombre) {
        if (dbNombre == null) return null;
        dbNombre = dbNombre.trim().toUpperCase();
        if (dbNombre.equals("4K")) return ResolucionTipo._4K;
        try {
            return ResolucionTipo.valueOf(dbNombre);
        } catch (Exception e) {
            return null;
        }
    }

    private String getResolucionTipoDbNombre(ResolucionTipo tipo) {
        if (tipo == null) return null;
        if (tipo == ResolucionTipo._4K) return "4K";
        return tipo.name();
    }

    @Override
    public int insertar(Resolucion resolucion) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, getResolucionTipoDbNombre(resolucion.getNombre()));
        parametrosEntrada.put(3, resolucion.getDescripcion());

        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_RESOLUCION", parametrosEntrada, parametrosSalida);
        resolucion.setIdResolucion((int) parametrosSalida.get(1));
        return resolucion.getIdResolucion();
    }

    @Override
    public int modificar(Resolucion resolucion) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, resolucion.getIdResolucion());
        parametrosEntrada.put(2, getResolucionTipoDbNombre(resolucion.getNombre()));
        parametrosEntrada.put(3, resolucion.getDescripcion());

        return DBManager.getInstance().ejecutarProcedimientoAuto("MODIFICAR_RESOLUCION", parametrosEntrada, null);
    }

    @Override
    public int eliminar(int id) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_RESOLUCION", parametrosEntrada, null);
    }

    @Override
    public Resolucion buscarPorId(int id) {
        Resolucion resolucion = null;
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_RESOLUCION_X_ID", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                if (rs.next()) {
                    resolucion = new Resolucion();
                    resolucion.setIdResolucion(rs.getInt("id"));
                    resolucion.setNombre(mapResolucionTipo(rs.getString("nombre")));
                    resolucion.setDescripcion(rs.getString("descripcion"));
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar resolucion por ID: " + ex.getMessage());
        }
        return resolucion;
    }

    @Override
    public List<Resolucion> listarTodos() {
        List<Resolucion> resoluciones = new ArrayList<>();
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_RESOLUCIONES_TODOS", null)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    Resolucion resolucion = new Resolucion();
                    resolucion.setIdResolucion(rs.getInt("id"));
                    resolucion.setNombre(mapResolucionTipo(rs.getString("nombre")));
                    resolucion.setDescripcion(rs.getString("descripcion"));
                    resoluciones.add(resolucion);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar todas las resoluciones: " + ex.getMessage());
        }
        return resoluciones;
    }
}
