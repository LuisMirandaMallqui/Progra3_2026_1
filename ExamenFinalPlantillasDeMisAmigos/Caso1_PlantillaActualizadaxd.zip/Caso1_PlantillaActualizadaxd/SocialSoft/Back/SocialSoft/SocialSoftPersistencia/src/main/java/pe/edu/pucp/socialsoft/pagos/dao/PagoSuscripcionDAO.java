package pe.edu.pucp.socialsoft.pagos.dao;

import pe.edu.pucp.socialsoft.dao.IDAO;
import pe.edu.pucp.socialsoft.pagos.model.PagoSuscripcion;

public interface PagoSuscripcionDAO extends IDAO<PagoSuscripcion> {
}
