package pe.edu.pucp.socialsoft.canales.dao;

import pe.edu.pucp.socialsoft.canales.model.Canal;
import pe.edu.pucp.socialsoft.dao.IDAO;

public interface CanalDAO extends IDAO<Canal> {
}
