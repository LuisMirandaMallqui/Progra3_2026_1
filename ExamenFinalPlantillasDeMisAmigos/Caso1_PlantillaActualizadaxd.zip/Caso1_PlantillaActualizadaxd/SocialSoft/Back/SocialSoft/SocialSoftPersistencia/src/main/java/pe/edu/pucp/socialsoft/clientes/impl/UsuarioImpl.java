package pe.edu.pucp.socialsoft.clientes.impl;

import pe.edu.pucp.socialsoft.clientes.dao.UsuarioDAO;
import pe.edu.pucp.socialsoft.clientes.model.Usuario;
import pe.edu.pucp.socialsoft.config.DBManager;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsuarioImpl implements UsuarioDAO {

    @Override
    public int insertar(Usuario usuario) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, usuario.getNombreCompleto());
        parametrosEntrada.put(3, usuario.getDNI());
        parametrosEntrada.put(4, usuario.getEdad());
        parametrosEntrada.put(5, usuario.getCiudad());
        parametrosEntrada.put(6, usuario.getFechaNacimiento());
        parametrosEntrada.put(7, usuario.getTelefono());
        parametrosEntrada.put(8, usuario.getCorreo());
        parametrosEntrada.put(9, usuario.getProfesion());

        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_USUARIO", parametrosEntrada, parametrosSalida);
        usuario.setIdUsuario((int) parametrosSalida.get(1));
        return usuario.getIdUsuario();
    }

    @Override
    public int modificar(Usuario usuario) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, usuario.getIdUsuario());
        parametrosEntrada.put(2, usuario.getNombreCompleto());
        parametrosEntrada.put(3, usuario.getDNI());
        parametrosEntrada.put(4, usuario.getEdad());
        parametrosEntrada.put(5, usuario.getCiudad());
        parametrosEntrada.put(6, usuario.getFechaNacimiento());
        parametrosEntrada.put(7, usuario.getTelefono());
        parametrosEntrada.put(8, usuario.getCorreo());
        parametrosEntrada.put(9, usuario.getProfesion());

        return DBManager.getInstance().ejecutarProcedimientoAuto("MODIFICAR_USUARIO", parametrosEntrada, null);
    }

    @Override
    public int eliminar(int id) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_USUARIO", parametrosEntrada, null);
    }

    @Override
    public Usuario buscarPorId(int id) {
        Usuario usuario = null;
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_USUARIO_X_ID", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                if (rs.next()) {
                    usuario = new Usuario();
                    usuario.setIdUsuario(rs.getInt("id"));
                    usuario.setNombreCompleto(rs.getString("nombre_completo"));
                    usuario.setDNI(rs.getString("dni"));
                    usuario.setEdad(rs.getInt("edad"));
                    usuario.setCiudad(rs.getString("ciudad"));
                    usuario.setFechaNacimiento(rs.getDate("fecha_nacimiento").toLocalDate());
                    usuario.setTelefono(rs.getString("telefono"));
                    usuario.setCorreo(rs.getString("correo"));
                    usuario.setProfesion(rs.getString("profesion"));
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar usuario por ID: " + ex.getMessage());
        }
        return usuario;
    }

    @Override
    public List<Usuario> listarTodos() {
        List<Usuario> usuarios = new ArrayList<>();
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_USUARIOS_TODOS", null)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setIdUsuario(rs.getInt("id"));
                    usuario.setNombreCompleto(rs.getString("nombre_completo"));
                    usuario.setDNI(rs.getString("dni"));
                    usuario.setEdad(rs.getInt("edad"));
                    usuario.setCiudad(rs.getString("ciudad"));
                    usuario.setFechaNacimiento(rs.getDate("fecha_nacimiento").toLocalDate());
                    usuario.setTelefono(rs.getString("telefono"));
                    usuario.setCorreo(rs.getString("correo"));
                    usuario.setProfesion(rs.getString("profesion"));
                    usuarios.add(usuario);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar todos los usuarios: " + ex.getMessage());
        }
        return usuarios;
    }
}
