package pe.edu.pucp.socialsoft.clientes.dao;

import pe.edu.pucp.socialsoft.clientes.model.Usuario;
import pe.edu.pucp.socialsoft.dao.IDAO;

public interface UsuarioDAO extends IDAO<Usuario> {
}
