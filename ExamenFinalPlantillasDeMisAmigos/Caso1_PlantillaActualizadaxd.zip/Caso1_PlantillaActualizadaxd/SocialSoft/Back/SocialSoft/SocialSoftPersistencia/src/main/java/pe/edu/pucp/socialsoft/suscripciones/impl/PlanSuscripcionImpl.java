package pe.edu.pucp.socialsoft.suscripciones.impl;

import pe.edu.pucp.socialsoft.config.DBManager;
import pe.edu.pucp.socialsoft.suscripciones.dao.PlanSuscripcionDAO;
import pe.edu.pucp.socialsoft.suscripciones.model.PlanSuscripcion;
import pe.edu.pucp.socialsoft.enums.TipoPlan;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlanSuscripcionImpl implements PlanSuscripcionDAO {

    /**
     * Convierte el string de la BD al enum TipoPlan.
     * Los valores en BD son: 'BASICA', 'PREMIUM', 'VIP' (mayúsculas según DML).
     */
    private TipoPlan mapTipoPlan(String dbNombre) {
        if (dbNombre == null) return null;
        try {
            return TipoPlan.valueOf(dbNombre.trim().toUpperCase());
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Convierte el enum TipoPlan al string que espera la BD.
     * Los valores insertados por DML son: 'BASICA', 'PREMIUM', 'VIP'.
     */
    private String getTipoPlanDbNombre(TipoPlan plan) {
        if (plan == null) return null;
        return plan.name(); // BASICA, PREMIUM, VIP — coinciden directamente con la BD
    }

    @Override
    public int insertar(PlanSuscripcion plan) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, getTipoPlanDbNombre(plan.getNombre()));
        parametrosEntrada.put(3, plan.getCostoMensual());

        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_PLAN_SUSCRIPCION", parametrosEntrada, parametrosSalida);
        plan.setIdPlanSuscripcion((int) parametrosSalida.get(1));
        return plan.getIdPlanSuscripcion();
    }

    @Override
    public int modificar(PlanSuscripcion plan) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, plan.getIdPlanSuscripcion());
        parametrosEntrada.put(2, getTipoPlanDbNombre(plan.getNombre()));
        parametrosEntrada.put(3, plan.getCostoMensual());
        return DBManager.getInstance().ejecutarProcedimientoAuto("MODIFICAR_PLAN_SUSCRIPCION", parametrosEntrada, null);
    }

    @Override
    public int eliminar(int id) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_PLAN_SUSCRIPCION", parametrosEntrada, null);
    }

    @Override
    public PlanSuscripcion buscarPorId(int id) {
        PlanSuscripcion plan = null;
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_PLAN_SUSCRIPCION_X_ID", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                if (rs.next()) {
                    plan = new PlanSuscripcion();
                    plan.setIdPlanSuscripcion(rs.getInt("id"));
                    plan.setNombre(mapTipoPlan(rs.getString("nombre")));
                    plan.setCostoMensual(rs.getDouble("costo_mensual"));
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar plan por ID: " + ex.getMessage());
        }
        return plan;
    }

    @Override
    public List<PlanSuscripcion> listarTodos() {
        List<PlanSuscripcion> planes = new ArrayList<>();
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_PLAN_SUSCRIPCION_TODOS", null)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    PlanSuscripcion plan = new PlanSuscripcion();
                    plan.setIdPlanSuscripcion(rs.getInt("id"));
                    plan.setNombre(mapTipoPlan(rs.getString("nombre")));
                    plan.setCostoMensual(rs.getDouble("costo_mensual"));
                    planes.add(plan);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar todos los planes: " + ex.getMessage());
        }
        return planes;
    }
}
