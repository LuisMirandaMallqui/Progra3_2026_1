package pe.edu.pucp.socialsoft.suscripciones.impl;

import pe.edu.pucp.socialsoft.config.DBManager;
import pe.edu.pucp.socialsoft.suscripciones.dao.BeneficioDAO;
import pe.edu.pucp.socialsoft.suscripciones.model.Beneficio;

import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BeneficioImpl implements BeneficioDAO {

    @Override
    public int insertar(Beneficio beneficio) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        Map<Integer, Object> parametrosSalida = new HashMap<>();
        parametrosSalida.put(1, Types.INTEGER);
        parametrosEntrada.put(2, beneficio.getNombre());
        parametrosEntrada.put(3, beneficio.getDescripcion());

        DBManager.getInstance().ejecutarProcedimientoAuto("INSERTAR_BENEFICIO", parametrosEntrada, parametrosSalida);
        beneficio.setIdBeneficio((int) parametrosSalida.get(1));
        return beneficio.getIdBeneficio();
    }

    @Override
    public int modificar(Beneficio beneficio) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, beneficio.getIdBeneficio());
        parametrosEntrada.put(2, beneficio.getNombre());
        parametrosEntrada.put(3, beneficio.getDescripcion());

        return DBManager.getInstance().ejecutarProcedimientoAuto("MODIFICAR_BENEFICIO", parametrosEntrada, null);
    }

    @Override
    public int eliminar(int id) {
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        return DBManager.getInstance().ejecutarProcedimientoAuto("ELIMINAR_BENEFICIO", parametrosEntrada, null);
    }

    @Override
    public Beneficio buscarPorId(int id) {
        Beneficio beneficio = null;
        Map<Integer, Object> parametrosEntrada = new HashMap<>();
        parametrosEntrada.put(1, id);
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_BENEFICIO_X_ID", parametrosEntrada)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                if (rs.next()) {
                    beneficio = new Beneficio();
                    beneficio.setIdBeneficio(rs.getInt("id"));
                    beneficio.setNombre(rs.getString("nombre"));
                    beneficio.setDescripcion(rs.getString("descripcion"));
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al buscar beneficio por ID: " + ex.getMessage());
        }
        return beneficio;
    }

    @Override
    public List<Beneficio> listarTodos() {
        List<Beneficio> beneficios = new ArrayList<>();
        try (DBManager.ResultadoConsulta resultado = DBManager.getInstance().ejecutarProcedimientoLectura("LISTAR_BENEFICIOS_TODOS", null)) {
            if (resultado != null && resultado.getRs() != null) {
                ResultSet rs = resultado.getRs();
                while (rs.next()) {
                    Beneficio beneficio = new Beneficio();
                    beneficio.setIdBeneficio(rs.getInt("id"));
                    beneficio.setNombre(rs.getString("nombre"));
                    beneficio.setDescripcion(rs.getString("descripcion"));
                    beneficios.add(beneficio);
                }
            }
        } catch (Exception ex) {
            System.out.println("Error al listar todos los beneficios: " + ex.getMessage());
        }
        return beneficios;
    }
}
