package pe.edu.pucp.socialsoft.suscripciones.boi;

import pe.edu.pucp.socialsoft.bo.IBaseBO;
import pe.edu.pucp.socialsoft.suscripciones.model.PlanSuscripcion;

public interface IPlanSuscripcionBO extends IBaseBO<PlanSuscripcion> {
}
