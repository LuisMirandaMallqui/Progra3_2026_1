package pe.edu.pucp.socialsoft.pagos.boi;

import pe.edu.pucp.socialsoft.bo.IBaseBO;
import pe.edu.pucp.socialsoft.pagos.model.PagoSuscripcion;

public interface IPagoSuscripcionBO extends IBaseBO<PagoSuscripcion> {
}
