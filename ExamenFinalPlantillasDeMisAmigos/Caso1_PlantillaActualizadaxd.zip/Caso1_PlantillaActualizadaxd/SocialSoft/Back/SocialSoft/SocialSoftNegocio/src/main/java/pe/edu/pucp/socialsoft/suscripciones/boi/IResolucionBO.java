package pe.edu.pucp.socialsoft.suscripciones.boi;

import pe.edu.pucp.socialsoft.bo.IBaseBO;
import pe.edu.pucp.socialsoft.suscripciones.model.Resolucion;

public interface IResolucionBO extends IBaseBO<Resolucion> {
}
