package pe.edu.pucp.socialsoft.clientes.bo;

import pe.edu.pucp.socialsoft.clientes.boi.IUsuarioBO;
import pe.edu.pucp.socialsoft.clientes.dao.UsuarioDAO;
import pe.edu.pucp.socialsoft.clientes.dao.DispositivoUsuarioDAO;
import pe.edu.pucp.socialsoft.clientes.impl.UsuarioImpl;
import pe.edu.pucp.socialsoft.clientes.impl.DispositivoUsuarioImpl;
import pe.edu.pucp.socialsoft.clientes.model.Usuario;
import pe.edu.pucp.socialsoft.clientes.model.DispositivoUsuario;
import pe.edu.pucp.socialsoft.config.DBManager;

import java.util.List;

public class UsuarioBOImpl implements IUsuarioBO {

    private final UsuarioDAO usuarioDAO;
    private final DispositivoUsuarioDAO dispositivoUsuarioDAO;

    public UsuarioBOImpl() {
        this.usuarioDAO = new UsuarioImpl();
        this.dispositivoUsuarioDAO = new DispositivoUsuarioImpl();
    }

    @Override
    public int insertar(Usuario usuario) throws Exception {
        if (usuario == null) {
            throw new Exception("El usuario no puede ser nulo.");
        }
        if (usuario.getNombreCompleto() == null || usuario.getNombreCompleto().trim().isEmpty()) {
            throw new Exception("El nombre completo es obligatorio.");
        }
        if (usuario.getDNI() == null || usuario.getDNI().length() != 8) {
            throw new Exception("El DNI debe tener exactamente 8 caracteres.");
        }

        try {
            DBManager.getInstance().iniciarTransaccion();
            int idUsuario = usuarioDAO.insertar(usuario);
            usuario.setIdUsuario(idUsuario);

            if (usuario.getDispositivos() != null) {
                for (DispositivoUsuario dispositivo : usuario.getDispositivos()) {
                    dispositivo.setIdUsuario(idUsuario);
                    dispositivoUsuarioDAO.insertar(dispositivo);
                }
            }

            DBManager.getInstance().confirmarTransaccion();
            return idUsuario;
        } catch (Exception ex) {
            DBManager.getInstance().cancelarTransaccion();
            throw ex;
        }
    }

    @Override
    public int modificar(Usuario usuario) throws Exception {
        if (usuario == null) {
            throw new Exception("El usuario no puede ser nulo.");
        }
        if (usuario.getIdUsuario() <= 0) {
            throw new Exception("El ID del usuario es obligatorio para modificar.");
        }
        return usuarioDAO.modificar(usuario);
    }

    @Override
    public int eliminar(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID del usuario debe ser mayor que cero.");
        }
        return usuarioDAO.eliminar(id);
    }

    @Override
    public List<Usuario> listarTodos() throws Exception {
        List<Usuario> usuarios = usuarioDAO.listarTodos();
        for (Usuario u : usuarios) {
            u.setDispositivos(dispositivoUsuarioDAO.listarPorUsuario(u.getIdUsuario()));
        }
        return usuarios;
    }

    @Override
    public Usuario buscarPorId(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID del usuario debe ser mayor que cero.");
        }
        Usuario u = usuarioDAO.buscarPorId(id);
        if (u != null) {
            u.setDispositivos(dispositivoUsuarioDAO.listarPorUsuario(id));
        }
        return u;
    }
}
