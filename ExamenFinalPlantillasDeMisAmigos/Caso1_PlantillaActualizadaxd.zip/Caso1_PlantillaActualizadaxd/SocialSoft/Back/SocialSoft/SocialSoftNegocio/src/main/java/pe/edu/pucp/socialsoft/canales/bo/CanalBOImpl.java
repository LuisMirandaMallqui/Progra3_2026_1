package pe.edu.pucp.socialsoft.canales.bo;

import pe.edu.pucp.socialsoft.canales.boi.ICanalBO;
import pe.edu.pucp.socialsoft.canales.dao.CanalDAO;
import pe.edu.pucp.socialsoft.canales.impl.CanalImpl;
import pe.edu.pucp.socialsoft.canales.model.Canal;

import java.util.List;

public class CanalBOImpl implements ICanalBO {

    private final CanalDAO canalDAO;

    public CanalBOImpl() {
        this.canalDAO = new CanalImpl();
    }

    @Override
    public int insertar(Canal canal) throws Exception {
        if (canal == null) throw new Exception("El canal no puede ser nulo.");
        if (canal.getNombre() == null || canal.getNombre().trim().isEmpty()) throw new Exception("El nombre del canal es obligatorio.");
        return canalDAO.insertar(canal);
    }

    @Override
    public int modificar(Canal canal) throws Exception {
        if (canal == null) throw new Exception("El canal no puede ser nulo.");
        if (canal.getIdCanal() <= 0) throw new Exception("El ID del canal es obligatorio para modificar.");
        return canalDAO.modificar(canal);
    }

    @Override
    public int eliminar(int id) throws Exception {
        if (id <= 0) throw new Exception("El ID del canal debe ser mayor que cero.");
        return canalDAO.eliminar(id);
    }

    @Override
    public List<Canal> listarTodos() throws Exception {
        return canalDAO.listarTodos();
    }

    @Override
    public Canal buscarPorId(int id) throws Exception {
        if (id <= 0) throw new Exception("El ID del canal debe ser mayor que cero.");
        return canalDAO.buscarPorId(id);
    }
}
