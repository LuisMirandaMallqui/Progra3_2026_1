package pe.edu.pucp.socialsoft.suscripciones.bo;

import pe.edu.pucp.socialsoft.suscripciones.boi.IResolucionBO;
import pe.edu.pucp.socialsoft.suscripciones.dao.ResolucionDAO;
import pe.edu.pucp.socialsoft.suscripciones.impl.ResolucionImpl;
import pe.edu.pucp.socialsoft.suscripciones.model.Resolucion;

import java.util.List;

public class ResolucionBOImpl implements IResolucionBO {

    private final ResolucionDAO resolucionDAO;

    public ResolucionBOImpl() {
        this.resolucionDAO = new ResolucionImpl();
    }

    @Override
    public int insertar(Resolucion resolucion) throws Exception {
        if (resolucion == null) {
            throw new Exception("La resolución no puede ser nula.");
        }
        if (resolucion.getNombre() == null) {
            throw new Exception("El nombre de la resolución es obligatorio.");
        }
        return resolucionDAO.insertar(resolucion);
    }

    @Override
    public int modificar(Resolucion resolucion) throws Exception {
        if (resolucion == null) {
            throw new Exception("La resolución no puede ser nula.");
        }
        if (resolucion.getIdResolucion() <= 0) {
            throw new Exception("El ID de la resolución es obligatorio para modificar.");
        }
        return resolucionDAO.modificar(resolucion);
    }

    @Override
    public int eliminar(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID de la resolución debe ser mayor que cero.");
        }
        return resolucionDAO.eliminar(id);
    }

    @Override
    public List<Resolucion> listarTodos() throws Exception {
        return resolucionDAO.listarTodos();
    }

    @Override
    public Resolucion buscarPorId(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID de la resolución debe ser mayor que cero.");
        }
        return resolucionDAO.buscarPorId(id);
    }
}
