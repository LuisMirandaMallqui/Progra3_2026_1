package pe.edu.pucp.socialsoft.clientes.boi;

import pe.edu.pucp.socialsoft.bo.IBaseBO;
import pe.edu.pucp.socialsoft.clientes.model.Usuario;

public interface IUsuarioBO extends IBaseBO<Usuario> {
}
