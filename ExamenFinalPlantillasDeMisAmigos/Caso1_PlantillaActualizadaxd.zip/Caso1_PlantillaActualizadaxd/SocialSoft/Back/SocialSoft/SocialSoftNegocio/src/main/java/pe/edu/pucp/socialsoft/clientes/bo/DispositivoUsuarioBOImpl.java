package pe.edu.pucp.socialsoft.clientes.bo;

import pe.edu.pucp.socialsoft.clientes.boi.IDispositivoUsuarioBO;
import pe.edu.pucp.socialsoft.clientes.dao.DispositivoUsuarioDAO;
import pe.edu.pucp.socialsoft.clientes.impl.DispositivoUsuarioImpl;
import pe.edu.pucp.socialsoft.clientes.model.DispositivoUsuario;

import java.util.List;

public class DispositivoUsuarioBOImpl implements IDispositivoUsuarioBO {

    private final DispositivoUsuarioDAO dispositivoDAO;

    public DispositivoUsuarioBOImpl() {
        this.dispositivoDAO = new DispositivoUsuarioImpl();
    }

    @Override
    public int insertar(DispositivoUsuario dispositivo) throws Exception {
        if (dispositivo == null) {
            throw new Exception("El dispositivo no puede ser nulo.");
        }
        if (dispositivo.getIdUsuario() <= 0) {
            throw new Exception("El ID de usuario asociado es obligatorio.");
        }
        if (dispositivo.getNombre() == null || dispositivo.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre del dispositivo es obligatorio.");
        }
        return dispositivoDAO.insertar(dispositivo);
    }

    @Override
    public int modificar(DispositivoUsuario dispositivo) throws Exception {
        if (dispositivo == null) {
            throw new Exception("El dispositivo no puede ser nulo.");
        }
        if (dispositivo.getIdDispositivoUsuario() <= 0) {
            throw new Exception("El ID del dispositivo es obligatorio para modificar.");
        }
        return dispositivoDAO.modificar(dispositivo);
    }

    @Override
    public int eliminar(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID del dispositivo debe ser mayor que cero.");
        }
        return dispositivoDAO.eliminar(id);
    }

    @Override
    public List<DispositivoUsuario> listarTodos() throws Exception {
        return dispositivoDAO.listarTodos();
    }

    @Override
    public DispositivoUsuario buscarPorId(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID del dispositivo debe ser mayor que cero.");
        }
        return dispositivoDAO.buscarPorId(id);
    }

    @Override
    public List<DispositivoUsuario> listarPorUsuario(int idUsuario) throws Exception {
        if (idUsuario <= 0) {
            throw new Exception("El ID del usuario debe ser mayor que cero.");
        }
        return dispositivoDAO.listarPorUsuario(idUsuario);
    }
}
