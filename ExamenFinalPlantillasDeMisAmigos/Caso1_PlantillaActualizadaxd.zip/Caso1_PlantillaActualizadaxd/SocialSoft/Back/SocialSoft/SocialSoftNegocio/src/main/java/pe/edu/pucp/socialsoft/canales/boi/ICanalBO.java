package pe.edu.pucp.socialsoft.canales.boi;

import pe.edu.pucp.socialsoft.bo.IBaseBO;
import pe.edu.pucp.socialsoft.canales.model.Canal;

public interface ICanalBO extends IBaseBO<Canal> {
}
