package pe.edu.pucp.socialsoft.pagos.bo;

import pe.edu.pucp.socialsoft.pagos.boi.IMetodoPagoBO;
import pe.edu.pucp.socialsoft.pagos.dao.MetodoPagoDAO;
import pe.edu.pucp.socialsoft.pagos.impl.MetodoPagoImpl;
import pe.edu.pucp.socialsoft.pagos.model.MetodoPago;

import java.util.List;

public class MetodoPagoBOImpl implements IMetodoPagoBO {

    private final MetodoPagoDAO metodoPagoDAO;

    public MetodoPagoBOImpl() {
        this.metodoPagoDAO = new MetodoPagoImpl();
    }

    @Override
    public int insertar(MetodoPago metodo) throws Exception {
        if (metodo == null) throw new Exception("El metodo de pago no puede ser nulo.");
        if (metodo.getNombre() == null) throw new Exception("El metodo de pago no puede ser nulo.");
        return metodoPagoDAO.insertar(metodo);
    }

    @Override
    public int modificar(MetodoPago metodo) throws Exception {
        if (metodo == null) throw new Exception("El metodo de pago no puede ser nulo.");
        if (metodo.getIdMetodoPago() <= 0) throw new Exception("El ID del metodo de pago es obligatorio para modificar.");
        return metodoPagoDAO.modificar(metodo);
    }

    @Override
    public int eliminar(int id) throws Exception {
        if (id <= 0) throw new Exception("El ID del metodo de pago debe ser mayor que cero.");
        return metodoPagoDAO.eliminar(id);
    }

    @Override
    public List<MetodoPago> listarTodos() throws Exception {
        return metodoPagoDAO.listarTodos();
    }

    @Override
    public MetodoPago buscarPorId(int id) throws Exception {
        if (id <= 0) throw new Exception("El ID del metodo de pago debe ser mayor que cero.");
        return metodoPagoDAO.buscarPorId(id);
    }
}
