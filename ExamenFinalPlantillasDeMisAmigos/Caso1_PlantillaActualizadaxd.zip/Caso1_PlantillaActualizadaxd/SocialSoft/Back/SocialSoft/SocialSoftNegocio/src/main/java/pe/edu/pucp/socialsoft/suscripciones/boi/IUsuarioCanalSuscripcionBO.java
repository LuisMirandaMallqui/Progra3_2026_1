package pe.edu.pucp.socialsoft.suscripciones.boi;

import pe.edu.pucp.socialsoft.bo.IBaseBO;
import pe.edu.pucp.socialsoft.suscripciones.model.UsuarioCanalSuscripcion;

public interface IUsuarioCanalSuscripcionBO extends IBaseBO<UsuarioCanalSuscripcion> {
}
