package pe.edu.pucp.socialsoft.suscripciones.bo;

import pe.edu.pucp.socialsoft.suscripciones.boi.IBeneficioBO;
import pe.edu.pucp.socialsoft.suscripciones.dao.BeneficioDAO;
import pe.edu.pucp.socialsoft.suscripciones.impl.BeneficioImpl;
import pe.edu.pucp.socialsoft.suscripciones.model.Beneficio;

import java.util.List;

public class BeneficioBOImpl implements IBeneficioBO {

    private final BeneficioDAO beneficioDAO;

    public BeneficioBOImpl() {
        this.beneficioDAO = new BeneficioImpl();
    }

    @Override
    public int insertar(Beneficio beneficio) throws Exception {
        if (beneficio == null) {
            throw new Exception("El beneficio no puede ser nulo.");
        }
        if (beneficio.getNombre() == null || beneficio.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre del beneficio es obligatorio.");
        }
        return beneficioDAO.insertar(beneficio);
    }

    @Override
    public int modificar(Beneficio beneficio) throws Exception {
        if (beneficio == null) {
            throw new Exception("El beneficio no puede ser nulo.");
        }
        if (beneficio.getIdBeneficio() <= 0) {
            throw new Exception("El ID del beneficio es obligatorio para modificar.");
        }
        return beneficioDAO.modificar(beneficio);
    }

    @Override
    public int eliminar(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID del beneficio debe ser mayor que cero.");
        }
        return beneficioDAO.eliminar(id);
    }

    @Override
    public List<Beneficio> listarTodos() throws Exception {
        return beneficioDAO.listarTodos();
    }

    @Override
    public Beneficio buscarPorId(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID del beneficio debe ser mayor que cero.");
        }
        return beneficioDAO.buscarPorId(id);
    }
}
