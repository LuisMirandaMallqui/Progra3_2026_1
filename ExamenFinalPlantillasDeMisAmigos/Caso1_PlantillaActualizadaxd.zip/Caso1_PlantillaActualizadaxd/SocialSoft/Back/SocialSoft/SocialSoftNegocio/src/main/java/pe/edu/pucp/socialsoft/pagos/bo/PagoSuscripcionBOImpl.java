package pe.edu.pucp.socialsoft.pagos.bo;

import pe.edu.pucp.socialsoft.pagos.boi.IPagoSuscripcionBO;
import pe.edu.pucp.socialsoft.pagos.dao.PagoSuscripcionDAO;
import pe.edu.pucp.socialsoft.pagos.impl.PagoSuscripcionImpl;
import pe.edu.pucp.socialsoft.pagos.model.PagoSuscripcion;

import java.util.List;

public class PagoSuscripcionBOImpl implements IPagoSuscripcionBO {

    private final PagoSuscripcionDAO pagoDAO;

    public PagoSuscripcionBOImpl() {
        this.pagoDAO = new PagoSuscripcionImpl();
    }

    @Override
    public int insertar(PagoSuscripcion pago) throws Exception {
        if (pago == null) throw new Exception("El pago no puede ser nulo.");
        if (pago.getUsuarioCanalSuscripcion() == null || pago.getUsuarioCanalSuscripcion().getIdUsuarioCanalSuscripcion() <= 0)
            throw new Exception("La suscripcion del pago es obligatoria.");
        if (pago.getMetodoPago() == null || pago.getMetodoPago().getIdMetodoPago() <= 0)
            throw new Exception("El metodo de pago es obligatorio.");
        if (pago.getMonto() <= 0) throw new Exception("El monto del pago debe ser mayor que cero.");
        if (pago.getFechaPago() == null) throw new Exception("La fecha del pago es obligatoria.");
        if (pago.getEstado() == null || pago.getEstado().trim().isEmpty()) throw new Exception("El estado del pago es obligatorio.");
        return pagoDAO.insertar(pago);
    }

    @Override
    public int modificar(PagoSuscripcion pago) throws Exception {
        if (pago == null) throw new Exception("El pago no puede ser nulo.");
        if (pago.getIdPagoSuscripcion() <= 0) throw new Exception("El ID del pago es obligatorio para modificar.");
        return pagoDAO.modificar(pago);
    }

    @Override
    public int eliminar(int id) throws Exception {
        if (id <= 0) throw new Exception("El ID del pago debe ser mayor que cero.");
        return pagoDAO.eliminar(id);
    }

    @Override
    public List<PagoSuscripcion> listarTodos() throws Exception {
        return pagoDAO.listarTodos();
    }

    @Override
    public PagoSuscripcion buscarPorId(int id) throws Exception {
        if (id <= 0) throw new Exception("El ID del pago debe ser mayor que cero.");
        return pagoDAO.buscarPorId(id);
    }
}
