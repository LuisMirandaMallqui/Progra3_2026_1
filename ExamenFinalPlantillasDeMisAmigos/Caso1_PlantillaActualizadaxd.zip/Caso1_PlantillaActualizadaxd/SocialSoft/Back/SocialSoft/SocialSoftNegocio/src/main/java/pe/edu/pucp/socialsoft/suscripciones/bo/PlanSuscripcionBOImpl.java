package pe.edu.pucp.socialsoft.suscripciones.bo;

import pe.edu.pucp.socialsoft.config.DBManager;
import pe.edu.pucp.socialsoft.suscripciones.boi.IPlanSuscripcionBO;
import pe.edu.pucp.socialsoft.suscripciones.dao.BeneficioDAO;
import pe.edu.pucp.socialsoft.suscripciones.dao.PlanBeneficioDAO;
import pe.edu.pucp.socialsoft.suscripciones.dao.PlanResolucionDAO;
import pe.edu.pucp.socialsoft.suscripciones.dao.PlanSuscripcionDAO;
import pe.edu.pucp.socialsoft.suscripciones.dao.ResolucionDAO;
import pe.edu.pucp.socialsoft.suscripciones.impl.BeneficioImpl;
import pe.edu.pucp.socialsoft.suscripciones.impl.PlanBeneficioImpl;
import pe.edu.pucp.socialsoft.suscripciones.impl.PlanResolucionImpl;
import pe.edu.pucp.socialsoft.suscripciones.impl.PlanSuscripcionImpl;
import pe.edu.pucp.socialsoft.suscripciones.impl.ResolucionImpl;
import pe.edu.pucp.socialsoft.suscripciones.model.Beneficio;
import pe.edu.pucp.socialsoft.suscripciones.model.PlanSuscripcion;
import pe.edu.pucp.socialsoft.suscripciones.model.Resolucion;

import java.util.List;

public class PlanSuscripcionBOImpl implements IPlanSuscripcionBO {

    private final PlanSuscripcionDAO planDAO;
    private final PlanResolucionDAO planResolucionDAO;
    private final PlanBeneficioDAO planBeneficioDAO;
    private final ResolucionDAO resolucionDAO;
    private final BeneficioDAO beneficioDAO;

    public PlanSuscripcionBOImpl() {
        this.planDAO = new PlanSuscripcionImpl();
        this.planResolucionDAO = new PlanResolucionImpl();
        this.planBeneficioDAO = new PlanBeneficioImpl();
        this.resolucionDAO = new ResolucionImpl();
        this.beneficioDAO = new BeneficioImpl();
    }

    @Override
    public int insertar(PlanSuscripcion plan) throws Exception {
        if (plan == null) {
            throw new Exception("El plan de suscripcion no puede ser nulo.");
        }
        if (plan.getNombre() == null) {
            throw new Exception("El nombre del plan es obligatorio.");
        }
        if (plan.getCostoMensual() <= 0) {
            throw new Exception("El costo mensual debe ser mayor que cero.");
        }

        try {
            DBManager.getInstance().iniciarTransaccion();

            int idPlan = planDAO.insertar(plan);
            plan.setIdPlanSuscripcion(idPlan);

            if (plan.getResoluciones() != null) {
                for (Resolucion res : plan.getResoluciones()) {
                    planResolucionDAO.asociarResolucionAPlan(idPlan, res.getIdResolucion());
                }
            }

            if (plan.getBeneficios() != null) {
                for (Beneficio ben : plan.getBeneficios()) {
                    planBeneficioDAO.asociarBeneficioAPlan(idPlan, ben.getIdBeneficio());
                }
            }

            DBManager.getInstance().confirmarTransaccion();
            return idPlan;
        } catch (Exception ex) {
            DBManager.getInstance().cancelarTransaccion();
            throw ex;
        }
    }

    @Override
    public int modificar(PlanSuscripcion plan) throws Exception {
        if (plan == null) {
            throw new Exception("El plan de suscripcion no puede ser nulo.");
        }
        if (plan.getIdPlanSuscripcion() <= 0) {
            throw new Exception("El ID del plan es obligatorio para modificar.");
        }
        return planDAO.modificar(plan);
    }

    @Override
    public int eliminar(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID del plan debe ser mayor que cero.");
        }
        return planDAO.eliminar(id);
    }

    @Override
    public List<PlanSuscripcion> listarTodos() throws Exception {
        List<PlanSuscripcion> planes = planDAO.listarTodos();
        for (PlanSuscripcion p : planes) {
            p.setResoluciones(planResolucionDAO.listarResolucionesPorPlan(p.getIdPlanSuscripcion()));
            p.setBeneficios(planBeneficioDAO.listarBeneficiosPorPlan(p.getIdPlanSuscripcion()));
        }
        return planes;
    }

    @Override
    public PlanSuscripcion buscarPorId(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID del plan debe ser mayor que cero.");
        }
        PlanSuscripcion plan = planDAO.buscarPorId(id);
        if (plan != null) {
            plan.setResoluciones(planResolucionDAO.listarResolucionesPorPlan(id));
            plan.setBeneficios(planBeneficioDAO.listarBeneficiosPorPlan(id));
        }
        return plan;
    }
}
