package pe.edu.pucp.socialsoft.suscripciones.bo;

import pe.edu.pucp.socialsoft.suscripciones.boi.IUsuarioCanalSuscripcionBO;
import pe.edu.pucp.socialsoft.suscripciones.dao.UsuarioCanalSuscripcionDAO;
import pe.edu.pucp.socialsoft.suscripciones.impl.UsuarioCanalSuscripcionImpl;
import pe.edu.pucp.socialsoft.suscripciones.model.UsuarioCanalSuscripcion;

import java.util.List;

public class UsuarioCanalSuscripcionBOImpl implements IUsuarioCanalSuscripcionBO {

    private final UsuarioCanalSuscripcionDAO suscripcionDAO;

    public UsuarioCanalSuscripcionBOImpl() {
        this.suscripcionDAO = new UsuarioCanalSuscripcionImpl();
    }

    @Override
    public int insertar(UsuarioCanalSuscripcion suscripcion) throws Exception {
        if (suscripcion == null) {
            throw new Exception("La suscripcion no puede ser nula.");
        }
        if (suscripcion.getUsuario() == null || suscripcion.getUsuario().getIdUsuario() <= 0) {
            throw new Exception("El usuario de la suscripcion es obligatorio.");
        }
        if (suscripcion.getCanal() == null || suscripcion.getCanal().getIdCanal() <= 0) {
            throw new Exception("El canal de la suscripcion es obligatorio.");
        }
        if (suscripcion.getPlanSuscripcion() == null || suscripcion.getPlanSuscripcion().getIdPlanSuscripcion() <= 0) {
            throw new Exception("El plan de suscripcion es obligatorio.");
        }
        return suscripcionDAO.insertar(suscripcion);
    }

    @Override
    public int modificar(UsuarioCanalSuscripcion suscripcion) throws Exception {
        if (suscripcion == null) {
            throw new Exception("La suscripcion no puede ser nula.");
        }
        if (suscripcion.getIdUsuarioCanalSuscripcion() <= 0) {
            throw new Exception("El ID de la suscripcion es obligatorio para modificar.");
        }
        return suscripcionDAO.modificar(suscripcion);
    }

    @Override
    public int eliminar(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID de la suscripcion debe ser mayor que cero.");
        }
        return suscripcionDAO.eliminar(id);
    }

    @Override
    public List<UsuarioCanalSuscripcion> listarTodos() throws Exception {
        return suscripcionDAO.listarTodos();
    }

    @Override
    public UsuarioCanalSuscripcion buscarPorId(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("El ID de la suscripcion debe ser mayor que cero.");
        }
        return suscripcionDAO.buscarPorId(id);
    }
}
