package pe.edu.pucp.socialsoft.clientes.boi;

import pe.edu.pucp.socialsoft.bo.IBaseBO;
import pe.edu.pucp.socialsoft.clientes.model.DispositivoUsuario;

import java.util.List;

public interface IDispositivoUsuarioBO extends IBaseBO<DispositivoUsuario> {
    List<DispositivoUsuario> listarPorUsuario(int idUsuario) throws Exception;
}
