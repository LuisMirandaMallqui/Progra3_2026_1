package pe.edu.pucp.socialsoft.pagos.boi;

import pe.edu.pucp.socialsoft.bo.IBaseBO;
import pe.edu.pucp.socialsoft.pagos.model.MetodoPago;

public interface IMetodoPagoBO extends IBaseBO<MetodoPago> {
}
