package pe.edu.pucp.socialsoft.suscripciones.boi;

import pe.edu.pucp.socialsoft.bo.IBaseBO;
import pe.edu.pucp.socialsoft.suscripciones.model.Beneficio;

public interface IBeneficioBO extends IBaseBO<Beneficio> {
}
