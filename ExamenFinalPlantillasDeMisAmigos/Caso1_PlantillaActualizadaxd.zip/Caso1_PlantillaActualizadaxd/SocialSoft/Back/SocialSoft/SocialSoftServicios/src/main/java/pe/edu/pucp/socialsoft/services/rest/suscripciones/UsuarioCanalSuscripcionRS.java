package pe.edu.pucp.socialsoft.services.rest.suscripciones;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import pe.edu.pucp.socialsoft.suscripciones.bo.UsuarioCanalSuscripcionBOImpl;
import pe.edu.pucp.socialsoft.suscripciones.boi.IUsuarioCanalSuscripcionBO;
import pe.edu.pucp.socialsoft.suscripciones.model.UsuarioCanalSuscripcion;

import java.util.ArrayList;
import java.util.List;

@Path("UsuarioCanalSuscripcionRS")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UsuarioCanalSuscripcionRS {

    private final IUsuarioCanalSuscripcionBO suscripcionBO;

    public UsuarioCanalSuscripcionRS() {
        this.suscripcionBO = new UsuarioCanalSuscripcionBOImpl();
    }

    @GET
    public List<UsuarioCanalSuscripcion> listarTodasSuscripciones() {
        List<UsuarioCanalSuscripcion> lista = new ArrayList<>();
        try {
            lista = suscripcionBO.listarTodos();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return lista;
    }

    @GET
    @Path("{idSuscripcion}")
    public UsuarioCanalSuscripcion buscarSuscripcionPorId(@PathParam("idSuscripcion") int idSuscripcion) {
        UsuarioCanalSuscripcion suscripcion = null;
        try {
            suscripcion = suscripcionBO.buscarPorId(idSuscripcion);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return suscripcion;
    }

    @POST
    public int insertarSuscripcion(UsuarioCanalSuscripcion suscripcion) {
        int resultado = 0;
        try {
            resultado = suscripcionBO.insertar(suscripcion);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @PUT
    public int modificarSuscripcion(UsuarioCanalSuscripcion suscripcion) {
        int resultado = 0;
        try {
            resultado = suscripcionBO.modificar(suscripcion);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @DELETE
    @Path("{idSuscripcion}")
    public int eliminarSuscripcion(@PathParam("idSuscripcion") int idSuscripcion) {
        int resultado = 0;
        try {
            resultado = suscripcionBO.eliminar(idSuscripcion);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
}
