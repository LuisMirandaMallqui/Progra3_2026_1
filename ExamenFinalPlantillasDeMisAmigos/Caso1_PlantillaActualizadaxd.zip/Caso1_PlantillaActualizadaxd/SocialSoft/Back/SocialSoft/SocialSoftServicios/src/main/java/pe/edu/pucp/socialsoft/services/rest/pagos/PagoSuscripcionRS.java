package pe.edu.pucp.socialsoft.services.rest.pagos;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import pe.edu.pucp.socialsoft.pagos.bo.PagoSuscripcionBOImpl;
import pe.edu.pucp.socialsoft.pagos.boi.IPagoSuscripcionBO;
import pe.edu.pucp.socialsoft.pagos.model.PagoSuscripcion;

import java.util.ArrayList;
import java.util.List;

@Path("PagoSuscripcionRS")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PagoSuscripcionRS {

    private final IPagoSuscripcionBO pagoBO;

    public PagoSuscripcionRS() {
        this.pagoBO = new PagoSuscripcionBOImpl();
    }

    @GET
    public List<PagoSuscripcion> listarTodosPagos() {
        List<PagoSuscripcion> lista = new ArrayList<>();
        try {
            lista = pagoBO.listarTodos();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return lista;
    }

    @GET
    @Path("{idPago}")
    public PagoSuscripcion buscarPagoPorId(@PathParam("idPago") int idPago) {
        PagoSuscripcion pago = null;
        try {
            pago = pagoBO.buscarPorId(idPago);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return pago;
    }

    @POST
    public int insertarPago(PagoSuscripcion pago) {
        int resultado = 0;
        try {
            resultado = pagoBO.insertar(pago);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @PUT
    public int modificarPago(PagoSuscripcion pago) {
        int resultado = 0;
        try {
            resultado = pagoBO.modificar(pago);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @DELETE
    @Path("{idPago}")
    public int eliminarPago(@PathParam("idPago") int idPago) {
        int resultado = 0;
        try {
            resultado = pagoBO.eliminar(idPago);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
}
