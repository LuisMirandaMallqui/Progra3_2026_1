package pe.edu.pucp.socialsoft.services.rest;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("webresources")
public class RestApplication extends Application {
    //para verificar si funcionan los servicios rest:
    //http://localhost:8080/SocialSoftServicios/webresources/CanalRS/BuscarCanal/1
}
