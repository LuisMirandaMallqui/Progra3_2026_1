package pe.edu.pucp.socialsoft.services.rest.clientes;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import pe.edu.pucp.socialsoft.clientes.bo.UsuarioBOImpl;
import pe.edu.pucp.socialsoft.clientes.boi.IUsuarioBO;
import pe.edu.pucp.socialsoft.clientes.model.Usuario;

import java.util.ArrayList;
import java.util.List;

@Path("UsuarioRS")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UsuarioRS {

    private final IUsuarioBO usuarioBO;

    public UsuarioRS() {
        this.usuarioBO = new UsuarioBOImpl();
    }

    @GET
    public List<Usuario> listarTodosUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        try {
            usuarios = usuarioBO.listarTodos();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return usuarios;
    }

    @GET
    @Path("{idUsuario}")
    public Usuario buscarUsuarioPorId(@PathParam("idUsuario") int idUsuario) {
        Usuario usuario = null;
        try {
            usuario = usuarioBO.buscarPorId(idUsuario);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return usuario;
    }

    @POST
    public int insertarUsuario(Usuario usuario) {
        int resultado = 0;
        try {
            resultado = usuarioBO.insertar(usuario);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @PUT
    public int modificarUsuario(Usuario usuario) {
        int resultado = 0;
        try {
            resultado = usuarioBO.modificar(usuario);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @DELETE
    @Path("{idUsuario}")
    public int eliminarUsuario(@PathParam("idUsuario") int idUsuario) {
        int resultado = 0;
        try {
            resultado = usuarioBO.eliminar(idUsuario);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
}
