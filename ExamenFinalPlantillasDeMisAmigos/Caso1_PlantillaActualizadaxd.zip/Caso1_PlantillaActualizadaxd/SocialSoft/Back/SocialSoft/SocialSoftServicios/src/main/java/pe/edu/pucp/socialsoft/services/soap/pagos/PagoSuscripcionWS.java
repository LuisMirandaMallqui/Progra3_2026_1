package pe.edu.pucp.socialsoft.services.soap.pagos;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import pe.edu.pucp.socialsoft.pagos.bo.PagoSuscripcionBOImpl;
import pe.edu.pucp.socialsoft.pagos.boi.IPagoSuscripcionBO;
import pe.edu.pucp.socialsoft.pagos.model.PagoSuscripcion;

import java.util.List;

@WebService(
        serviceName = "PagoSuscripcionWS",
        targetNamespace = "http://services.socialsoft.pucp.edu.pe/"
)
public class PagoSuscripcionWS {

    private final IPagoSuscripcionBO pagoBO;

    public PagoSuscripcionWS() {
        this.pagoBO = new PagoSuscripcionBOImpl();
    }

    @WebMethod(operationName = "listarTodosPagos")
    public List<PagoSuscripcion> listarTodosPagos() {
        List<PagoSuscripcion> lista = null;
        try {
            lista = pagoBO.listarTodos();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return lista;
    }

    @WebMethod(operationName = "buscarPagoPorId")
    public PagoSuscripcion buscarPagoPorId(@WebParam(name = "idPago") int idPago) {
        PagoSuscripcion pago = null;
        try {
            pago = pagoBO.buscarPorId(idPago);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return pago;
    }

    @WebMethod(operationName = "insertarPago")
    public int insertarPago(@WebParam(name = "pago") PagoSuscripcion pago) {
        int resultado = 0;
        try {
            resultado = pagoBO.insertar(pago);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @WebMethod(operationName = "modificarPago")
    public int modificarPago(@WebParam(name = "pago") PagoSuscripcion pago) {
        int resultado = 0;
        try {
            resultado = pagoBO.modificar(pago);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @WebMethod(operationName = "eliminarPago")
    public int eliminarPago(@WebParam(name = "idPago") int idPago) {
        int resultado = 0;
        try {
            resultado = pagoBO.eliminar(idPago);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
}
