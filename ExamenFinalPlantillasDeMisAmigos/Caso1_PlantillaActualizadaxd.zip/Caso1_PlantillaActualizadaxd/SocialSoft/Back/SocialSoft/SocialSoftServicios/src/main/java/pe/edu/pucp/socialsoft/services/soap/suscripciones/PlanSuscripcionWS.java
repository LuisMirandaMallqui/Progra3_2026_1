package pe.edu.pucp.socialsoft.services.soap.suscripciones;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import pe.edu.pucp.socialsoft.suscripciones.bo.PlanSuscripcionBOImpl;
import pe.edu.pucp.socialsoft.suscripciones.boi.IPlanSuscripcionBO;
import pe.edu.pucp.socialsoft.suscripciones.model.PlanSuscripcion;

import java.util.List;

@WebService(
        serviceName = "PlanSuscripcionWS",
        targetNamespace = "http://services.socialsoft.pucp.edu.pe/"
)
public class PlanSuscripcionWS {

    private final IPlanSuscripcionBO planBO;

    public PlanSuscripcionWS() {
        this.planBO = new PlanSuscripcionBOImpl();
    }

    @WebMethod(operationName = "listarTodosPlanes")
    public List<PlanSuscripcion> listarTodosPlanes() {
        List<PlanSuscripcion> planes = null;
        try {
            planes = planBO.listarTodos();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return planes;
    }

    @WebMethod(operationName = "buscarPlanPorId")
    public PlanSuscripcion buscarPlanPorId(@WebParam(name = "idPlan") int idPlan) {
        PlanSuscripcion plan = null;
        try {
            plan = planBO.buscarPorId(idPlan);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return plan;
    }

    @WebMethod(operationName = "insertarPlan")
    public int insertarPlan(@WebParam(name = "plan") PlanSuscripcion plan) {
        int resultado = 0;
        try {
            resultado = planBO.insertar(plan);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @WebMethod(operationName = "modificarPlan")
    public int modificarPlan(@WebParam(name = "plan") PlanSuscripcion plan) {
        int resultado = 0;
        try {
            resultado = planBO.modificar(plan);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @WebMethod(operationName = "eliminarPlan")
    public int eliminarPlan(@WebParam(name = "idPlan") int idPlan) {
        int resultado = 0;
        try {
            resultado = planBO.eliminar(idPlan);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
}
