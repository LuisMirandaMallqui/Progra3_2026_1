package pe.edu.pucp.socialsoft.services.soap.suscripciones;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import pe.edu.pucp.socialsoft.suscripciones.bo.UsuarioCanalSuscripcionBOImpl;
import pe.edu.pucp.socialsoft.suscripciones.boi.IUsuarioCanalSuscripcionBO;
import pe.edu.pucp.socialsoft.suscripciones.model.UsuarioCanalSuscripcion;

import java.util.List;

@WebService(
        serviceName = "UsuarioCanalSuscripcionWS",
        targetNamespace = "http://services.socialsoft.pucp.edu.pe/"
)
public class UsuarioCanalSuscripcionWS {

    private final IUsuarioCanalSuscripcionBO suscripcionBO;

    public UsuarioCanalSuscripcionWS() {
        this.suscripcionBO = new UsuarioCanalSuscripcionBOImpl();
    }

    @WebMethod(operationName = "listarTodasSuscripciones")
    public List<UsuarioCanalSuscripcion> listarTodasSuscripciones() {
        List<UsuarioCanalSuscripcion> lista = null;
        try {
            lista = suscripcionBO.listarTodos();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return lista;
    }

    @WebMethod(operationName = "buscarSuscripcionPorId")
    public UsuarioCanalSuscripcion buscarSuscripcionPorId(@WebParam(name = "idSuscripcion") int idSuscripcion) {
        UsuarioCanalSuscripcion suscripcion = null;
        try {
            suscripcion = suscripcionBO.buscarPorId(idSuscripcion);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return suscripcion;
    }

    @WebMethod(operationName = "insertarSuscripcion")
    public int insertarSuscripcion(@WebParam(name = "suscripcion") UsuarioCanalSuscripcion suscripcion) {
        int resultado = 0;
        try {
            resultado = suscripcionBO.insertar(suscripcion);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @WebMethod(operationName = "modificarSuscripcion")
    public int modificarSuscripcion(@WebParam(name = "suscripcion") UsuarioCanalSuscripcion suscripcion) {
        int resultado = 0;
        try {
            resultado = suscripcionBO.modificar(suscripcion);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @WebMethod(operationName = "eliminarSuscripcion")
    public int eliminarSuscripcion(@WebParam(name = "idSuscripcion") int idSuscripcion) {
        int resultado = 0;
        try {
            resultado = suscripcionBO.eliminar(idSuscripcion);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
}
