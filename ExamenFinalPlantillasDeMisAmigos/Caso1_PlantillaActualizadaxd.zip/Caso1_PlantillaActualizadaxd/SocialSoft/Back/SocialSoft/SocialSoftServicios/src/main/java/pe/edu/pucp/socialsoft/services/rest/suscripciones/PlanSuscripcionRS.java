package pe.edu.pucp.socialsoft.services.rest.suscripciones;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import pe.edu.pucp.socialsoft.suscripciones.bo.PlanSuscripcionBOImpl;
import pe.edu.pucp.socialsoft.suscripciones.boi.IPlanSuscripcionBO;
import pe.edu.pucp.socialsoft.suscripciones.model.PlanSuscripcion;

import java.util.ArrayList;
import java.util.List;

@Path("PlanSuscripcionRS")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PlanSuscripcionRS {

    private final IPlanSuscripcionBO planBO;

    public PlanSuscripcionRS() {
        this.planBO = new PlanSuscripcionBOImpl();
    }

    @GET
    public List<PlanSuscripcion> listarTodosPlanes() {
        List<PlanSuscripcion> planes = new ArrayList<>();
        try {
            planes = planBO.listarTodos();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return planes;
    }

    @GET
    @Path("{idPlan}")
    public PlanSuscripcion buscarPlanPorId(@PathParam("idPlan") int idPlan) {
        PlanSuscripcion plan = null;
        try {
            plan = planBO.buscarPorId(idPlan);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return plan;
    }

    @POST
    public int insertarPlan(PlanSuscripcion plan) {
        int resultado = 0;
        try {
            resultado = planBO.insertar(plan);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @PUT
    public int modificarPlan(PlanSuscripcion plan) {
        int resultado = 0;
        try {
            resultado = planBO.modificar(plan);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @DELETE
    @Path("{idPlan}")
    public int eliminarPlan(@PathParam("idPlan") int idPlan) {
        int resultado = 0;
        try {
            resultado = planBO.eliminar(idPlan);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
}
