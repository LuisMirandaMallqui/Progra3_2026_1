package pe.edu.pucp.socialsoft.services.rest.canales;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import pe.edu.pucp.socialsoft.canales.bo.CanalBOImpl;
import pe.edu.pucp.socialsoft.canales.boi.ICanalBO;
import pe.edu.pucp.socialsoft.canales.model.Canal;

import java.util.ArrayList;
import java.util.List;

@Path("CanalRS")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CanalRS {

    private final ICanalBO canalBO;

    public CanalRS() {
        this.canalBO = new CanalBOImpl();
    }

    @GET
    public List<Canal> listarTodosCanales() {
        List<Canal> canales = new ArrayList<>();
        try {
            canales = canalBO.listarTodos();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return canales;
    }

    @GET
    @Path("{idCanal}")
    public Canal buscarCanalPorId(@PathParam("idCanal") int idCanal) {
        Canal canal = null;
        try {
            canal = canalBO.buscarPorId(idCanal);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return canal;
    }

    @POST
    public int insertarCanal(Canal canal) {
        int resultado = 0;
        try {
            resultado = canalBO.insertar(canal);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @PUT
    public int modificarCanal(Canal canal) {
        int resultado = 0;
        try {
            resultado = canalBO.modificar(canal);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @DELETE
    @Path("{idCanal}")
    public int eliminarCanal(@PathParam("idCanal") int idCanal) {
        int resultado = 0;
        try {
            resultado = canalBO.eliminar(idCanal);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
}
