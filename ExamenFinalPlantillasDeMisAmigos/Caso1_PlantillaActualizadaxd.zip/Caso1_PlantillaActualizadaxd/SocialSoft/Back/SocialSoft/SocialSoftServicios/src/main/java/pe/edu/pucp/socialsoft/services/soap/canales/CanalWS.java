package pe.edu.pucp.socialsoft.services.soap.canales;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import pe.edu.pucp.socialsoft.canales.bo.CanalBOImpl;
import pe.edu.pucp.socialsoft.canales.boi.ICanalBO;
import pe.edu.pucp.socialsoft.canales.model.Canal;

import java.util.List;

@WebService(
        serviceName = "CanalWS",
        targetNamespace = "http://services.socialsoft.pucp.edu.pe/"
)
public class CanalWS {
    //para testerar SOAP
    //http://localhost:8080/SocialSoftServicios/CanalWS?Tester

    private final ICanalBO canalBO;

    public CanalWS() {
        this.canalBO = new CanalBOImpl();
    }

    @WebMethod(operationName = "listarTodosCanales")
    public List<Canal> listarTodosCanales() {
        List<Canal> canales = null;
        try {
            canales = canalBO.listarTodos();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return canales;
    }

    @WebMethod(operationName = "buscarCanalPorId")
    public Canal buscarCanalPorId(@WebParam(name = "idCanal") int idCanal) {
        Canal canal = null;
        try {
            canal = canalBO.buscarPorId(idCanal);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return canal;
    }

    @WebMethod(operationName = "insertarCanal")
    public int insertarCanal(@WebParam(name = "canal") Canal canal) {
        int resultado = 0;
        try {
            resultado = canalBO.insertar(canal);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @WebMethod(operationName = "modificarCanal")
    public int modificarCanal(@WebParam(name = "canal") Canal canal) {
        int resultado = 0;
        try {
            resultado = canalBO.modificar(canal);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @WebMethod(operationName = "eliminarCanal")
    public int eliminarCanal(@WebParam(name = "idCanal") int idCanal) {
        int resultado = 0;
        try {
            resultado = canalBO.eliminar(idCanal);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
}
