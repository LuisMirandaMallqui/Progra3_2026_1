package pe.edu.pucp.socialsoft.services.soap.clientes;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import pe.edu.pucp.socialsoft.clientes.bo.UsuarioBOImpl;
import pe.edu.pucp.socialsoft.clientes.boi.IUsuarioBO;
import pe.edu.pucp.socialsoft.clientes.model.Usuario;

import java.util.List;

@WebService(
        serviceName = "UsuarioWS",
        targetNamespace = "http://services.socialsoft.pucp.edu.pe/"
)
public class UsuarioWS {

    private final IUsuarioBO usuarioBO;

    public UsuarioWS() {
        this.usuarioBO = new UsuarioBOImpl();
    }

    @WebMethod(operationName = "listarTodosUsuarios")
    public List<Usuario> listarTodosUsuarios() {
        List<Usuario> usuarios = null;
        try {
            usuarios = usuarioBO.listarTodos();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return usuarios;
    }

    @WebMethod(operationName = "buscarUsuarioPorId")
    public Usuario buscarUsuarioPorId(@WebParam(name = "idUsuario") int idUsuario) {
        Usuario usuario = null;
        try {
            usuario = usuarioBO.buscarPorId(idUsuario);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return usuario;
    }

    @WebMethod(operationName = "insertarUsuario")
    public int insertarUsuario(@WebParam(name = "usuario") Usuario usuario) {
        int resultado = 0;
        try {
            resultado = usuarioBO.insertar(usuario);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @WebMethod(operationName = "modificarUsuario")
    public int modificarUsuario(@WebParam(name = "usuario") Usuario usuario) {
        int resultado = 0;
        try {
            resultado = usuarioBO.modificar(usuario);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }

    @WebMethod(operationName = "eliminarUsuario")
    public int eliminarUsuario(@WebParam(name = "idUsuario") int idUsuario) {
        int resultado = 0;
        try {
            resultado = usuarioBO.eliminar(idUsuario);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return resultado;
    }
}
