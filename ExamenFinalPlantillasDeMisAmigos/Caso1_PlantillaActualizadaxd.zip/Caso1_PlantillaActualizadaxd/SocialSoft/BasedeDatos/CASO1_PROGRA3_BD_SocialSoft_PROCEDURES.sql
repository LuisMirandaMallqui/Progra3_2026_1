USE socialsoft;

-- =========================================================================
-- PROCEDURES FOR 'canal'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_CANAL;
DELIMITER $$
CREATE PROCEDURE INSERTAR_CANAL(
    OUT _id INT,
    IN _nombre VARCHAR(100),
    IN _descripcion VARCHAR(255),
    IN _fecha_creacion DATE,
    IN _numero_seguidores INT,
    IN _categoria VARCHAR(80)
)
BEGIN
    INSERT INTO canal (nombre, descripcion, fecha_creacion, numero_seguidores, categoria)
    VALUES (_nombre, _descripcion, _fecha_creacion, _numero_seguidores, _categoria);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS MODIFICAR_CANAL;
DELIMITER $$
CREATE PROCEDURE MODIFICAR_CANAL(
    IN _id INT,
    IN _nombre VARCHAR(100),
    IN _descripcion VARCHAR(255),
    IN _fecha_creacion DATE,
    IN _numero_seguidores INT,
    IN _categoria VARCHAR(80)
)
BEGIN
    UPDATE canal
    SET nombre = _nombre,
        descripcion = _descripcion,
        fecha_creacion = _fecha_creacion,
        numero_seguidores = _numero_seguidores,
        categoria = _categoria
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_CANAL;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_CANAL(
    IN _id INT
)
BEGIN
    DELETE FROM canal WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_CANAL_X_ID;
DELIMITER $$
CREATE PROCEDURE LISTAR_CANAL_X_ID(
    IN _id INT
)
BEGIN
    SELECT id, nombre, descripcion, fecha_creacion, numero_seguidores, categoria
    FROM canal
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_CANALES_TODOS;
DELIMITER $$
CREATE PROCEDURE LISTAR_CANALES_TODOS()
BEGIN
    SELECT id, nombre, descripcion, fecha_creacion, numero_seguidores, categoria
    FROM canal;
END$$
DELIMITER ;

-- =========================================================================
-- PROCEDURES FOR 'usuario'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_USUARIO;
DELIMITER $$
CREATE PROCEDURE INSERTAR_USUARIO(
    OUT _id INT,
    IN _nombre_completo VARCHAR(120),
    IN _dni VARCHAR(8),
    IN _edad INT,
    IN _ciudad VARCHAR(80),
    IN _fecha_nacimiento DATE,
    IN _telefono VARCHAR(20),
    IN _correo VARCHAR(120),
    IN _profesion VARCHAR(120)
)
BEGIN
    INSERT INTO usuario (nombre_completo, dni, edad, ciudad, fecha_nacimiento, telefono, correo, profesion)
    VALUES (_nombre_completo, _dni, _edad, _ciudad, _fecha_nacimiento, _telefono, _correo, _profesion);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS MODIFICAR_USUARIO;
DELIMITER $$
CREATE PROCEDURE MODIFICAR_USUARIO(
    IN _id INT,
    IN _nombre_completo VARCHAR(120),
    IN _dni VARCHAR(8),
    IN _edad INT,
    IN _ciudad VARCHAR(80),
    IN _fecha_nacimiento DATE,
    IN _telefono VARCHAR(20),
    IN _correo VARCHAR(120),
    IN _profesion VARCHAR(120)
)
BEGIN
    UPDATE usuario
    SET nombre_completo = _nombre_completo,
        dni = _dni,
        edad = _edad,
        ciudad = _ciudad,
        fecha_nacimiento = _fecha_nacimiento,
        telefono = _telefono,
        correo = _correo,
        profesion = _profesion
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_USUARIO;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_USUARIO(
    IN _id INT
)
BEGIN
    DELETE FROM usuario WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_USUARIO_X_ID;
DELIMITER $$
CREATE PROCEDURE LISTAR_USUARIO_X_ID(
    IN _id INT
)
BEGIN
    SELECT id, nombre_completo, dni, edad, ciudad, fecha_nacimiento, telefono, correo, profesion
    FROM usuario
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_USUARIOS_TODOS;
DELIMITER $$
CREATE PROCEDURE LISTAR_USUARIOS_TODOS()
BEGIN
    SELECT id, nombre_completo, dni, edad, ciudad, fecha_nacimiento, telefono, correo, profesion
    FROM usuario;
END$$
DELIMITER ;

-- =========================================================================
-- PROCEDURES FOR 'dispositivo_usuario'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_DISPOSITIVO_USUARIO;
DELIMITER $$
CREATE PROCEDURE INSERTAR_DISPOSITIVO_USUARIO(
    OUT _id INT,
    IN _id_usuario INT,
    IN _nombre VARCHAR(100),
    IN _tipo VARCHAR(50),
    IN _sistema_operativo VARCHAR(50),
    IN _activo BOOLEAN
)
BEGIN
    INSERT INTO dispositivo_usuario (id_usuario, nombre, tipo, sistema_operativo, activo)
    VALUES (_id_usuario, _nombre, _tipo, _sistema_operativo, _activo);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS MODIFICAR_DISPOSITIVO_USUARIO;
DELIMITER $$
CREATE PROCEDURE MODIFICAR_DISPOSITIVO_USUARIO(
    IN _id INT,
    IN _id_usuario INT,
    IN _nombre VARCHAR(100),
    IN _tipo VARCHAR(50),
    IN _sistema_operativo VARCHAR(50),
    IN _activo BOOLEAN
)
BEGIN
    UPDATE dispositivo_usuario
    SET id_usuario = _id_usuario,
        nombre = _nombre,
        tipo = _tipo,
        sistema_operativo = _sistema_operativo,
        activo = _activo
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_DISPOSITIVO_USUARIO;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_DISPOSITIVO_USUARIO(
    IN _id INT
)
BEGIN
    DELETE FROM dispositivo_usuario WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_DISPOSITIVO_USUARIO_X_ID;
DELIMITER $$
CREATE PROCEDURE LISTAR_DISPOSITIVO_USUARIO_X_ID(
    IN _id INT
)
BEGIN
    SELECT id, id_usuario, nombre, tipo, sistema_operativo, activo
    FROM dispositivo_usuario
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_DISPOSITIVOS_USUARIO_TODOS;
DELIMITER $$
CREATE PROCEDURE LISTAR_DISPOSITIVOS_USUARIO_TODOS()
BEGIN
    SELECT id, id_usuario, nombre, tipo, sistema_operativo, activo
    FROM dispositivo_usuario;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_DISPOSITIVOS_X_USUARIO;
DELIMITER $$
CREATE PROCEDURE LISTAR_DISPOSITIVOS_X_USUARIO(
    IN _id_usuario INT
)
BEGIN
    SELECT id, id_usuario, nombre, tipo, sistema_operativo, activo
    FROM dispositivo_usuario
    WHERE id_usuario = _id_usuario;
END$$
DELIMITER ;

-- =========================================================================
-- PROCEDURES FOR 'plan_suscripcion'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_PLAN_SUSCRIPCION;
DELIMITER $$
CREATE PROCEDURE INSERTAR_PLAN_SUSCRIPCION(
    OUT _id INT,
    IN _nombre VARCHAR(20),
    IN _costo_mensual DECIMAL(10,2)
)
BEGIN
    INSERT INTO plan_suscripcion (nombre, costo_mensual)
    VALUES (_nombre, _costo_mensual);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS MODIFICAR_PLAN_SUSCRIPCION;
DELIMITER $$
CREATE PROCEDURE MODIFICAR_PLAN_SUSCRIPCION(
    IN _id INT,
    IN _nombre VARCHAR(20),
    IN _costo_mensual DECIMAL(10,2)
)
BEGIN
    UPDATE plan_suscripcion
    SET nombre = _nombre,
        costo_mensual = _costo_mensual
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_PLAN_SUSCRIPCION;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_PLAN_SUSCRIPCION(
    IN _id INT
)
BEGIN
    DELETE FROM plan_suscripcion WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_PLAN_SUSCRIPCION_X_ID;
DELIMITER $$
CREATE PROCEDURE LISTAR_PLAN_SUSCRIPCION_X_ID(
    IN _id INT
)
BEGIN
    SELECT id, nombre, costo_mensual
    FROM plan_suscripcion
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_PLAN_SUSCRIPCION_TODOS;
DELIMITER $$
CREATE PROCEDURE LISTAR_PLAN_SUSCRIPCION_TODOS()
BEGIN
    SELECT id, nombre, costo_mensual
    FROM plan_suscripcion;
END$$
DELIMITER ;

-- =========================================================================
-- PROCEDURES FOR 'resolucion'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_RESOLUCION;
DELIMITER $$
CREATE PROCEDURE INSERTAR_RESOLUCION(
    OUT _id INT,
    IN _nombre VARCHAR(20),
    IN _descripcion VARCHAR(100)
)
BEGIN
    INSERT INTO resolucion (nombre, descripcion)
    VALUES (_nombre, _descripcion);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS MODIFICAR_RESOLUCION;
DELIMITER $$
CREATE PROCEDURE MODIFICAR_RESOLUCION(
    IN _id INT,
    IN _nombre VARCHAR(20),
    IN _descripcion VARCHAR(100)
)
BEGIN
    UPDATE resolucion
    SET nombre = _nombre,
        descripcion = _descripcion
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_RESOLUCION;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_RESOLUCION(
    IN _id INT
)
BEGIN
    DELETE FROM resolucion WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_RESOLUCION_X_ID;
DELIMITER $$
CREATE PROCEDURE LISTAR_RESOLUCION_X_ID(
    IN _id INT
)
BEGIN
    SELECT id, nombre, descripcion
    FROM resolucion
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_RESOLUCIONES_TODOS;
DELIMITER $$
CREATE PROCEDURE LISTAR_RESOLUCIONES_TODOS()
BEGIN
    SELECT id, nombre, descripcion
    FROM resolucion;
END$$
DELIMITER ;

-- =========================================================================
-- PROCEDURES FOR 'beneficio'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_BENEFICIO;
DELIMITER $$
CREATE PROCEDURE INSERTAR_BENEFICIO(
    OUT _id INT,
    IN _nombre VARCHAR(100),
    IN _descripcion VARCHAR(255)
)
BEGIN
    INSERT INTO beneficio (nombre, descripcion)
    VALUES (_nombre, _descripcion);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS MODIFICAR_BENEFICIO;
DELIMITER $$
CREATE PROCEDURE MODIFICAR_BENEFICIO(
    IN _id INT,
    IN _nombre VARCHAR(100),
    IN _descripcion VARCHAR(255)
)
BEGIN
    UPDATE beneficio
    SET nombre = _nombre,
        descripcion = _descripcion
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_BENEFICIO;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_BENEFICIO(
    IN _id INT
)
BEGIN
    DELETE FROM beneficio WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_BENEFICIO_X_ID;
DELIMITER $$
CREATE PROCEDURE LISTAR_BENEFICIO_X_ID(
    IN _id INT
)
BEGIN
    SELECT id, nombre, descripcion
    FROM beneficio
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_BENEFICIOS_TODOS;
DELIMITER $$
CREATE PROCEDURE LISTAR_BENEFICIOS_TODOS()
BEGIN
    SELECT id, nombre, descripcion
    FROM beneficio;
END$$
DELIMITER ;

-- =========================================================================
-- PROCEDURES FOR Many-to-Many: 'plan_resolucion'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_PLAN_RESOLUCION;
DELIMITER $$
CREATE PROCEDURE INSERTAR_PLAN_RESOLUCION(
    OUT _id INT,
    IN _id_plan INT,
    IN _id_resolucion INT
)
BEGIN
    INSERT INTO plan_resolucion (id_plan_suscripcion, id_resolucion)
    VALUES (_id_plan, _id_resolucion);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_PLAN_RESOLUCION;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_PLAN_RESOLUCION(
    IN _id_plan INT,
    IN _id_resolucion INT
)
BEGIN
    DELETE FROM plan_resolucion
    WHERE id_plan_suscripcion = _id_plan AND id_resolucion = _id_resolucion;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_RESOLUCIONES_X_PLAN;
DELIMITER $$
CREATE PROCEDURE LISTAR_RESOLUCIONES_X_PLAN(
    IN _id_plan INT
)
BEGIN
    SELECT r.id, r.nombre, r.descripcion
    FROM resolucion r
    INNER JOIN plan_resolucion pr ON r.id = pr.id_resolucion
    WHERE pr.id_plan_suscripcion = _id_plan;
END$$
DELIMITER ;

-- =========================================================================
-- PROCEDURES FOR Many-to-Many: 'plan_beneficio'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_PLAN_BENEFICIO;
DELIMITER $$
CREATE PROCEDURE INSERTAR_PLAN_BENEFICIO(
    OUT _id INT,
    IN _id_plan INT,
    IN _id_beneficio INT
)
BEGIN
    INSERT INTO plan_beneficio (id_plan_suscripcion, id_beneficio)
    VALUES (_id_plan, _id_beneficio);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_PLAN_BENEFICIO;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_PLAN_BENEFICIO(
    IN _id_plan INT,
    IN _id_beneficio INT
)
BEGIN
    DELETE FROM plan_beneficio
    WHERE id_plan_suscripcion = _id_plan AND id_beneficio = _id_beneficio;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_BENEFICIOS_X_PLAN;
DELIMITER $$
CREATE PROCEDURE LISTAR_BENEFICIOS_X_PLAN(
    IN _id_plan INT
)
BEGIN
    SELECT b.id, b.nombre, b.descripcion
    FROM beneficio b
    INNER JOIN plan_beneficio pb ON b.id = pb.id_beneficio
    WHERE pb.id_plan_suscripcion = _id_plan;
END$$
DELIMITER ;

-- =========================================================================
-- PROCEDURES FOR 'usuario_canal_suscripcion'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_USUARIO_CANAL_SUSCRIPCION;
DELIMITER $$
CREATE PROCEDURE INSERTAR_USUARIO_CANAL_SUSCRIPCION(
    OUT _id INT,
    IN _id_usuario INT,
    IN _id_canal INT,
    IN _id_plan INT,
    IN _estado VARCHAR(20)
)
BEGIN
    INSERT INTO usuario_canal_suscripcion (id_usuario, id_canal, id_plan_suscripcion, fecha_registro, estado)
    VALUES (_id_usuario, _id_canal, _id_plan, NOW(), _estado);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS MODIFICAR_USUARIO_CANAL_SUSCRIPCION;
DELIMITER $$
CREATE PROCEDURE MODIFICAR_USUARIO_CANAL_SUSCRIPCION(
    IN _id INT,
    IN _id_usuario INT,
    IN _id_canal INT,
    IN _id_plan INT,
    IN _estado VARCHAR(20)
)
BEGIN
    UPDATE usuario_canal_suscripcion
    SET id_usuario = _id_usuario,
        id_canal = _id_canal,
        id_plan_suscripcion = _id_plan,
        estado = _estado
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_USUARIO_CANAL_SUSCRIPCION;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_USUARIO_CANAL_SUSCRIPCION(
    IN _id INT
)
BEGIN
    DELETE FROM usuario_canal_suscripcion WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_USUARIO_CANAL_SUSCRIPCION_X_ID;
DELIMITER $$
CREATE PROCEDURE LISTAR_USUARIO_CANAL_SUSCRIPCION_X_ID(
    IN _id INT
)
BEGIN
    SELECT ucs.id, ucs.id_usuario, ucs.id_canal, ucs.id_plan_suscripcion, ucs.fecha_registro, ucs.estado,
           u.nombre_completo AS nombre_completo_usuario, u.dni AS dni_usuario,
           c.nombre AS nombre_canal,
           p.nombre AS nombre_plan, p.costo_mensual
    FROM usuario_canal_suscripcion ucs
    INNER JOIN usuario u ON ucs.id_usuario = u.id
    INNER JOIN canal c ON ucs.id_canal = c.id
    INNER JOIN plan_suscripcion p ON ucs.id_plan_suscripcion = p.id
    WHERE ucs.id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_USUARIO_CANAL_SUSCRIPCION_TODOS;
DELIMITER $$
CREATE PROCEDURE LISTAR_USUARIO_CANAL_SUSCRIPCION_TODOS()
BEGIN
    SELECT ucs.id, ucs.id_usuario, ucs.id_canal, ucs.id_plan_suscripcion, ucs.fecha_registro, ucs.estado,
           u.nombre_completo AS nombre_completo_usuario, u.dni AS dni_usuario,
           c.nombre AS nombre_canal,
           p.nombre AS nombre_plan, p.costo_mensual
    FROM usuario_canal_suscripcion ucs
    INNER JOIN usuario u ON ucs.id_usuario = u.id
    INNER JOIN canal c ON ucs.id_canal = c.id
    INNER JOIN plan_suscripcion p ON ucs.id_plan_suscripcion = p.id;
END$$
DELIMITER ;

-- =========================================================================
-- PROCEDURES FOR 'metodo_pago'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_METODO_PAGO;
DELIMITER $$
CREATE PROCEDURE INSERTAR_METODO_PAGO(
    OUT _id INT,
    IN _nombre VARCHAR(40)
)
BEGIN
    INSERT INTO metodo_pago (nombre)
    VALUES (_nombre);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS MODIFICAR_METODO_PAGO;
DELIMITER $$
CREATE PROCEDURE MODIFICAR_METODO_PAGO(
    IN _id INT,
    IN _nombre VARCHAR(40)
)
BEGIN
    UPDATE metodo_pago
    SET nombre = _nombre
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_METODO_PAGO;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_METODO_PAGO(
    IN _id INT
)
BEGIN
    DELETE FROM metodo_pago WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_METODO_PAGO_X_ID;
DELIMITER $$
CREATE PROCEDURE LISTAR_METODO_PAGO_X_ID(
    IN _id INT
)
BEGIN
    SELECT id, nombre
    FROM metodo_pago
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_METODOS_PAGO_TODOS;
DELIMITER $$
CREATE PROCEDURE LISTAR_METODOS_PAGO_TODOS()
BEGIN
    SELECT id, nombre
    FROM metodo_pago;
END$$
DELIMITER ;

-- =========================================================================
-- PROCEDURES FOR 'pago_suscripcion'
-- =========================================================================

DROP PROCEDURE IF EXISTS INSERTAR_PAGO_SUSCRIPCION;
DELIMITER $$
CREATE PROCEDURE INSERTAR_PAGO_SUSCRIPCION(
    OUT _id INT,
    IN _id_ucs INT,
    IN _id_metodo INT,
    IN _monto DECIMAL(10,2),
    IN _fecha_pago DATE,
    IN _estado VARCHAR(20)
)
BEGIN
    INSERT INTO pago_suscripcion (id_usuario_canal_suscripcion, id_metodo_pago, monto, fecha_pago, estado)
    VALUES (_id_ucs, _id_metodo, _monto, _fecha_pago, _estado);
    SET _id = LAST_INSERT_ID();
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS MODIFICAR_PAGO_SUSCRIPCION;
DELIMITER $$
CREATE PROCEDURE MODIFICAR_PAGO_SUSCRIPCION(
    IN _id INT,
    IN _id_ucs INT,
    IN _id_metodo INT,
    IN _monto DECIMAL(10,2),
    IN _fecha_pago DATE,
    IN _estado VARCHAR(20)
)
BEGIN
    UPDATE pago_suscripcion
    SET id_usuario_canal_suscripcion = _id_ucs,
        id_metodo_pago = _id_metodo,
        monto = _monto,
        fecha_pago = _fecha_pago,
        estado = _estado
    WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS ELIMINAR_PAGO_SUSCRIPCION;
DELIMITER $$
CREATE PROCEDURE ELIMINAR_PAGO_SUSCRIPCION(
    IN _id INT
)
BEGIN
    DELETE FROM pago_suscripcion WHERE id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_PAGO_SUSCRIPCION_X_ID;
DELIMITER $$
CREATE PROCEDURE LISTAR_PAGO_SUSCRIPCION_X_ID(
    IN _id INT
)
BEGIN
    SELECT ps.id, ps.id_usuario_canal_suscripcion, ps.id_metodo_pago, ps.monto, ps.fecha_pago, ps.estado,
           mp.nombre AS nombre_metodo
    FROM pago_suscripcion ps
    INNER JOIN metodo_pago mp ON ps.id_metodo_pago = mp.id
    WHERE ps.id = _id;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS LISTAR_PAGOS_SUSCRIPCION_TODOS;
DELIMITER $$
CREATE PROCEDURE LISTAR_PAGOS_SUSCRIPCION_TODOS()
BEGIN
    SELECT ps.id, ps.id_usuario_canal_suscripcion, ps.id_metodo_pago, ps.monto, ps.fecha_pago, ps.estado,
           mp.nombre AS nombre_metodo
    FROM pago_suscripcion ps
    INNER JOIN metodo_pago mp ON ps.id_metodo_pago = mp.id;
END$$
DELIMITER ;
