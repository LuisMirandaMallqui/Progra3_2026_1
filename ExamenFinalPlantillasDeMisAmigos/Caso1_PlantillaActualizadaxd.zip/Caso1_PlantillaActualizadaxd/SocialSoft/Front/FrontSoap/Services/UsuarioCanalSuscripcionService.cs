using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontSoap.Models;
using FrontSoap.Proxy;

namespace FrontSoap.Services
{
    public class UsuarioCanalSuscripcionService
    {
        private readonly UsuarioCanalSuscripcionWS _suscripcionWS;

        public UsuarioCanalSuscripcionService(UsuarioCanalSuscripcionWS suscripcionWS)
        {
            _suscripcionWS = suscripcionWS;
        }

        public async Task<List<UsuarioCanalSuscripcion>> ListarTodasSuscripcionesAsync()
        {
            var response = await _suscripcionWS.listarTodasSuscripcionesAsync(new listarTodasSuscripcionesRequest());
            var list = new List<UsuarioCanalSuscripcion>();
            if (response?.@return != null)
            {
                foreach (var s in response.@return)
                {
                    list.Add(MapProxyToModel(s));
                }
            }
            return list;
        }

        public async Task<UsuarioCanalSuscripcion?> BuscarSuscripcionPorIdAsync(int idSuscripcion)
        {
            var response = await _suscripcionWS.buscarSuscripcionPorIdAsync(new buscarSuscripcionPorIdRequest { idSuscripcion = idSuscripcion });
            return response?.@return != null ? MapProxyToModel(response.@return) : null;
        }

        public async Task<int> InsertarSuscripcionAsync(UsuarioCanalSuscripcion suscripcion)
        {
            var pSub = MapModelToProxy(suscripcion);
            var response = await _suscripcionWS.insertarSuscripcionAsync(new insertarSuscripcionRequest { suscripcion = pSub });
            return response?.@return ?? 0;
        }

        public async Task<int> ModificarSuscripcionAsync(UsuarioCanalSuscripcion suscripcion)
        {
            var pSub = MapModelToProxy(suscripcion);
            var response = await _suscripcionWS.modificarSuscripcionAsync(new modificarSuscripcionRequest { suscripcion = pSub });
            return response?.@return ?? 0;
        }

        public async Task<int> EliminarSuscripcionAsync(int idSuscripcion)
        {
            var response = await _suscripcionWS.eliminarSuscripcionAsync(new eliminarSuscripcionRequest { idSuscripcion = idSuscripcion });
            return response?.@return ?? 0;
        }

        private UsuarioCanalSuscripcion MapProxyToModel(usuarioCanalSuscripcion p)
        {
            var u = p.usuario != null ? new Usuario {
                IdUsuario = p.usuario.idUsuario,
                NombreCompleto = p.usuario.nombreCompleto ?? string.Empty,
                DNI = p.usuario.DNI ?? string.Empty,
                Correo = p.usuario.correo ?? string.Empty
            } : null;

            var c = p.canal != null ? new Canal {
                IdCanal = p.canal.idCanal,
                Nombre = p.canal.nombre ?? string.Empty,
                Descripcion = p.canal.descripcion ?? string.Empty
            } : null;

            PlanSuscripcion? pl = null;
            if (p.planSuscripcion != null)
            {
                pl = new PlanSuscripcion {
                    IdPlanSuscripcion = p.planSuscripcion.idPlanSuscripcion,
                    Nombre = Enum.Parse<TipoPlan>(p.planSuscripcion.nombre.ToString()),
                    CostoMensual = p.planSuscripcion.costoMensual
                };
            }

            return new UsuarioCanalSuscripcion
            {
                IdUsuarioCanalSuscripcion = p.idUsuarioCanalSuscripcion,
                Usuario = u,
                Canal = c,
                PlanSuscripcion = pl,
                FechaRegistro = null,
                Estado = p.estado ?? string.Empty
            };
        }

        private usuarioCanalSuscripcion MapModelToProxy(UsuarioCanalSuscripcion m)
        {
            var u = m.Usuario != null ? new usuario {
                idUsuario = m.Usuario.IdUsuario
            } : null;

            var c = m.Canal != null ? new canal {
                idCanal = m.Canal.IdCanal
            } : null;

            planSuscripcion? pl = null;
            if (m.PlanSuscripcion != null)
            {
                pl = new planSuscripcion {
                    idPlanSuscripcion = m.PlanSuscripcion.IdPlanSuscripcion,
                    nombre = Enum.Parse<tipoPlan>(m.PlanSuscripcion.Nombre.ToString()),
                    costoMensual = m.PlanSuscripcion.CostoMensual
                };
            }

            return new usuarioCanalSuscripcion
            {
                idUsuarioCanalSuscripcion = m.IdUsuarioCanalSuscripcion,
                usuario = u,
                canal = c,
                planSuscripcion = pl,
                estado = m.Estado
            };
        }
    }
}
