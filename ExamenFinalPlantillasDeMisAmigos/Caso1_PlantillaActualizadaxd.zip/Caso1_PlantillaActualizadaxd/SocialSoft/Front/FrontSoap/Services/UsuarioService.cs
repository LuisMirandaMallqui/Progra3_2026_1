using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontSoap.Models;
using FrontSoap.Proxy;

namespace FrontSoap.Services
{
    public class UsuarioService
    {
        private readonly UsuarioWS _usuarioWS;

        public UsuarioService(UsuarioWS usuarioWS)
        {
            _usuarioWS = usuarioWS;
        }

        public async Task<List<Usuario>> ListarTodosUsuariosAsync()
        {
            var response = await _usuarioWS.listarTodosUsuariosAsync(new listarTodosUsuariosRequest());
            var list = new List<Usuario>();
            if (response?.@return != null)
            {
                foreach (var u in response.@return)
                {
                    list.Add(MapProxyToModel(u));
                }
            }
            return list;
        }

        public async Task<Usuario?> BuscarUsuarioPorIdAsync(int idUsuario)
        {
            var response = await _usuarioWS.buscarUsuarioPorIdAsync(new buscarUsuarioPorIdRequest { idUsuario = idUsuario });
            return response?.@return != null ? MapProxyToModel(response.@return) : null;
        }

        public async Task<int> InsertarUsuarioAsync(Usuario usuario)
        {
            var pUsuario = MapModelToProxy(usuario);
            var response = await _usuarioWS.insertarUsuarioAsync(new insertarUsuarioRequest { usuario = pUsuario });
            return response?.@return ?? 0;
        }

        public async Task<int> ModificarUsuarioAsync(Usuario usuario)
        {
            var pUsuario = MapModelToProxy(usuario);
            var response = await _usuarioWS.modificarUsuarioAsync(new modificarUsuarioRequest { usuario = pUsuario });
            return response?.@return ?? 0;
        }

        public async Task<int> EliminarUsuarioAsync(int idUsuario)
        {
            var response = await _usuarioWS.eliminarUsuarioAsync(new eliminarUsuarioRequest { idUsuario = idUsuario });
            return response?.@return ?? 0;
        }

        private Usuario MapProxyToModel(usuario p)
        {
            var devList = new List<DispositivoUsuario>();
            if (p.dispositivos != null)
            {
                foreach (var d in p.dispositivos)
                {
                    devList.Add(new DispositivoUsuario {
                        IdDispositivoUsuario = d.idDispositivoUsuario,
                        Nombre = d.nombre ?? string.Empty,
                        Tipo = d.tipo ?? string.Empty,
                        SistemaOperativo = d.sistemaOperativo ?? string.Empty,
                        Activo = d.activo
                    });
                }
            }

            return new Usuario
            {
                IdUsuario = p.idUsuario,
                NombreCompleto = p.nombreCompleto ?? string.Empty,
                DNI = p.DNI ?? string.Empty,
                Edad = p.edad,
                Ciudad = p.ciudad ?? string.Empty,
                FechaNacimiento = null,
                Telefono = p.telefono ?? string.Empty,
                Correo = p.correo ?? string.Empty,
                Profesion = p.profesion ?? string.Empty,
                Dispositivos = devList
            };
        }

        private usuario MapModelToProxy(Usuario m)
        {
            var pDevs = m.Dispositivos?.Select(d => new dispositivoUsuario {
                idDispositivoUsuario = d.IdDispositivoUsuario,
                nombre = d.Nombre,
                tipo = d.Tipo,
                sistemaOperativo = d.SistemaOperativo,
                activo = d.Activo
            }).ToArray();

            return new usuario
            {
                idUsuario = m.IdUsuario,
                nombreCompleto = m.NombreCompleto,
                DNI = m.DNI,
                edad = m.Edad,
                ciudad = m.Ciudad,
                telefono = m.Telefono,
                correo = m.Correo,
                profesion = m.Profesion,
                dispositivos = pDevs
            };
        }
    }
}
