using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontSoap.Models;
using FrontSoap.Proxy;

namespace FrontSoap.Services
{
    public class CanalService
    {
        private readonly CanalWS _canalWS;

        public CanalService(CanalWS canalWS)
        {
            _canalWS = canalWS;
        }

        public async Task<List<Canal>> ListarTodosCanalesAsync()
        {
            var response = await _canalWS.listarTodosCanalesAsync(new listarTodosCanalesRequest());
            var list = new List<Canal>();
            if (response?.@return != null)
            {
                foreach (var c in response.@return)
                {
                    list.Add(MapProxyToModel(c));
                }
            }
            return list;
        }

        public async Task<Canal?> BuscarCanalPorIdAsync(int idCanal)
        {
            var response = await _canalWS.buscarCanalPorIdAsync(new buscarCanalPorIdRequest { idCanal = idCanal });
            return response?.@return != null ? MapProxyToModel(response.@return) : null;
        }

        public async Task<int> InsertarCanalAsync(Canal canal)
        {
            var pCanal = MapModelToProxy(canal);
            var response = await _canalWS.insertarCanalAsync(new insertarCanalRequest { canal = pCanal });
            return response?.@return ?? 0;
        }

        public async Task<int> ModificarCanalAsync(Canal canal)
        {
            var pCanal = MapModelToProxy(canal);
            var response = await _canalWS.modificarCanalAsync(new modificarCanalRequest { canal = pCanal });
            return response?.@return ?? 0;
        }

        public async Task<int> EliminarCanalAsync(int idCanal)
        {
            var response = await _canalWS.eliminarCanalAsync(new eliminarCanalRequest { idCanal = idCanal });
            return response?.@return ?? 0;
        }

        private Canal MapProxyToModel(canal p)
        {
            return new Canal
            {
                IdCanal = p.idCanal,
                Nombre = p.nombre ?? string.Empty,
                Descripcion = p.descripcion ?? string.Empty,
                FechaCreacion = null,
                NumeroSeguidores = p.numeroSeguidores,
                Categoria = p.categoria ?? string.Empty
            };
        }

        private canal MapModelToProxy(Canal m)
        {
            return new canal
            {
                idCanal = m.IdCanal,
                nombre = m.Nombre,
                descripcion = m.Descripcion,
                numeroSeguidores = m.NumeroSeguidores,
                categoria = m.Categoria
            };
        }
    }
}
