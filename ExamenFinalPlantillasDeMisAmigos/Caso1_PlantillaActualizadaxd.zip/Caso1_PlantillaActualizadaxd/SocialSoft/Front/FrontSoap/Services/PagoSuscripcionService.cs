using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontSoap.Models;
using FrontSoap.Proxy;

namespace FrontSoap.Services
{
    public class PagoSuscripcionService
    {
        private readonly PagoSuscripcionWS _pagoWS;

        public PagoSuscripcionService(PagoSuscripcionWS pagoWS)
        {
            _pagoWS = pagoWS;
        }

        public async Task<List<PagoSuscripcion>> ListarTodosPagosAsync()
        {
            var response = await _pagoWS.listarTodosPagosAsync(new listarTodosPagosRequest());
            var list = new List<PagoSuscripcion>();
            if (response?.@return != null)
            {
                foreach (var p in response.@return)
                {
                    list.Add(MapProxyToModel(p));
                }
            }
            return list;
        }

        public async Task<PagoSuscripcion?> BuscarPagoPorIdAsync(int idPago)
        {
            var response = await _pagoWS.buscarPagoPorIdAsync(new buscarPagoPorIdRequest { idPago = idPago });
            return response?.@return != null ? MapProxyToModel(response.@return) : null;
        }

        public async Task<int> InsertarPagoAsync(PagoSuscripcion pago)
        {
            var pPago = MapModelToProxy(pago);
            var response = await _pagoWS.insertarPagoAsync(new insertarPagoRequest { pago = pPago });
            return response?.@return ?? 0;
        }

        public async Task<int> ModificarPagoAsync(PagoSuscripcion pago)
        {
            var pPago = MapModelToProxy(pago);
            var response = await _pagoWS.modificarPagoAsync(new modificarPagoRequest { pago = pPago });
            return response?.@return ?? 0;
        }

        public async Task<int> EliminarPagoAsync(int idPago)
        {
            var response = await _pagoWS.eliminarPagoAsync(new eliminarPagoRequest { idPago = idPago });
            return response?.@return ?? 0;
        }

        private PagoSuscripcion MapProxyToModel(pagoSuscripcion p)
        {
            var ucs = p.usuarioCanalSuscripcion != null ? new UsuarioCanalSuscripcion
            {
                IdUsuarioCanalSuscripcion = p.usuarioCanalSuscripcion.idUsuarioCanalSuscripcion,
                Usuario = p.usuarioCanalSuscripcion.usuario != null ? new Usuario {
                    IdUsuario = p.usuarioCanalSuscripcion.usuario.idUsuario,
                    NombreCompleto = p.usuarioCanalSuscripcion.usuario.nombreCompleto ?? string.Empty
                } : null,
                Canal = p.usuarioCanalSuscripcion.canal != null ? new Canal {
                    IdCanal = p.usuarioCanalSuscripcion.canal.idCanal,
                    Nombre = p.usuarioCanalSuscripcion.canal.nombre ?? string.Empty
                } : null
            } : null;

            MetodoPago? mp = null;
            if (p.metodoPago != null)
            {
                mp = new MetodoPago {
                    IdMetodoPago = p.metodoPago.idMetodoPago,
                    Nombre = Enum.Parse<MetodoPagoTipo>(p.metodoPago.nombre.ToString())
                };
            }

            return new PagoSuscripcion
            {
                IdPagoSuscripcion = p.idPagoSuscripcion,
                UsuarioCanalSuscripcion = ucs,
                MetodoPago = mp,
                Monto = p.monto,
                FechaPago = null,
                Estado = p.estado ?? string.Empty
            };
        }

        private pagoSuscripcion MapModelToProxy(PagoSuscripcion m)
        {
            var ucs = m.UsuarioCanalSuscripcion != null ? new usuarioCanalSuscripcion
            {
                idUsuarioCanalSuscripcion = m.UsuarioCanalSuscripcion.IdUsuarioCanalSuscripcion
            } : null;

            metodoPago? mp = null;
            if (m.MetodoPago != null)
            {
                mp = new metodoPago {
                    idMetodoPago = m.MetodoPago.IdMetodoPago,
                    nombre = Enum.Parse<metodoPagoTipo>(m.MetodoPago.Nombre.ToString())
                };
            }

            return new pagoSuscripcion
            {
                idPagoSuscripcion = m.IdPagoSuscripcion,
                usuarioCanalSuscripcion = ucs,
                metodoPago = mp,
                monto = m.Monto,
                estado = m.Estado
            };
        }
    }
}
