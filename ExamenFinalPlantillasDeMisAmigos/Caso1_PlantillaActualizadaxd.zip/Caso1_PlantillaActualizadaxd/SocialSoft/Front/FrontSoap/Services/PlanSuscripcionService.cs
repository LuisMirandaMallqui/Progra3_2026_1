using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontSoap.Models;
using FrontSoap.Proxy;

namespace FrontSoap.Services
{
    public class PlanSuscripcionService
    {
        private readonly PlanSuscripcionWS _planWS;

        public PlanSuscripcionService(PlanSuscripcionWS planWS)
        {
            _planWS = planWS;
        }

        public async Task<List<PlanSuscripcion>> ListarTodosPlanesAsync()
        {
            var response = await _planWS.listarTodosPlanesAsync(new listarTodosPlanesRequest());
            var list = new List<PlanSuscripcion>();
            if (response?.@return != null)
            {
                foreach (var p in response.@return)
                {
                    list.Add(MapProxyToModel(p));
                }
            }
            return list;
        }

        public async Task<PlanSuscripcion?> BuscarPlanPorIdAsync(int idPlan)
        {
            var response = await _planWS.buscarPlanPorIdAsync(new buscarPlanPorIdRequest { idPlan = idPlan });
            return response?.@return != null ? MapProxyToModel(response.@return) : null;
        }

        public async Task<int> InsertarPlanAsync(PlanSuscripcion plan)
        {
            var pPlan = MapModelToProxy(plan);
            var response = await _planWS.insertarPlanAsync(new insertarPlanRequest { plan = pPlan });
            return response?.@return ?? 0;
        }

        public async Task<int> ModificarPlanAsync(PlanSuscripcion plan)
        {
            var pPlan = MapModelToProxy(plan);
            var response = await _planWS.modificarPlanAsync(new modificarPlanRequest { plan = pPlan });
            return response?.@return ?? 0;
        }

        public async Task<int> EliminarPlanAsync(int idPlan)
        {
            var response = await _planWS.eliminarPlanAsync(new eliminarPlanRequest { idPlan = idPlan });
            return response?.@return ?? 0;
        }

        private PlanSuscripcion MapProxyToModel(planSuscripcion p)
        {
            var resList = new List<Resolucion>();
            if (p.resoluciones != null)
            {
                foreach (var r in p.resoluciones)
                {
                    resList.Add(new Resolucion {
                        IdResolucion = r.idResolucion,
                        Nombre = r.nombre.ToString(),
                        Descripcion = r.descripcion ?? string.Empty
                    });
                }
            }

            var benList = new List<Beneficio>();
            if (p.beneficios != null)
            {
                foreach (var b in p.beneficios)
                {
                    benList.Add(new Beneficio {
                        IdBeneficio = b.idBeneficio,
                        Nombre = b.nombre ?? string.Empty,
                        Descripcion = b.descripcion ?? string.Empty
                    });
                }
            }

            return new PlanSuscripcion
            {
                IdPlanSuscripcion = p.idPlanSuscripcion,
                Nombre = Enum.Parse<TipoPlan>(p.nombre.ToString()),
                CostoMensual = p.costoMensual,
                Resoluciones = resList,
                Beneficios = benList
            };
        }

        private planSuscripcion MapModelToProxy(PlanSuscripcion m)
        {
            return new planSuscripcion
            {
                idPlanSuscripcion = m.IdPlanSuscripcion,
                nombre = Enum.Parse<tipoPlan>(m.Nombre.ToString()),
                costoMensual = m.CostoMensual
            };
        }
    }
}
