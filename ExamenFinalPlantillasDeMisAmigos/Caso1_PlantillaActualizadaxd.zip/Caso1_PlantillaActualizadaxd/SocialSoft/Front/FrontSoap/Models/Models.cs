using System;
using System.Collections.Generic;

namespace FrontSoap.Models
{
    public enum TipoPlan
    {
        BASICA,
        PREMIUM,
        VIP
    }

    public enum MetodoPagoTipo
    {
        TARJETA_CREDITO,
        TARJETA_DEBITO,
        YAPE,
        PLIN,
        TRANSFERENCIA_BANCARIA
    }

    public class Canal
    {
        public int IdCanal { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
        public DateTime? FechaCreacion { get; set; }
        public int NumeroSeguidores { get; set; }
        public string Categoria { get; set; } = string.Empty;
    }

    public class DispositivoUsuario
    {
        public int IdDispositivoUsuario { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Tipo { get; set; } = string.Empty;
        public string SistemaOperativo { get; set; } = string.Empty;
        public bool Activo { get; set; } = true;
    }

    public class Usuario
    {
        public int IdUsuario { get; set; }
        public string NombreCompleto { get; set; } = string.Empty;
        public string DNI { get; set; } = string.Empty;
        public int Edad { get; set; }
        public string Ciudad { get; set; } = string.Empty;
        public DateTime? FechaNacimiento { get; set; }
        public string Telefono { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
        public string Profesion { get; set; } = string.Empty;
        public List<DispositivoUsuario> Dispositivos { get; set; } = new();
    }

    public class Resolucion
    {
        public int IdResolucion { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
    }

    public class Beneficio
    {
        public int IdBeneficio { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Descripcion { get; set; } = string.Empty;
    }

    public class PlanSuscripcion
    {
        public int IdPlanSuscripcion { get; set; }
        public TipoPlan Nombre { get; set; }
        public double CostoMensual { get; set; }
        public List<Resolucion> Resoluciones { get; set; } = new();
        public List<Beneficio> Beneficios { get; set; } = new();
    }

    public class UsuarioCanalSuscripcion
    {
        public int IdUsuarioCanalSuscripcion { get; set; }
        public Usuario? Usuario { get; set; }
        public Canal? Canal { get; set; }
        public PlanSuscripcion? PlanSuscripcion { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public string Estado { get; set; } = "ACTIVA";
    }

    public class MetodoPago
    {
        public int IdMetodoPago { get; set; }
        public MetodoPagoTipo Nombre { get; set; }
    }

    public class PagoSuscripcion
    {
        public int IdPagoSuscripcion { get; set; }
        public UsuarioCanalSuscripcion? UsuarioCanalSuscripcion { get; set; }
        public MetodoPago? MetodoPago { get; set; }
        public double Monto { get; set; }
        public DateTime? FechaPago { get; set; }
        public string Estado { get; set; } = "PAGADO";
    }
}
