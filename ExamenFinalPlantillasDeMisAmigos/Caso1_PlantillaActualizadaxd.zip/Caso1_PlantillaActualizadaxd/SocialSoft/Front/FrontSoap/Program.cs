using FrontSoap.Components;
using FrontSoap.Services;
using FrontSoap.Proxy;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddScoped<CanalWS>(sp => new CanalWSClient());
builder.Services.AddScoped<PlanSuscripcionWS>(sp => new PlanSuscripcionWSClient());
builder.Services.AddScoped<UsuarioWS>(sp => new UsuarioWSClient());
builder.Services.AddScoped<UsuarioCanalSuscripcionWS>(sp => new UsuarioCanalSuscripcionWSClient());
builder.Services.AddScoped<PagoSuscripcionWS>(sp => new PagoSuscripcionWSClient());

builder.Services.AddScoped<CanalService>();
builder.Services.AddScoped<PlanSuscripcionService>();
builder.Services.AddScoped<UsuarioService>();
builder.Services.AddScoped<UsuarioCanalSuscripcionService>();
builder.Services.AddScoped<PagoSuscripcionService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
