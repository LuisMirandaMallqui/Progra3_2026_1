# Guia de Integracion y Consumo - FrontSoap (Blazor Server - WCF)

Este proyecto Blazor Server (.NET 10.0) consume servicios web **SOAP** expuestos por el backend Java en GlassFish, utilizando clientes WCF auto-generados a partir de WSDL con `dotnet-svcutil`.

---

## Arquitectura de la Integracion SOAP

```
Blazor Server (.NET 10)
  |
  +-- Services/Reference.cs          <-- Proxy consolidado (interfaces + clientes + tipos)
  +-- Services/CanalService.cs       <-- Adaptador: proxy -> modelo UI
  +-- Services/UsuarioService.cs
  +-- Services/PlanSuscripcionService.cs
  +-- Services/UsuarioCanalSuscripcionService.cs
  +-- Services/PagoSuscripcionService.cs
  +-- Models/Models.cs               <-- Entidades del dominio UI
  +-- Program.cs                     <-- Registro de clientes en DI
  |
  v
GlassFish (localhost:8080/SocialSoftServicios/)
  CanalWS | UsuarioWS | PlanSuscripcionWS | UsuarioCanalSuscripcionWS | PagoSuscripcionWS
```

### Ficheros principales

| Fichero | Descripcion |
|---------|-------------|
| `Services/Reference.cs` | Proxy consolidado generado con `dotnet-svcutil`. Contiene las 5 interfaces (`CanalWS`, `UsuarioWS`, `PlanSuscripcionWS`, `UsuarioCanalSuscripcionWS`, `PagoSuscripcionWS`), los 5 clientes WCF, todos los message contracts y los domain types. |
| `Models/Models.cs` | Entidades limpias del dominio utilizadas por los componentes Blazor. |
| `Program.cs` | Registra los clientes WCF en el contenedor DI y los servicios de adaptacion. |
| `Services/*Service.cs` | Cada servicio adapta los tipos del proxy a los modelos de la UI. |

---

## Consumo de un Servicio SOAP (Paso a Paso)

### Paso 1: Instalar dotnet-svcutil

```bash
dotnet tool install --global dotnet-svcutil
```

> **Nota:** Requiere .NET 9.0+. Si solo tienes .NET 10.0 instalado, ejecuta antes:
> ```powershell
> $env:DOTNET_ROLL_FORWARD = "LatestMajor"
> ```

### Paso 2: Generar el proxy desde el WSDL

```bash
dotnet-svcutil "http://localhost:8080/SocialSoftServicios/CanalWS?wsdl" \
  --namespace "*,FrontSoap.Proxy" \
  --output "Services/Reference.cs"
```

Repite para cada servicio (`UsuarioWS`, `PlanSuscripcionWS`, `UsuarioCanalSuscripcionWS`, `PagoSuscripcionWS`).

> **IMPORTANTE:** Como los WSDL comparten los mismos domain types, debes generar UN solo proxy consolidado y eliminar las definiciones duplicadas, o usar un unico fichero `Reference.cs` con todos los servicios.

### Paso 3: Registrar el cliente en DI (`Program.cs`)

```csharp
using FrontSoap.Proxy;

// Los clientes tienen constructor por defecto con URL hardcoded desde el WSDL
builder.Services.AddScoped<CanalWS>(sp => new CanalWSClient());
builder.Services.AddScoped<UsuarioWS>(sp => new UsuarioWSClient());
builder.Services.AddScoped<PlanSuscripcionWS>(sp => new PlanSuscripcionWSClient());
builder.Services.AddScoped<UsuarioCanalSuscripcionWS>(sp => new UsuarioCanalSuscripcionWSClient());
builder.Services.AddScoped<PagoSuscripcionWS>(sp => new PagoSuscripcionWSClient());

// Servicios de adaptacion
builder.Services.AddScoped<CanalService>();
builder.Services.AddScoped<UsuarioService>();
builder.Services.AddScoped<PlanSuscripcionService>();
builder.Services.AddScoped<UsuarioCanalSuscripcionService>();
builder.Services.AddScoped<PagoSuscripcionService>();
```

### Paso 4: Crear el adaptador de servicio

```csharp
using FrontSoap.Proxy;

namespace FrontSoap.Services
{
    public class CanalService
    {
        private readonly CanalWS _canalWS;

        public CanalService(CanalWS canalWS)
        {
            _canalWS = canalWS;
        }

        public async Task<List<Canal>> ListarTodosCanalesAsync()
        {
            var response = await _canalWS.listarTodosCanalesAsync(new listarTodosCanalesRequest());
            return response?.@return?.Select(c => new Canal
            {
                IdCanal = c.idCanal,
                Nombre = c.nombre ?? string.Empty,
                Descripcion = c.descripcion ?? string.Empty
            }).ToList() ?? new List<Canal>();
        }
    }
}
```

### Paso 5: Usar en un componente Blazor

```razor
@inject CanalService CanalService

@code {
    private List<Canal> canales = new();

    protected override async Task OnInitializedAsync()
    {
        canales = await CanalService.ListarTodosCanalesAsync();
    }
}
```

---

## Servicios SOAP Disponibles

| Servicio | Endpoint | Operaciones |
|----------|----------|-------------|
| `CanalWS` | `/CanalWS` | listarTodos, buscarPorId, insertar, modificar, eliminar |
| `UsuarioWS` | `/UsuarioWS` | listarTodos, buscarPorId, insertar, modificar, eliminar |
| `PlanSuscripcionWS` | `/PlanSuscripcionWS` | listarTodos, buscarPorId, insertar, modificar, eliminar |
| `UsuarioCanalSuscripcionWS` | `/UsuarioCanalSuscripcionWS` | listarTodas, buscarPorId, insertar, modificar, eliminar |
| `PagoSuscripcionWS` | `/PagoSuscripcionWS` | listarTodos, buscarPorId, insertar, modificar, eliminar |

---

## Ejecucion

1. **Backend:** Asegurate de que MySQL y GlassFish (`SocialSoftServicios`) esten activos en `http://localhost:8080/SocialSoftServicios/`.
2. **Frontend:** Ejecuta desde `Front/FrontSoap/`:
   ```bash
   dotnet run
   ```
3. Navega al puerto indicado por consola (habitualmente `http://localhost:5000` o `https://localhost:5001`).

---

## Notas Importantes

- **`localDate` de Java:** El tipo `java.time.LocalDate` se serializa como un `complexType` vacio en el XSD. Los campos de fecha (`fechaCreacion`, `fechaNacimiento`, `fechaRegistro`, `fechaPago`) se mapean como `null` en el frontend como solucion temporal.
- **Warnings CS8981:** Los warnings sobre nombres en minusculas (`canal`, `usuario`, etc.) son normales — son los nombres que genera el WSDL de Java.
- **Proxy consolidado:** Los 5 servicios comparten domain types en el namespace `FrontSoap.Proxy`. Por eso se usa un unico `Reference.cs` consolidado en lugar de 5 separados.
