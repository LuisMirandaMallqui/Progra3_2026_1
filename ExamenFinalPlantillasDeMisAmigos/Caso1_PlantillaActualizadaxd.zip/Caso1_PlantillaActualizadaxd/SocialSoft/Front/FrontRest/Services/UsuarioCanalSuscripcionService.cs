using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using FrontRest.Models;

namespace FrontRest.Services
{
    public class UsuarioCanalSuscripcionService
    {
        private readonly HttpClient _httpClient;
        private const string BasePath = "webresources/UsuarioCanalSuscripcionRS";

        public UsuarioCanalSuscripcionService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<UsuarioCanalSuscripcion>> ListarTodasSuscripcionesAsync()
        {
            try
            {
                Console.WriteLine($"[SuscripcionService] Requesting: {_httpClient.BaseAddress}{BasePath}");
                var response = await _httpClient.GetFromJsonAsync<List<UsuarioCanalSuscripcion>>(BasePath);
                Console.WriteLine($"[SuscripcionService] Received {response?.Count ?? 0} items");
                return response ?? new List<UsuarioCanalSuscripcion>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[SuscripcionService] ERROR: {ex.GetType().Name}: {ex.Message}");
                if (ex.InnerException != null) Console.WriteLine($"[SuscripcionService] Inner: {ex.InnerException.Message}");
                return new List<UsuarioCanalSuscripcion>();
            }
        }

        public async Task<UsuarioCanalSuscripcion?> BuscarSuscripcionPorIdAsync(int idSuscripcion)
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<UsuarioCanalSuscripcion>($"{BasePath}/{idSuscripcion}");
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarSuscripcionAsync(UsuarioCanalSuscripcion suscripcion)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync(BasePath, suscripcion);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> ModificarSuscripcionAsync(UsuarioCanalSuscripcion suscripcion)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync(BasePath, suscripcion);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarSuscripcionAsync(int idSuscripcion)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{BasePath}/{idSuscripcion}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }
    }
}
