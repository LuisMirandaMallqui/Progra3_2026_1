using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using FrontRest.Models;

namespace FrontRest.Services
{
    public class CanalService
    {
        private readonly HttpClient _httpClient;
        private const string BasePath = "webresources/CanalRS";

        public CanalService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<Canal>> ListarTodosCanalesAsync()
        {
            try
            {
                Console.WriteLine($"[CanalService] Requesting: {_httpClient.BaseAddress}{BasePath}");
                var response = await _httpClient.GetFromJsonAsync<List<Canal>>(BasePath);
                Console.WriteLine($"[CanalService] Received {response?.Count ?? 0} items");
                return response ?? new List<Canal>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[CanalService] ERROR: {ex.GetType().Name}: {ex.Message}");
                if (ex.InnerException != null) Console.WriteLine($"[CanalService] Inner: {ex.InnerException.Message}");
                return new List<Canal>();
            }
        }

        public async Task<Canal?> BuscarCanalPorIdAsync(int idCanal)
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<Canal>($"{BasePath}/{idCanal}");
            }
            catch
            {
                return null;
            }
        }

        public async Task<int> InsertarCanalAsync(Canal canal)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync(BasePath, canal);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> ModificarCanalAsync(Canal canal)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync(BasePath, canal);
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }

        public async Task<int> EliminarCanalAsync(int idCanal)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"{BasePath}/{idCanal}");
                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadFromJsonAsync<int>();
                }
                return 0;
            }
            catch
            {
                return 0;
            }
        }
    }
}
