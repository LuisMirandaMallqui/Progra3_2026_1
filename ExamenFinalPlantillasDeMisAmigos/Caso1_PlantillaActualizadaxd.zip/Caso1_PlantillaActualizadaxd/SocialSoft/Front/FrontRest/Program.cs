using FrontRest.Components;
using FrontRest.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// Configure HttpClient pointing to the REST backend context root
builder.Services.AddScoped(sp => new HttpClient {
    BaseAddress = new Uri("http://localhost:8080/SocialSoftServicios/")
});

// Register REST service clients
builder.Services.AddScoped<CanalService>();
builder.Services.AddScoped<PlanSuscripcionService>();
builder.Services.AddScoped<UsuarioService>();
builder.Services.AddScoped<UsuarioCanalSuscripcionService>();
builder.Services.AddScoped<PagoSuscripcionService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
