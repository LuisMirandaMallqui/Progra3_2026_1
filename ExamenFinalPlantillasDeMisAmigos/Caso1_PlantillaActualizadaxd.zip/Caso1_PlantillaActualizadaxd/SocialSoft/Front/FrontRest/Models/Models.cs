using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace FrontRest.Models
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum TipoPlan
    {
        BASICA,
        PREMIUM,
        VIP
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum MetodoPagoTipo
    {
        TARJETA_CREDITO,
        TARJETA_DEBITO,
        YAPE,
        PLIN,
        TRANSFERENCIA_BANCARIA
    }

    public class Canal
    {
        [JsonPropertyName("idCanal")]
        public int IdCanal { get; set; }

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; } = string.Empty;

        [JsonPropertyName("descripcion")]
        public string Descripcion { get; set; } = string.Empty;

        [JsonPropertyName("fechaCreacion")]
        public DateTime? FechaCreacion { get; set; }

        [JsonPropertyName("numeroSeguidores")]
        public int NumeroSeguidores { get; set; }

        [JsonPropertyName("categoria")]
        public string Categoria { get; set; } = string.Empty;
    }

    public class DispositivoUsuario
    {
        [JsonPropertyName("idDispositivoUsuario")]
        public int IdDispositivoUsuario { get; set; }

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; } = string.Empty;

        [JsonPropertyName("tipo")]
        public string Tipo { get; set; } = string.Empty;

        [JsonPropertyName("sistemaOperativo")]
        public string SistemaOperativo { get; set; } = string.Empty;

        [JsonPropertyName("activo")]
        public bool Activo { get; set; } = true;
    }

    public class Usuario
    {
        [JsonPropertyName("idUsuario")]
        public int IdUsuario { get; set; }

        [JsonPropertyName("nombreCompleto")]
        public string NombreCompleto { get; set; } = string.Empty;

        [JsonPropertyName("dni")]
        public string DNI { get; set; } = string.Empty;

        [JsonPropertyName("edad")]
        public int Edad { get; set; }

        [JsonPropertyName("ciudad")]
        public string Ciudad { get; set; } = string.Empty;

        [JsonPropertyName("fechaNacimiento")]
        public DateTime? FechaNacimiento { get; set; }

        [JsonPropertyName("telefono")]
        public string Telefono { get; set; } = string.Empty;

        [JsonPropertyName("correo")]
        public string Correo { get; set; } = string.Empty;

        [JsonPropertyName("profesion")]
        public string Profesion { get; set; } = string.Empty;

        [JsonPropertyName("dispositivos")]
        public List<DispositivoUsuario> Dispositivos { get; set; } = new();
    }

    public class Resolucion
    {
        [JsonPropertyName("idResolucion")]
        public int IdResolucion { get; set; }

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; } = string.Empty;

        [JsonPropertyName("descripcion")]
        public string Descripcion { get; set; } = string.Empty;
    }

    public class Beneficio
    {
        [JsonPropertyName("idBeneficio")]
        public int IdBeneficio { get; set; }

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; } = string.Empty;

        [JsonPropertyName("descripcion")]
        public string Descripcion { get; set; } = string.Empty;
    }

    public class PlanSuscripcion
    {
        [JsonPropertyName("idPlanSuscripcion")]
        public int IdPlanSuscripcion { get; set; }

        [JsonPropertyName("nombre")]
        public TipoPlan Nombre { get; set; }

        [JsonPropertyName("costoMensual")]
        public double CostoMensual { get; set; }

        [JsonPropertyName("resoluciones")]
        public List<Resolucion> Resoluciones { get; set; } = new();

        [JsonPropertyName("beneficios")]
        public List<Beneficio> Beneficios { get; set; } = new();
    }

    public class UsuarioCanalSuscripcion
    {
        [JsonPropertyName("idUsuarioCanalSuscripcion")]
        public int IdUsuarioCanalSuscripcion { get; set; }

        [JsonPropertyName("usuario")]
        public Usuario? Usuario { get; set; }

        [JsonPropertyName("canal")]
        public Canal? Canal { get; set; }

        [JsonPropertyName("planSuscripcion")]
        public PlanSuscripcion? PlanSuscripcion { get; set; }

        [JsonPropertyName("fechaRegistro")]
        public DateTime? FechaRegistro { get; set; }

        [JsonPropertyName("estado")]
        public string Estado { get; set; } = "ACTIVA";
    }

    public class MetodoPago
    {
        [JsonPropertyName("idMetodoPago")]
        public int IdMetodoPago { get; set; }

        [JsonPropertyName("nombre")]
        public MetodoPagoTipo Nombre { get; set; }
    }

    public class PagoSuscripcion
    {
        [JsonPropertyName("idPagoSuscripcion")]
        public int IdPagoSuscripcion { get; set; }

        [JsonPropertyName("usuarioCanalSuscripcion")]
        public UsuarioCanalSuscripcion? UsuarioCanalSuscripcion { get; set; }

        [JsonPropertyName("metodoPago")]
        public MetodoPago? MetodoPago { get; set; }

        [JsonPropertyName("monto")]
        public double Monto { get; set; }

        [JsonPropertyName("fechaPago")]
        public DateTime? FechaPago { get; set; }

        [JsonPropertyName("estado")]
        public string Estado { get; set; } = "PAGADO";
    }
}
