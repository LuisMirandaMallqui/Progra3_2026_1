Archivos para frontend del caso 2:

1. Instala Newtonsoft.Json.
2. Copia Utils/HttpClientUtils.cs, DTO/UniversidadDTO.cs y Managers/UniversidadRSManager.cs a tu proyecto Blazor.
3. Copia Pages/Universidad.razor a la carpeta Pages.
4. Registra UniversidadRSManager en Program.cs:
   builder.Services.AddScoped<UniversidadRSManager>();
5. Verifica la base URL dentro de UniversidadRSManager.cs.
   Si tu WAR se llama RestServicesCaso2-1.0-SNAPSHOT, cambia BASE_URL.
6. Abre /universidad.

Nota: esta interfaz muestra cursos, horarios, matrículas, evaluaciones y notas. El control fuerte de cupos, prerrequisitos y conflicto horario puede validarse en BO/procedimiento si el examen lo solicita.
