using System;
using System.Collections.Generic;
using CSharpRestClient;

class Program
{
    static void Main(string[] args)
    {
        UniversidadRSManager manager = new UniversidadRSManager();

        try
        {
            Console.WriteLine("=== FACULTADES ===");
            List<FacultadDTO> facultades = manager.ListarFacultads();
            foreach (var f in facultades)
                Console.WriteLine($"{f.Id}. {f.Nombre}");

            Console.WriteLine("\n=== CURSOS ===");
            List<CursoDTO> cursos = manager.ListarCursos();
            foreach (var c in cursos)
                Console.WriteLine($"{c.Id}. {c.Codigo} - {c.Nombre}");

            Console.WriteLine("\n=== INSERTAR ESTUDIANTE ===");
            EstudianteDTO estudiante = new EstudianteDTO();
            estudiante.Especialidad = new EspecialidadDTO { Id = 1 };
            estudiante.CodigoUniversitario = "20269999";
            estudiante.Nombres = "Alumno";
            estudiante.Apellidos = "De Prueba";
            estudiante.CorreoInstitucional = "alumno.prueba@pucp.edu.pe";
            estudiante.Activo = true;

            int idEstudiante = manager.InsertarEstudiante(estudiante);
            Console.WriteLine("ID estudiante generado: " + idEstudiante);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al consumir servicios:");
            Console.WriteLine(ex.Message);
        }

        Console.ReadKey();
    }
}
