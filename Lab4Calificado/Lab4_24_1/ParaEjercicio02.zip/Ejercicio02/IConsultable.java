interface IConsultable{
	String devolverInformacion();
}