enum Plataforma{
	ZOOM, WEBEX
}